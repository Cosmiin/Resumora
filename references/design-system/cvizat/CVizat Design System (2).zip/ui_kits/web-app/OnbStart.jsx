function OnbWelcome({ onStart, onLogin, mobile }) {
  const px = mobile ? '16px' : '44px';
  const { Button, Logo, Pill } = ONB_DS;
  const steps = [['Bring your CV once','We read it, you check every detail. It becomes your Base CV.'],['Paste a job ad','See how well you fit and what your CV is missing — in plain words.'],['Download a CV for that job','Same facts, better chosen. Your Base CV stays as it is.']];
  return <div style={{ minHeight: mobile ? undefined : '100vh', display:'flex', flexDirection:'column' }}>
    <header style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'16px ' + px }}><Logo size={30} /><Button variant="ghost" onClick={onLogin}>Log in</Button></header>
    <main style={{ flex:1, padding:'12px ' + px + ' 60px', display:'grid', gap:28, maxWidth:1120, width:'100%', margin:'0 auto', boxSizing:'border-box' }}>
      <section style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(min(100%,380px),1fr))', gap:40, alignItems:'center', background:'var(--surface-hero)', border:'1px solid #d6e4d9', borderRadius:'var(--radius-hero)', padding: mobile ? '28px 20px' : '48px 44px' }}>
        <div>
          <div style={{ font:'750 .73rem var(--font-sans)', letterSpacing:'.14em', textTransform:'uppercase', color:'var(--text-accent)', marginBottom:14 }}>For job seekers in Romania</div>
          <h1 style={{ margin:0, font:(mobile ? '700 2.1rem/1.08' : '700 3rem/1.05') + ' var(--font-display)', letterSpacing:'-0.045em', color:'var(--text-strong)', textWrap:'balance' }}>One honest CV. The right version for every job.</h1>
          <p style={{ margin:'18px 0 0', color:'var(--text-muted)', fontSize:'1.05rem', lineHeight:1.6, maxWidth:480, textWrap:'pretty' }}>Resumora shows how well you match a job and helps you say it better — without adding anything you haven’t done.</p>
          <div style={{ display:'flex', gap:10, marginTop:28, flexWrap:'wrap' }}><Button variant="primary" size="lg" iconRight="arrow-right" onClick={onStart}>Create my free account</Button><Button size="lg" icon="play">See an example first</Button></div>
          <div style={{ marginTop:16, fontSize:'.8rem', color:'var(--text-muted)' }}>About 5 minutes to set up · no card needed</div>
        </div>
        <div style={{ position:'relative', justifySelf:'center', width:'min(100%,340px)' }}>
          <div style={{ background:'#fff', padding:'26px 28px', boxShadow:'var(--shadow-paper)', transform:'rotate(2deg)', borderRadius:3 }}>
            <div style={{ font:'700 1.15rem var(--font-document)', color:'var(--text-document)' }}>Mara Ionescu</div>
            <div style={{ fontSize:'.75rem', color:'var(--text-muted)', marginTop:2 }}>Business Systems Analyst</div>
            {[100,84,62,94,70,88].map((w,i)=><div key={i} style={{ height:6, width:w+'%', background: i===2 ? 'var(--marigold-200)' : 'var(--pine-200)', borderRadius:3, margin:'13px 0' }} />)}
          </div>
          <div style={{ position:'absolute', left:-18, bottom:-14 }}><Pill tone="good" icon="shield-check">Confirmed by you</Pill></div>
        </div>
      </section>
      <section style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(min(100%,260px),1fr))', gap:24 }}>
        {steps.map(([t,d],i) => <div key={t} style={{ display:'grid', gap:8, alignContent:'start', padding:'4px 2px' }}>
          <div style={{ font:'700 1.6rem/1 var(--font-display)', color:'var(--pine-300)', letterSpacing:'-0.04em' }}>{i+1}</div>
          <div style={{ font:'var(--type-section-title)', color:'var(--text-strong)' }}>{t}</div>
          <div style={{ fontSize:'.9rem', color:'var(--text-muted)', lineHeight:1.55 }}>{d}</div>
        </div>)}
      </section>
      <section style={{ display:'flex', flexWrap:'wrap', gap:'10px 28px', paddingTop:20, borderTop:'1px solid var(--border-subtle)', fontSize:'.84rem', color:'var(--text-body)' }}>
        {[['shield-check','We never invent experience or numbers'],['lock','Your CV is never sent to employers'],['info','Scores are estimates, not hiring predictions']].map(([ic,t]) => <span key={t} style={{ display:'inline-flex', alignItems:'center', gap:8 }}><ONB_DS.Icon name={ic} size={16} color="var(--pine-600)" />{t}</span>)}
      </section>
    </main>
  </div>;
}
function OnbAccount({ data, set, onNext, onLogin }) {
  const { Card, Field, Checkbox, Button } = ONB_DS;
  const [tried, setTried] = React.useState(false);
  const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(data.email);
  const errs = { name: !data.name.trim() ? 'Add your name — it goes at the top of your CV.' : null, email: !emailOk ? 'Check the email — it should look like name@example.ro.' : null, pw: data.pw.length < 8 ? 'Use at least 8 characters.' : null, terms: !data.terms };
  const ok = !errs.name && !errs.email && !errs.pw && !errs.terms;
  const submit = () => { setTried(true); if (ok) onNext(); };
  return <div style={{ maxWidth:480, margin:'0 auto', display:'grid', gap:24 }}>
    <OnbTitle title="Create your account">Your Base CV and every job version are saved here, so you can come back anytime.</OnbTitle>
    <Card>
      <div style={{ display:'grid', gap:18 }}>
        <Field label="Full name" icon="user" value={data.name} onChange={v => set({ name:v })} hint="As it should appear on your CV." error={tried ? errs.name : undefined} />
        <Field label="Email" icon="mail" type="email" value={data.email} onChange={v => set({ email:v })} placeholder="name@example.ro" error={tried ? errs.email : undefined} success={!tried && emailOk ? 'Looks right' : undefined} />
        <Field label="Password" icon="lock" type="password" value={data.pw} onChange={v => set({ pw:v })} hint="At least 8 characters." error={tried ? errs.pw : undefined} success={data.pw.length >= 8 ? 'Strong enough' : undefined} />
        <div style={{ display:'grid', gap:6 }}>
          <Checkbox checked={data.terms} onChange={v => set({ terms:v })} label={<span>I agree to the <a href="#" onClick={e => e.preventDefault()}>Terms</a> and <a href="#" onClick={e => e.preventDefault()}>Privacy policy</a></span>} description="We use your CV only to tailor it for you. Export or delete everything anytime." />
          {tried && errs.terms && <div style={{ fontSize:'.8rem', color:'var(--status-bad-fg)', paddingLeft:34 }}>Tick this to continue.</div>}
        </div>
        <Button variant="primary" size="lg" fullWidth iconRight="arrow-right" onClick={submit}>Create account</Button>
      </div>
    </Card>
    <div style={{ textAlign:'center', fontSize:'.86rem', color:'var(--text-muted)' }}>Already have an account? <a href="#" onClick={e => { e.preventDefault(); onLogin(); }}>Log in</a></div>
  </div>;
}
function OnbVerify({ email, onNext, onChange }) {
  const { Card, Button, Alert } = ONB_DS;
  const [wait, setWait] = React.useState(0);
  React.useEffect(() => { if (!wait) return; const t = setTimeout(() => setWait(w => w - 1), 1000); return () => clearTimeout(t); }, [wait]);
  return <div style={{ maxWidth:520, margin:'0 auto', display:'grid', gap:20 }}>
    <Card padding="lg"><div style={{ display:'grid', gap:22, justifyItems:'center', textAlign:'center', padding:'8px 0' }}>
      <OnbIconTile icon="mail-check" />
      <OnbTitle center title="Check your inbox">We sent a link to <b style={{ color:'var(--text-strong)', fontWeight:650 }}>{email || 'your email'}</b>. Open it to confirm it’s you — then we’ll continue right here.</OnbTitle>
      <div style={{ display:'flex', gap:10, flexWrap:'wrap', justifyContent:'center' }}>
        <Button icon="rotate-cw" disabled={wait > 0} onClick={() => setWait(30)}>{wait ? `Resend in ${wait}s` : 'Resend email'}</Button>
        <Button variant="ghost" icon="pencil" onClick={onChange}>Change email</Button>
      </div>
    </div></Card>
    <Alert tone="info" title="Can’t find it?">Look in Spam or Promotions. The link works for 24 hours.</Alert>
    <div style={{ textAlign:'center' }}><Button variant="ghost" size="sm" iconRight="arrow-right" onClick={onNext}>Demo: open the link</Button></div>
  </div>;
}
function OnbGoals({ data, set, onNext, onBack }) {
  const { Card, RadioGroup, Field, Button } = ONB_DS;
  return <div style={{ maxWidth:640, margin:'0 auto', display:'grid', gap:24 }}>
    <OnbTitle eyebrow={data.name.trim() ? `Welcome, ${data.name.trim().split(' ')[0]}` : 'Welcome'} title="Tell us about your search">Two quick answers so your first CV starts in the right language. You can change both later.</OnbTitle>
    <Card><div style={{ display:'grid', gap:24 }}>
      <RadioGroup label="Where are you applying?" name="where" value={data.where} onChange={v => set({ where:v })} options={[
        { value:'ro', label:'In Romania', description:'Your CVs start in Romanian.' },
        { value:'abroad', label:'Abroad or at international companies', description:'Your CVs start in English.' },
        { value:'both', label:'Both', description:'We’ll ask the language for each job.' }]} />
      <Field label="What role are you aiming for?" icon="target" optional value={data.target} onChange={v => set({ target:v })} placeholder="e.g. Business Systems Analyst" hint="Shown under your name as a positioning title. It doesn’t change your past job titles." />
    </div></Card>
    <OnbActions back={<Button variant="ghost" icon="arrow-left" onClick={onBack}>Back</Button>}>
      <Button variant="ghost" onClick={onNext}>Skip for now</Button>
      <Button variant="primary" size="lg" iconRight="arrow-right" disabled={!data.where} onClick={onNext}>Continue</Button>
    </OnbActions>
  </div>;
}
Object.assign(window, { OnbWelcome, OnbAccount, OnbVerify, OnbGoals });
