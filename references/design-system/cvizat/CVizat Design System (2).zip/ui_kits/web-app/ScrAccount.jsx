function PlansScreen({ go }) {
  const { PlanCard, Button } = ONB_DS;
  const [sel, setSel] = React.useState('3');
  const plans = [['1','1 month','Renews every month'],['3','3 months','Renews every 3 months'],['6','6 months','Renews every 6 months']];
  return <div style={{ maxWidth:980, margin:'0 auto', display:'grid', gap:26 }}>
    <OnbTitle center title="Choose a plan">Editing, your match and previews stay free. A plan lets you download your CVs as PDF.</OnbTitle>
    <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(min(100%,260px),1fr))', gap:16 }}>
      {plans.map(([v, t, n]) => <PlanCard key={v} term={t} price="— RON" note={n} selected={sel === v} onSelect={() => setSel(v)} features={['PDF downloads, checked for readability','Match report for every job','Monthly allowance resets each month','Cancel anytime']} />)}
    </div>
    <div style={{ display:'grid', justifyItems:'center', gap:10 }}>
      <Button variant="primary" size="lg" iconRight="arrow-right" onClick={() => go('checkout')}>Continue with {plans.find(p => p[0] === sel)[1]}</Button>
      <div style={{ fontSize:'.8rem', color:'var(--text-muted)' }}>Prices and allowances aren’t final yet. VAT included.</div>
    </div>
  </div>;
}
function CheckoutScreen({ state, go, flash }) {
  const { Card, Button, Checkbox, Alert, Spinner, Icon } = ONB_DS;
  const [st, setSt] = React.useState({ Form:'form', Pending:'pending', Declined:'declined', Active:'active' }[state]);
  const [ack, setAck] = React.useState(false);
  const pay = () => { setSt('busy'); setTimeout(() => setSt('active'), 1500); };
  const row = (k, v, b) => <div style={{ display:'flex', justifyContent:'space-between', gap:12, fontSize:'.88rem', color: b ? 'var(--text-strong)' : 'var(--text-body)', fontWeight: b ? 650 : 400 }}><span>{k}</span><span>{v}</span></div>;
  return <div style={{ maxWidth:980, margin:'0 auto', display:'flex', flexWrap:'wrap', gap:24, alignItems:'flex-start' }}>
    <div style={{ flex:'2 1 480px', display:'grid', gap:16, minWidth:0 }}>
      {st === 'form' && <><OnbTitle title="Checkout">You’ll enter your card on our payment provider’s secure page.</OnbTitle>
        <Card><div style={{ display:'grid', gap:18 }}>
          <OnbPromise items={[['lock','Resumora never sees your card number','Payments are handled by our provider.'],['calendar-clock','Renews every 3 months','Until you cancel. Cancel anytime from Account — you keep access to the end of the period.']]} />
          <Checkbox variant="card" checked={ack} onChange={setAck} label="I understand this plan renews every 3 months until I cancel" />
          <div><Button variant="primary" size="lg" iconRight="external-link" disabled={!ack} onClick={pay}>Continue to payment</Button></div>
        </div></Card></>}
      {st === 'busy' && <Card padding="lg"><div style={{ padding:'30px 0', textAlign:'center' }}><Spinner label="Waiting for the payment provider to confirm…" /></div></Card>}
      {st === 'pending' && <Card padding="lg"><div style={{ display:'grid', gap:16, justifyItems:'start' }}>
        <OnbIconTile icon="hourglass" tone="warn" />
        <OnbTitle title="Waiting for your bank">This can take a few minutes. You’ll get access as soon as the payment is confirmed — not before.</OnbTitle>
        <div style={{ display:'flex', gap:10, flexWrap:'wrap' }}><Button variant="primary" icon="rotate-cw" onClick={pay}>Check again</Button><Button variant="ghost" onClick={() => go('home')}>Back to my CVs</Button></div>
      </div></Card>}
      {st === 'declined' && <><OnbTitle title="Checkout"></OnbTitle><Alert tone="bad" title="Your bank declined the payment" action={<Button size="sm" variant="primary" onClick={() => setSt('form')}>Try again</Button>}>Nothing was charged. Try again, or use another card on the next page.</Alert>
        <div><Button variant="ghost" icon="arrow-left" onClick={() => go('plans')}>Back to plans</Button></div></>}
      {st === 'active' && <Card padding="lg"><div style={{ display:'grid', gap:16, justifyItems:'start' }}>
        <OnbIconTile icon="circle-check" tone="inverse" />
        <OnbTitle title="Your plan is active">3 months · renews 25 Jan 2027. You can cancel anytime from Account.</OnbTitle>
        <div style={{ display:'flex', gap:10, flexWrap:'wrap' }}><Button variant="primary" icon="download" onClick={() => go('preview')}>Download my CV</Button><Button onClick={() => go('account')}>Go to account</Button></div>
      </div></Card>}
    </div>
    <Card tone="sunken" style={{ flex:'1 1 260px', width:'auto' }}><div style={{ display:'grid', gap:12 }}>
      <div style={{ font:'var(--type-section-title)', color:'var(--text-strong)' }}>Order summary</div>
      {row('Plan','3 months')}{row('Price','— RON')}{row('VAT','Included')}{row('Renews','Every 3 months')}
      <div style={{ borderTop:'1px solid var(--border-subtle)', paddingTop:12 }}>{row('Total today','— RON', true)}</div>
      {st === 'form' && <Button variant="ghost" size="sm" icon="pencil" onClick={() => go('plans')}>Change plan</Button>}
    </div></Card>
  </div>;
}
function AccountScreen({ state, go, flash }) {
  const { Card, Button, Field, Select, Pill, Alert, ProgressBar, Dialog, Checkbox } = ONB_DS;
  const [st, setSt] = React.useState(state);
  const [ask, setAsk] = React.useState(null);
  const [sure, setSure] = React.useState(false);
  const status = { 'Active':['good','Active'], 'Cancel scheduled':['warn','Ends 25 Jan 2027'], 'Payment failed':['bad','Payment failed'], 'Free':['neutral','Free'] }[st];
  const H = ({ children, right }) => <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', gap:10, flexWrap:'wrap' }}><div style={{ font:'var(--type-section-title)', color:'var(--text-strong)' }}>{children}</div>{right}</div>;
  return <div style={{ maxWidth:820, margin:'0 auto', display:'grid', gap:20 }}>
    <OnbTitle title="Account"></OnbTitle>
    <Card><div style={{ display:'grid', gap:16 }}>
      <H right={<Pill size="sm" tone="good" icon="mail-check">Email verified</Pill>}>Profile</H>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(min(100%,220px),1fr))', gap:14 }}>
        <Field label="Name" defaultValue="Mara Ionescu" /><Field label="Email" type="email" defaultValue="mara.ionescu@example.ro" />
        <Select label="App language" icon="languages" defaultValue="ro" options={[{ value:'ro', label:'Română' },{ value:'en', label:'English' }]} hint="Your CVs keep their own language." />
      </div>
    </div></Card>
    <Card><div style={{ display:'grid', gap:16 }}>
      <H right={<Pill size="sm" tone={status[0]}>{status[1]}</Pill>}>Plan</H>
      {st === 'Free' ? <><div style={{ fontSize:'.9rem', color:'var(--text-muted)', lineHeight:1.55 }}>You can edit, check matches and preview for free. Choose a plan when you want to download.</div><div><Button variant="primary" iconRight="arrow-right" onClick={() => go('plans')}>See plans</Button></div></> : <>
        {st === 'Cancel scheduled' && <Alert tone="neutral" icon="calendar-x" action={<Button size="sm" variant="primary" onClick={() => { setSt('Active'); flash('Plan resumed — renews 25 Jan 2027'); }}>Resume plan</Button>}>Your plan ends on 25 Jan 2027. You keep full access until then, and your CVs stay here after.</Alert>}
        {st === 'Payment failed' && <Alert tone="bad" title="We couldn’t renew your plan" action={<Button size="sm" variant="primary" onClick={() => go('checkout')}>Update payment</Button>}>Downloads are paused. Your CVs, versions and applications are safe.</Alert>}
        <div style={{ fontSize:'.9rem', color:'var(--text-body)' }}>3 months · {st === 'Cancel scheduled' ? 'doesn’t renew' : 'renews 25 Jan 2027'}</div>
        <ProgressBar label="PDF downloads this month" valueLabel="2 of 10" value={2} max={10} />
        <div style={{ fontSize:'.78rem', color:'var(--text-muted)' }}>Proposed allowance · resets 1 Nov</div>
        {st === 'Active' && <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}><Button onClick={() => go('plans')}>Change term</Button><Button variant="ghost" onClick={() => setAsk('cancel')}>Cancel plan</Button></div>}
      </>}
    </div></Card>
    <Card><div style={{ display:'grid', gap:16 }}>
      <H>Your data</H>
      <div style={{ display:'flex', justifyContent:'space-between', gap:12, alignItems:'center', flexWrap:'wrap' }}><div style={{ fontSize:'.88rem', color:'var(--text-muted)', lineHeight:1.5, flex:'1 1 300px' }}>Download everything: Base CV and its history, job CVs, applications with sent copies, and your answers.</div><Button icon="download" onClick={() => flash('Export ready — resumora-data.json')}>Export (JSON)</Button></div>
      <div style={{ display:'flex', justifyContent:'space-between', gap:12, alignItems:'center', flexWrap:'wrap', paddingTop:16, borderTop:'1px solid var(--border-subtle)' }}><div style={{ fontSize:'.88rem', color:'var(--text-muted)', flex:'1 1 300px' }}>Delete your account and everything in it.</div><Button variant="danger" icon="trash-2" onClick={() => { setSure(false); setAsk('delete'); }}>Delete account</Button></div>
    </div></Card>
    {ask === 'cancel' && <Dialog title="Cancel at the end of this period?" onClose={() => setAsk(null)} footer={<><Button onClick={() => setAsk(null)}>Keep plan</Button><Button variant="primary" onClick={() => { setSt('Cancel scheduled'); setAsk(null); flash('Cancelled — ends 25 Jan 2027'); }}>Cancel at period end</Button></>}>You keep access until 25 Jan 2027. Nothing renews after that, and your CVs stay in your account.</Dialog>}
    {ask === 'delete' && <Dialog title="Delete your account?" onClose={() => setAsk(null)} footer={<><Button onClick={() => setAsk(null)}>Keep my account</Button><Button variant="danger" disabled={!sure} onClick={() => { setAsk(null); flash('Account scheduled for deletion'); }}>Delete everything</Button></>}>
      <p style={{ margin:'0 0 14px', color:'var(--text-muted)', lineHeight:1.55 }}>This removes your Base CV, every version, job CVs, applications and answers. It can’t be undone. Export your data first if you want a copy.</p>
      <Checkbox checked={sure} onChange={setSure} label="I understand this can’t be undone" />
    </Dialog>}
  </div>;
}
Object.assign(window, { PlansScreen, CheckoutScreen, AccountScreen });
