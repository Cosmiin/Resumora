const RZ_PHONES = [
  { group:'Onboarding', note:'Compact step header with progress; one column; actions at the bottom of the flow.', items:[['onb','welcome','Welcome','UX01'],['onb','account','Create account','UX02'],['onb','import','Import CV','UX03'],['onb','review','Check details','UX05']] },
  { group:'Everyday', note:'Bottom tab bar (5 destinations, 58px targets). LinkedIn check sits in the header.', items:[['app','home','Home','UX01'],['app','base','Base CV · edit','UX06'],['app','base/Review','Base CV · review','UX06'],['app','enrich','Improve profile','UX08'],['app','applications','Applications','UX20'],['app','application','Application','UX20']] },
  { group:'Job flow', note:'No tabs inside the flow. “Step n of 5” + progress replaces the stepper; preview stacks under the editor.', items:[['app','addjob','Add a job','UX09'],['app','requirements','Requirements','UX10'],['app','match','Match report','UX11'],['app','compare','Review changes','UX13'],['app','preview','Template & download','UX16']] },
  { group:'Account, sign-in & system', note:'System and sign-in pages keep only the logo — no tabs — and one clear next step.', items:[['app','account','Account','UX18'],['app','checkout/Pending','Checkout · pending','UX17'],['app','login/Wrong%20password','Log in · error','AUTH01'],['app','notfound','Page not found','SYS01'],['app','offline','Offline','SYS03']] },
];
function MobileBoard() {
  const { Logo } = ONB_DS;
  return <div style={{ position:'absolute', left:0, top:0, padding:'80px 90px 120px', display:'grid', gap:90, fontFamily:'var(--font-sans)', color:'var(--text-body)' }}>
    <header style={{ display:'grid', gap:14, maxWidth:900 }}>
      <Logo size={34} />
      <h1 style={{ margin:0, font:'700 3.4rem/1.05 var(--font-display)', letterSpacing:'-0.045em', color:'var(--text-strong)' }}>Mobile screens</h1>
      <p style={{ margin:0, fontSize:'1.15rem', lineHeight:1.6, color:'var(--text-muted)', maxWidth:820 }}>Below 760px the app switches to bottom tabs, a compact step header, stacked content and 44px+ touch targets. Every phone here is the live app — tap through it. The same layout appears when the real app is opened on a narrow screen.</p>
    </header>
    {RZ_PHONES.map(g => <section key={g.group} data-screen-label={g.group} style={{ display:'grid', gap:28 }}>
      <div style={{ display:'grid', gap:6 }}><h2 style={{ margin:0, font:'700 2rem/1.1 var(--font-display)', letterSpacing:'-0.035em', color:'var(--text-strong)' }}>{g.group}</h2><div style={{ fontSize:'1rem', color:'var(--text-muted)' }}>{g.note}</div></div>
      <div style={{ display:'flex', gap:56, alignItems:'flex-start' }}>{g.items.map(([kind, init, name, id]) => <div key={init} style={{ display:'grid', gap:16, flex:'none' }}>
        <div style={{ display:'flex', gap:10, alignItems:'baseline' }}><span style={{ font:'600 .9rem var(--font-mono, monospace)', color:'var(--pine-700)' }}>{id}</span><b style={{ fontSize:'1.15rem', fontWeight:650, color:'var(--text-strong)' }}>{name}</b></div>
        <IOSDevice>{kind === 'onb' ? <OnboardingApp embed initial={init} /> : <ResumoraApp embed initial={init} />}</IOSDevice>
      </div>)}</div>
    </section>)}
  </div>;
}
ReactDOM.createRoot(document.getElementById('root')).render(<MobileBoard />);
