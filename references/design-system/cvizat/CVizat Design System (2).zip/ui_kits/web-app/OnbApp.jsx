function OnboardingApp({ initial, embed }) {
  const { TopBar, Stepper, IconButton, Button, Logo, Toast } = ONB_DS;
  const mobile = rzUseMobile(embed);
  const saved = embed ? {} : JSON.parse(localStorage.getItem('rz-onb') || '{}');
  const ONB_ALL = ['welcome','account','verify','goals','import','reading','review','ready'];
  const fromHash = () => { const h = location.hash.replace(/^#\/?/, ''); return ONB_ALL.includes(h) ? h : null; };
  const [screen, setScreenRaw] = React.useState(initial || fromHash() || saved.screen || 'welcome');
  const mainRef = React.useRef(null);
  React.useEffect(() => { if (embed) return; const f = () => { const h = fromHash(); if (h) { setScreenRaw(h); window.scrollTo(0, 0); } }; window.addEventListener('hashchange', f); return () => window.removeEventListener('hashchange', f); }, []);
  const [acct, setAcct] = React.useState(saved.acct || { name:'', email:'', pw:'', terms:false });
  const [goals, setGoals] = React.useState(saved.goals || { where:'ro', target:'' });
  const [file, setFile] = React.useState(null);
  const [manual, setManual] = React.useState(false);
  const [flags, setFlags] = React.useState({ scanned:false, fail:false });
  const [notice, setNotice] = React.useState(null);
  const [toast, setToast] = React.useState(null);
  const setScreen = s => { setScreenRaw(s); if (mainRef.current) mainRef.current.scrollTop = 0; if (!embed) window.scrollTo(0, 0); };
  React.useEffect(() => { if (!embed) localStorage.setItem('rz-onb', JSON.stringify({ screen, acct:{ ...acct, pw:'' }, goals })); }, [screen, acct, goals]);
  const stepOf = { account:0, verify:0, goals:1, import:2, reading:2, review:3 };
  const steps = ['Account','Your search','Your CV','Check details'];
  const top = embed ? 44 : 0, px = mobile ? 16 : 44;
  const login = () => { if (!embed) location.href = 'app.html#/login'; };
  const demo = !embed && <OnbDemoBar screen={screen} setScreen={setScreen} flags={flags} setFlags={setFlags} />;
  const root = { height: mobile ? (embed ? '100%' : '100dvh') : undefined, minHeight: mobile ? undefined : '100vh', display:'flex', flexDirection:'column', background:'var(--surface-page)', fontFamily:'var(--font-sans)', color:'var(--text-body)', textAlign:'left', transform: embed ? 'translateZ(0)' : undefined, overflow: mobile ? 'hidden' : undefined };
  const mainStyle = pad => ({ flex:1, padding:pad, overflowY: mobile ? 'auto' : undefined, minHeight:0 });
  if (screen === 'welcome') return <div style={root}><div ref={mainRef} style={{ ...mainStyle(0), paddingTop:top }}><OnbWelcome mobile={mobile} onStart={() => setScreen('account')} onLogin={login} /></div>{demo}</div>;
  if (screen === 'ready') return <div style={root}>
    <header style={{ padding:(top + 20) + 'px ' + px + 'px 0' }}><Logo size={30} /></header>
    <main ref={mainRef} style={mainStyle('12px ' + px + 'px 60px')}><OnbReady name={acct.name} onFirstJob={() => { if (!embed) location.href = 'app.html#/addjob'; }} /></main>
    {toast && <Toast icon="shield-check">{toast}</Toast>}{demo}
  </div>;
  const signedIn = stepOf[screen] >= 1;
  return <div style={root}>
    {mobile ? <RzMobileHead top={top} onClose={() => setScreen('welcome')} eyebrow={`Set up Resumora · step ${stepOf[screen] + 1} of 4`} title={steps[stepOf[screen]]} progress={[stepOf[screen] + 1, 4]} right={signedIn ? <Button size="sm" variant="ghost" onClick={() => setScreen('welcome')}>Later</Button> : null} />
    : <TopBar back={<><IconButton icon="x" label="Exit" onClick={() => setScreen('welcome')} /><Logo variant="mark" size={28} /></>} title="Set up Resumora" right={signedIn ? <Button size="sm" onClick={() => setScreen('welcome')}>Finish later</Button> : null}>
      <Stepper steps={steps} current={stepOf[screen]} onStepClick={i => setScreen(['account','goals','import','review'][i])} />
    </TopBar>}
    <main ref={mainRef} style={mainStyle(mobile ? '24px 16px 48px' : '40px 44px 80px')}>
      {screen === 'account' && <OnbAccount data={acct} set={p => setAcct(a => ({ ...a, ...p }))} onNext={() => setScreen('verify')} onLogin={login} />}
      {screen === 'verify' && <OnbVerify email={acct.email} onNext={() => setScreen('goals')} onChange={() => setScreen('account')} />}
      {screen === 'goals' && <OnbGoals data={{ ...goals, name:acct.name }} set={p => setGoals(g => ({ ...g, ...p }))} onNext={() => setScreen('import')} onBack={() => setScreen('verify')} />}
      {screen === 'import' && <OnbImport flags={flags} file={file} setFile={f => { setFile(f); setNotice(null); }} notice={notice} onRead={() => { setManual(false); setScreen('reading'); }} onManual={() => { setManual(true); setScreen('review'); }} onBack={() => setScreen('goals')} />}
      {screen === 'reading' && <OnbReading flags={flags} fileName={file && file.name} onDone={() => setScreen('review')} onCancel={() => { setNotice('Stopped. Nothing was saved — choose a file when you’re ready.'); setScreen('import'); }} />}
      {screen === 'review' && <OnbReview acct={acct} goals={goals} manual={manual} onBack={() => setScreen('import')} onSave={f => { setAcct(a => ({ ...a, name:f.name })); setScreen('ready'); setToast('Saved — Base CV v1'); setTimeout(() => setToast(null), 2800); }} />}
    </main>
    {demo}
  </div>;
}
window.OnboardingApp = OnboardingApp;
if (!window.RZ_EMBED_PAGE) ReactDOM.createRoot(document.getElementById('root')).render(<OnboardingApp />);
