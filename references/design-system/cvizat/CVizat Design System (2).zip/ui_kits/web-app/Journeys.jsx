function JourneysGuide() {
  const { Logo, Pill, Icon, Button } = ONB_DS;
  const J = RZ_JOURNEYS;
  const h2 = { margin:0, font:'700 1.7rem/1.15 var(--font-display)', letterSpacing:'-0.035em', color:'var(--text-strong)' };
  const label = { font:'700 .7rem var(--font-sans)', letterSpacing:'.12em', textTransform:'uppercase', color:'var(--text-muted)' };
  const idx = Object.entries(RZ_ROUTES).map(([r, x]) => ({ id:x.id, name:x.name, j:x.journeys.join(' · '), states:x.states, href:RZ_HREF(r) }))
    .concat(RZ_ONB.map(o => ({ id:o.id, name:o.name, j:'A', states:['—'], href:RZ_HREF('onb:' + o.r), onb:true })))
    .sort((a, b) => a.id.localeCompare(b.id));
  return <div style={{ maxWidth:1240, margin:'0 auto', padding:'28px 44px 80px', display:'grid', gap:40 }}>
    <header style={{ display:'flex', justifyContent:'space-between', alignItems:'center', gap:12, flexWrap:'wrap' }}><Logo size={28} /><div style={{ display:'flex', gap:8, flexWrap:'wrap' }}><Button size="sm" href="onboarding.html#/welcome" icon="door-open">Onboarding flow</Button><Button size="sm" href="mobile.html" icon="smartphone">Mobile screens</Button><Button size="sm" variant="primary" href="app.html" iconRight="arrow-right">Open the app</Button></div></header>
    <section style={{ display:'grid', gap:18 }}>
      <div style={{ font:'750 .73rem var(--font-sans)', letterSpacing:'.14em', textTransform:'uppercase', color:'var(--text-accent)' }}>Design guide · from research/ux</div>
      <h1 style={{ margin:0, font:'700 3rem/1.05 var(--font-display)', letterSpacing:'-0.045em', color:'var(--text-strong)', maxWidth:760, textWrap:'balance' }}>Customer journeys</h1>
      <p style={{ margin:0, color:'var(--text-muted)', fontSize:'1.02rem', lineHeight:1.6, maxWidth:680, textWrap:'pretty' }}>Nine journeys cover the whole product — from the first visit to a sent application, plus signing back in and what happens when something breaks. Every stage links to the screen in the prototype. In the app, the bar above each screen shows its ID, its journeys, the states you can switch between and the rules it must follow.</p>
      <nav style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(min(100%,150px),1fr))', gap:8, marginTop:6 }}>{J.map((j, i) => <a key={j.k} href={'#' + j.k} style={{ display:'grid', gap:6, padding:'14px 16px', borderRadius:14, border:'1px solid var(--border-subtle)', background: i === 0 ? 'var(--surface-hero)' : '#fff', textDecoration:'none' }}>
        <span style={{ font:'700 1.4rem/1 var(--font-display)', color:'var(--pine-600)' }}>{j.k}</span><span style={{ fontSize:'.84rem', color:'var(--text-strong)', fontWeight:600, lineHeight:1.35 }}>{j.name}</span></a>)}</nav>
      <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap', fontSize:'.82rem', color:'var(--text-muted)' }}><Icon name="repeat" size={16} color="var(--pine-600)" />The core loop: <b style={{ color:'var(--text-strong)' }}>A</b> once → <b style={{ color:'var(--text-strong)' }}>C → D → E → G</b> for every job, with <b style={{ color:'var(--text-strong)' }}>B</b> between jobs and <b style={{ color:'var(--text-strong)' }}>F</b> at the first download.</div>
    </section>
    {J.map(j => <section key={j.k} id={j.k} data-screen-label={'Journey ' + j.k} style={{ display:'grid', gap:20, paddingTop:32, borderTop:'1px solid var(--border-subtle)', scrollMarginTop:20 }}>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(min(100%,340px),1fr))', gap:'16px 40px', alignItems:'start' }}>
        <div style={{ display:'flex', gap:18, alignItems:'flex-start' }}>
          <div style={{ width:56, height:56, borderRadius:16, background:'var(--pine-600)', color:'#fff', display:'grid', placeItems:'center', font:'700 1.6rem var(--font-display)', flex:'none' }}>{j.k}</div>
          <div style={{ display:'grid', gap:8 }}><h2 style={h2}>{j.name}</h2><div style={{ fontSize:'.84rem', color:'var(--text-muted)' }}>Starts: {j.when}</div><div style={{ font:'500 1.05rem/1.5 var(--font-document)', color:'var(--text-body)', fontStyle:'italic' }}>{j.goal}</div></div>
        </div>
        <div style={{ display:'grid', gap:6, padding:'14px 16px', borderRadius:12, background:'var(--status-good-bg)' }}><span style={{ ...label, color:'var(--status-good-fg)' }}>Done when</span><span style={{ fontSize:'.9rem', color:'var(--text-strong)', lineHeight:1.5 }}>{j.done}</span></div>
      </div>
      <ol style={{ listStyle:'none', margin:0, padding:0, display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(min(100%,210px),1fr))', gap:10 }}>
        {j.stages.map((s, i) => <li key={i} style={{ display:'grid', gridTemplateRows:'auto 1fr auto', gap:10, padding:'14px 16px', borderRadius:14, border:'1px solid var(--border-subtle)', background:'#fff' }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', gap:8 }}><span style={{ display:'flex', gap:8, alignItems:'baseline' }}><span style={{ font:'700 .95rem var(--font-display)', color:'var(--pine-300)' }}>{i + 1}</span><b style={{ fontWeight:650, color:'var(--text-strong)', fontSize:'.92rem' }}>{s.t}</b></span><span style={{ font:'600 .68rem var(--font-mono, monospace)', color:'var(--pine-700)' }}>{s.ux}</span></div>
          <div style={{ display:'grid', gap:8, fontSize:'.82rem', lineHeight:1.5 }}>
            <div><span style={label}>User</span><div style={{ color:'var(--text-body)', marginTop:2 }}>{s.does}</div></div>
            <div><span style={label}>We show</span><div style={{ color:'var(--text-body)', marginTop:2 }}>{s.we}</div></div>
          </div>
          <a href={RZ_HREF(s.r, s.s)} style={{ fontSize:'.8rem', display:'inline-flex', alignItems:'center', gap:4 }}>Open screen{s.s ? ' · ' + s.s : ''} <Icon name="arrow-up-right" size={14} /></a>
        </li>)}
      </ol>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(min(100%,340px),1fr))', gap:16 }}>
        <div style={{ display:'grid', gap:8 }}><span style={label}>When something goes wrong</span>{j.recover.map(r => <div key={r} style={{ display:'flex', gap:8, fontSize:'.86rem', color:'var(--text-body)', lineHeight:1.5 }}><Icon name="corner-down-right" size={16} color="var(--status-warn-fg)" />{r}</div>)}</div>
        <div style={{ display:'grid', gap:8 }}><span style={label}>Rules that must hold</span>{j.rules.map(r => <div key={r} style={{ display:'flex', gap:8, fontSize:'.86rem', color:'var(--text-body)', lineHeight:1.5 }}><Icon name="shield-check" size={16} color="var(--pine-600)" />{r}</div>)}</div>
      </div>
    </section>)}
    <section id="index" style={{ display:'grid', gap:16, paddingTop:32, borderTop:'1px solid var(--border-subtle)' }}>
      <h2 style={h2}>Screen index</h2>
      <div style={{ border:'1px solid var(--border-subtle)', borderRadius:14, overflow:'hidden', background:'#fff' }}>
        {idx.map((x, i) => <a key={x.href} href={x.href} style={{ display:'grid', gridTemplateColumns:'110px minmax(0,1.2fr) 80px minmax(0,2fr)', gap:12, alignItems:'center', padding:'11px 16px', borderTop: i ? '1px solid var(--border-subtle)' : 0, textDecoration:'none', fontWeight:400, color:'var(--text-body)', fontSize:'.84rem' }}>
          <span style={{ font:'600 .74rem var(--font-mono, monospace)', color:'var(--pine-700)' }}>{x.id}</span>
          <span style={{ fontWeight:650, color:'var(--text-strong)' }}>{x.name}{x.onb && <span style={{ fontWeight:400, color:'var(--text-muted)' }}> · onboarding</span>}</span>
          <span style={{ color:'var(--text-muted)' }}>{x.j}</span>
          <span style={{ display:'flex', gap:4, flexWrap:'wrap' }}>{x.states.map(s => s === '—' ? null : <Pill key={s} size="sm" shape="round">{s}</Pill>)}</span>
        </a>)}
      </div>
      <p style={{ margin:0, fontSize:'.8rem', color:'var(--text-muted)', lineHeight:1.55, maxWidth:760 }}>Source: research/ux/journeys.md, screen-specifications.md and docs/product/prd.md §15–16. Synthetic data (Mara Ionescu · Northstar People). Scores are illustrative and uncalibrated; prices are placeholders.</p>
    </section>
  </div>;
}
ReactDOM.createRoot(document.getElementById('root')).render(<JourneysGuide />);
