window.RZ_APP = {
  base:{ name:'Mara Ionescu', t1:'Business Systems Analyst', t2:'', email:'mara.ionescu@example.ro', phone:'', city:'Cluj-Napoca',
    summary:'Analyst with 6 years in HR operations and process improvement.',
    pro:['Process automation','Requirements analysis','Gestionarea părților interesate'], tech:['SQL','Excel','REST APIs'],
    roles:[
      { id:'r1', title:'Systems Analyst', company:'BridgeWorks', city:'Cluj-Napoca', start:{ y:'2021', m:'' }, current:true, end:{ y:'', m:'' }, context:'Internal systems team supporting finance and HR across 3 offices.', bullets:['Mapped approval workflows with stakeholders across finance and HR.','Wrote SQL reports used in monthly payroll reconciliation.','Responsible for payroll exports via REST APIs for 3 HR teams.'] },
      { id:'r2', title:'HR Operations Specialist', company:'Carpatia Retail', city:'Cluj-Napoca', start:{ y:'2019', m:'3' }, current:false, end:{ y:'2021', m:'' }, context:'HR team of 6 for a retail chain.', bullets:['Coordinated onboarding for 40+ hires per quarter.','Responsible for HR reporting.'] }],
    edu:'BSc Economic Informatics — Babeș-Bolyai University, 2013 — 2016',
    langs:'Romanian — native · English — C1 (Cambridge CAE)',
    sections:[{ k:'summary', label:'Summary', on:true },{ k:'experience', label:'Experience', on:true },{ k:'skills', label:'Skills', on:true },{ k:'education', label:'Education', on:true },{ k:'languages', label:'Languages', on:true }] },
  versions:[
    { v:3, date:'23 Oct 2026, 14:10', why:'Confirmed an answer', detail:'Added the outcome of the approval workflow at BridgeWorks.', summary:'Analyst with 6 years in HR operations and process improvement.' },
    { v:2, date:'20 Oct 2026, 09:42', why:'Edited', detail:'Split skills into professional and technical. Added English level.', summary:'Analyst with 6 years in HR operations and process improvement.' },
    { v:1, date:'18 Oct 2026, 18:05', why:'Imported', detail:'From Mara_Ionescu_CV_2026.pdf — every section confirmed.', summary:'HR and systems analyst.' }],
  questions:[
    { id:'e1', section:'BridgeWorks · Systems Analyst', q:'What changed after you automated the payroll exports?', help:'Your own result. Qualitative is fine. If it wasn’t measured, say so — we won’t add a number.', chips:['It wasn’t measured','No more manual file uploads','Fewer errors at month end'], before:'Responsible for payroll exports via REST APIs for 3 HR teams.', after:'Automated payroll exports via REST APIs for 3 HR teams, replacing manual file uploads.' },
    { id:'e2', section:'BridgeWorks · Systems Analyst', q:'What happened to approval requests after the new workflow?', help:'Think of what people noticed — speed, fewer lost requests, less chasing.', chips:['Requests stopped getting lost','Less chasing by email','It wasn’t measured'], before:null, after:'Replaced manual approval emails with a tracked workflow, so requests no longer got lost.' },
    { id:'e3', section:'Carpatia Retail · HR Operations', q:'Which HR reports did you own, and who used them?', help:'Name the reports and the people who relied on them.', chips:['Monthly headcount','Turnover','Store managers used them'], before:'Responsible for HR reporting.', after:'Built monthly headcount and turnover reports for store managers.' },
    { id:'e4', section:'Titles', q:'Is there a second kind of role you apply for?', help:'Shown under your name as a positioning title. It never changes your past job titles.', chips:['Process Automation Specialist','HRIS Analyst'], before:null, after:null }],
  reqs:[
    { id:'q1', text:'Process automation', src:'“…to automate HR and payroll workflows.”', cat:'Responsibilities', pri:'req' },
    { id:'q2', text:'SQL', src:'“Required: process automation, SQL, REST APIs…”', cat:'Tools', pri:'req' },
    { id:'q3', text:'REST APIs', src:'“Required: process automation, SQL, REST APIs…”', cat:'Tools', pri:'req' },
    { id:'q4', text:'Stakeholder management', src:'“…stakeholder management…”', cat:'Professional skills', pri:'req' },
    { id:'q5', text:'4+ years in business or systems analysis', src:'“4+ years in business/systems analysis”', cat:'Experience', pri:'req' },
    { id:'q6', text:'Right to work in Romania', src:'“…right to work in Romania.”', cat:'Eligibility', pri:'req', gate:true },
    { id:'q7', text:'HRIS: Workday or SAP SuccessFactors', src:'“Nice to have: HRIS experience (Workday or SAP SuccessFactors)”', cat:'Domain', pri:'pref', or:true },
    { id:'q8', text:'Power BI', src:'“…Power BI.”', cat:'Tools', pri:'pref' }],
  apps:[
    { id:'a1', role:'Business Systems Analyst — Automation', company:'Northstar People', stage:'To send', cv:'Not tailored yet', tailored:false, next:'See your match and tailor your CV', date:'' },
    { id:'a2', role:'Process Analyst', company:'Lumen Bank', stage:'Interview', cv:'Tailored CV v2', tailored:true, next:'Interview with the team', date:'28 Oct' },
    { id:'a3', role:'HRIS Analyst', company:'Carpatia Logistics', stage:'Sent', cv:'Tailored CV v1', tailored:true, next:'Follow up with the recruiter', date:'30 Oct' },
    { id:'a4', role:'Business Analyst', company:'Orbit Soft', stage:'Closed', cv:'Base CV v2', tailored:false, next:'—', date:'' }],
  linkedin:'Business Systems Analyst | Process automation · SQL · Power BI\n\nI help HR and finance teams replace manual work with simple, reliable workflows. Skills: Requirements analysis, Stakeholder management, Agile, Workday.',
  li:{ both:['Process automation','SQL','Requirements analysis','Stakeholder management'], onlyLi:['Power BI','Agile','Workday'], onlyCv:['REST APIs','Payroll systems','Excel'] },
};
