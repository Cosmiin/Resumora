function EnrichScreen({ state, go, flash }) {
  const { Card, Button, Field, Checkbox, RadioGroup, Pill, ProgressBar, EmptyState, Icon } = ONB_DS;
  const Q = RZ_APP.questions;
  const [cur, setCur] = React.useState(0);
  const [st, setSt] = React.useState({});
  const [ans, setAns] = React.useState({});
  const [step, setStep] = React.useState('ask');
  const [ok, setOk] = React.useState(false);
  const [dest, setDest] = React.useState('base');
  const [ver, setVer] = React.useState(3);
  if (state === 'Nothing to ask') return <div style={{ maxWidth:640, margin:'40px auto' }}><EmptyState icon="circle-check" title="Nothing to ask right now" actions={<Button variant="primary" iconRight="arrow-right" onClick={() => go('addjob')}>Add a job</Button>}>Your Base CV covers every section. When a job needs something your CV doesn’t say, we’ll ask about it then.</EmptyState></div>;
  const q = Q[cur], a = ans[q.id] || '';
  const answered = Object.values(st).filter(x => x === 'done').length, handled = Object.keys(st).length;
  const advance = (id, v) => { const nst = { ...st, [id]:v }; setSt(nst); const n = Q.findIndex(x => !nst[x.id]); if (n >= 0) setCur(n); setStep('ask'); setOk(false); setDest('base'); };
  const after = q.after || a.trim();
  const allDone = handled === Q.length;
  return <div style={{ maxWidth:1080, margin:'0 auto', display:'grid', gap:22 }}>
    <OnbTitle title="Improve your profile">A few questions about things your CV doesn’t say yet. Answer what you know — skip the rest. Nothing is added until you confirm it.</OnbTitle>
    <ProgressBar value={handled} max={Q.length} label="Questions" valueLabel={`${answered} answered · ${handled - answered} skipped · ${Q.length - handled} left`} />
    <div style={{ display:'flex', flexWrap:'wrap', gap:24, alignItems:'flex-start' }}>
      <Card padding="none" style={{ flex:'1 1 260px', width:'auto' }}>{Q.map((x, i) => { const s = st[x.id]; return <button key={x.id} onClick={() => { setCur(i); setStep('ask'); setOk(false); }} style={{ width:'100%', display:'flex', gap:12, alignItems:'flex-start', padding:'14px 18px', border:0, borderTop: i ? '1px solid var(--border-subtle)' : 0, background: i === cur && !allDone ? 'var(--pine-50)' : 'transparent', textAlign:'left', cursor:'pointer', font:'inherit' }}>
        <Icon name={s === 'done' ? 'circle-check' : s === 'skip' ? 'circle-minus' : 'circle'} size={18} color={s === 'done' ? 'var(--status-good-fg)' : 'var(--sage-400)'} />
        <span style={{ minWidth:0 }}><span style={{ display:'block', fontSize:'.72rem', fontWeight:700, letterSpacing:'.06em', textTransform:'uppercase', color:'var(--text-muted)' }}>{x.section}</span><span style={{ display:'block', fontSize:'.88rem', color:'var(--text-strong)', marginTop:3, lineHeight:1.45 }}>{x.q}</span></span>
      </button>; })}</Card>
      <div style={{ flex:'2 1 480px', minWidth:0 }}>
        {allDone ? <Card padding="lg"><div style={{ display:'grid', gap:16, justifyItems:'start' }}>
          <OnbIconTile icon="circle-check" />
          <div style={{ font:'700 1.5rem/1.2 var(--font-display)', letterSpacing:'-0.03em', color:'var(--text-strong)' }}>That’s everything for now</div>
          <div style={{ color:'var(--text-muted)', lineHeight:1.6 }}>{answered} answers confirmed. {handled - answered ? `${handled - answered} skipped — they added nothing to your CV.` : ''}</div>
          <div style={{ display:'flex', gap:10, flexWrap:'wrap' }}><Button variant="primary" iconRight="arrow-right" onClick={() => go('base')}>See my Base CV</Button><Button icon="history" onClick={() => go('history')}>Version history</Button></div>
        </div></Card> : <Card padding="lg"><div style={{ display:'grid', gap:18 }}>
          <div style={{ display:'flex', justifyContent:'space-between', gap:10, flexWrap:'wrap', alignItems:'center' }}>
            <span style={{ font:'750 .73rem var(--font-sans)', letterSpacing:'.14em', textTransform:'uppercase', color:'var(--text-accent)' }}>{q.section}</span>
            <Pill size="sm">{step === 'ask' ? 'Step 1 of 2 · Answer' : 'Step 2 of 2 · Confirm'}</Pill>
          </div>
          <h2 style={{ margin:0, font:'700 1.45rem/1.25 var(--font-display)', letterSpacing:'-0.03em', color:'var(--text-strong)', textWrap:'balance' }}>{q.q}</h2>
          {step === 'ask' ? <>
            <Field multiline rows={4} value={a} onChange={v => setAns(s => ({ ...s, [q.id]:v }))} hint={q.help} placeholder="In your own words…" />
            <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>{q.chips.map(c => <button key={c} onClick={() => setAns(s => ({ ...s, [q.id]:(a ? a.replace(/\s*$/, '') + (/[.!?]$/.test(a.trim()) ? ' ' : '. ') : '') + c }))} style={{ border:'1px solid var(--border-subtle)', background:'#fff', borderRadius:999, padding:'6px 12px', font:'600 .8rem var(--font-sans)', color:'var(--text-body)', cursor:'pointer' }}>+ {c}</button>)}</div>
            <OnbActions back={<Button variant="ghost" onClick={() => advance(q.id, 'skip')}>I don’t know · skip</Button>}>
              <Button variant="primary" iconRight="arrow-right" disabled={a.trim().length < 3} onClick={() => setStep('review')}>Review</Button>
            </OnbActions>
          </> : <>
            <div style={{ display:'grid', gap:6 }}>
              <div style={{ font:'var(--type-label)', color:'var(--text-strong)' }}>What you told us</div>
              <div style={{ padding:'12px 14px', borderRadius:10, background:'var(--sage-50)', color:'var(--text-body)', fontSize:'.9rem', lineHeight:1.55 }}>“{a.trim()}”<div style={{ marginTop:8 }}><Pill size="sm" icon="message-square">Your answer · 25 Oct</Pill></div></div>
            </div>
            <div style={{ display:'grid', gap:6 }}>
              <div style={{ font:'var(--type-label)', color:'var(--text-strong)' }}>{q.before ? 'Proposed wording' : q.after ? 'Proposed new bullet' : 'Second title'}</div>
              <div style={{ display:'grid', gap:8, padding:'12px 14px', borderRadius:10, border:'1px solid var(--border-subtle)', fontSize:'.9rem', lineHeight:1.55 }}>
                {q.before && <div style={{ color:'var(--text-muted)', textDecoration:'line-through' }}>{q.before}</div>}
                <div style={{ color:'var(--text-strong)', background:'var(--marigold-50)', padding:'2px 4px', borderRadius:4 }}>{after}</div>
              </div>
              {/measured/i.test(a) && <div style={{ fontSize:'.8rem', color:'var(--text-muted)' }}>No number added — you said it wasn’t measured.</div>}
            </div>
            <Checkbox variant="card" checked={ok} onChange={setOk} label="This is true and about my own work" description="We’ll use it as a confirmed fact. You can edit or remove it later." />
            <RadioGroup label="Where should it go?" name="dest" direction="row" value={dest} onChange={setDest} options={[{ value:'base', label:'My Base CV', description:'Every future job starts with it.' },{ value:'job', label:'Only the Northstar People CV', description:'Your Base CV stays as it is.' }]} />
            <OnbActions back={<Button variant="ghost" icon="arrow-left" onClick={() => setStep('ask')}>Edit answer</Button>}>
              <Button variant="primary" icon="check" disabled={!ok} onClick={() => { if (dest === 'base') { flash('Saved — Base CV v' + (ver + 1)); setVer(v => v + 1); } else flash('Saved to the Northstar People CV'); advance(q.id, 'done'); }}>{dest === 'base' ? `Save as Base CV v${ver + 1}` : 'Save to this job only'}</Button>
            </OnbActions>
          </>}
        </div></Card>}
      </div>
    </div>
  </div>;
}
window.EnrichScreen = EnrichScreen;
