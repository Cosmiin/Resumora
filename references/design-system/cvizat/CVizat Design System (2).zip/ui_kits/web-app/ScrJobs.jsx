function JobCaptureScreen({ state, go }) {
  const { Card, Button, Field, Segmented, Spinner, Alert, Checkbox, Pill, IconButton } = ONB_DS;
  const D = window.CVZ_DATA;
  const [mode, setMode] = React.useState({ 'Paste':'paste', 'Link blocked':'link', 'Manual':'manual', 'Extension':'ext', 'Parse failed':'paste' }[state]);
  const [text, setText] = React.useState(D.job.ad);
  const [url, setUrl] = React.useState(state === 'Link blocked' ? 'https://www.linkedin.com/jobs/view/3921057' : '');
  const [blocked, setBlocked] = React.useState(state === 'Link blocked');
  const [failed, setFailed] = React.useState(state === 'Parse failed');
  const [busy, setBusy] = React.useState(false);
  const [title, setTitle] = React.useState(D.job.title);
  const [company, setCompany] = React.useState(D.job.company);
  const [reqs, setReqs] = React.useState([{ t:'Process automation', p:'req' },{ t:'SQL', p:'req' },{ t:'Power BI', p:'pref' }]);
  const [cap, setCap] = React.useState(false);
  const [consent, setConsent] = React.useState(false);
  const urlOk = /^https:\/\/.+\..+/.test(url);
  const ready = mode === 'paste' ? text.trim().length >= 30 : mode === 'link' ? urlOk : mode === 'manual' ? !!title.trim() && reqs.some(r => r.t.trim()) : false;
  const run = () => { if (mode === 'link' && /linkedin\.com/.test(url)) { setBlocked(true); return; } setBusy(true); setTimeout(() => go('requirements'), 1300); };
  if (busy) return <Card style={{ maxWidth:640, margin:'40px auto', textAlign:'center' }}><div style={{ padding:'40px 0' }}><Spinner label="Reading the job ad and finding its requirements…" /><div style={{ marginTop:18 }}><Button variant="ghost" size="sm" onClick={() => setBusy(false)}>Cancel</Button></div></div></Card>;
  return <div style={{ maxWidth:720, margin:'0 auto', display:'grid', gap:20 }}>
    <OnbTitle title="Which job are you applying for?">We only read what you give us. Nothing is sent to the employer.</OnbTitle>
    <Card><div style={{ display:'grid', gap:20 }}>
      <div style={{ overflowX:'auto', minWidth:0 }}><Segmented fullWidth value={mode} onChange={m => { setMode(m); setBlocked(false); }} options={[{ value:'paste', label:'Paste' },{ value:'link', label:'Link' },{ value:'manual', label:'Type it in' },{ value:'ext', label:'Browser' }]} /></div>
      {mode === 'paste' && <>
        {failed && <Alert tone="bad" title="We couldn’t find the requirements" action={<Button size="sm" variant="primary" icon="rotate-cw" onClick={() => { setFailed(false); run(); }}>Try again</Button>}>Your text is still here. Check it includes the requirements — or <a href="#" onClick={e => { e.preventDefault(); setMode('manual'); }}>type them in</a>.</Alert>}
        <Field label="Job ad" multiline rows={9} maxLength={6000} value={text} onChange={setText} hint="Copy the whole ad, including the requirements." error={text.length > 0 && text.trim().length < 30 ? 'Paste a bit more — at least a few sentences.' : undefined} />
      </>}
      {mode === 'link' && <>
        <Field label="Link to the job ad" icon="link" type="url" value={url} onChange={v => { setUrl(v); setBlocked(false); }} placeholder="https://www.ejobs.ro/…" hint="Public pages only. We never sign in for you." error={url && !/^https:\/\//.test(url) ? 'Use the full link, starting with https://' : undefined} success={urlOk && !blocked ? 'Looks like a valid link' : undefined} />
        {blocked && <Alert tone="warn" title="This page needs a login" action={<Button size="sm" variant="primary" icon="clipboard-paste" onClick={() => { setMode('paste'); setBlocked(false); }}>Paste instead</Button>}>We can’t open pages behind a login. Copy the ad text from the page and paste it — it takes a few seconds.</Alert>}
      </>}
      {mode === 'manual' && <div style={{ display:'grid', gap:12 }}>
        <div style={{ font:'var(--type-label)', color:'var(--text-strong)' }}>Requirements</div>
        {reqs.map((r, i) => <div key={i} style={{ display:'flex', gap:8, alignItems:'center', flexWrap:'wrap' }}>
          <div style={{ flex:'1 1 220px' }}><Field size="sm" value={r.t} onChange={v => setReqs(x => x.map((y, k) => k === i ? { ...y, t:v } : y))} placeholder="e.g. SQL" /></div>
          <Segmented size="sm" value={r.p} onChange={v => setReqs(x => x.map((y, k) => k === i ? { ...y, p:v } : y))} options={[{ value:'req', label:'Required' },{ value:'pref', label:'Nice to have' }]} />
          <IconButton size="sm" variant="ghost" icon="trash-2" label="Remove" onClick={() => setReqs(x => x.filter((_, k) => k !== i))} />
        </div>)}
        <div><Button size="sm" variant="ghost" icon="plus" onClick={() => setReqs(x => [...x, { t:'', p:'req' }])}>Add requirement</Button></div>
      </div>}
      {mode === 'ext' && <div style={{ display:'grid', gap:14 }}>
        <div style={{ display:'flex', gap:8, alignItems:'center', flexWrap:'wrap' }}><Pill size="sm" tone="info" icon="flask-conical">Concept · not available yet</Pill></div>
        <OnbPromise items={[['mouse-pointer-click','Open the ad and click the Resumora button','We capture only the page you’re on — never your history, cookies or other tabs.'],['eye','You see exactly what we’d send','Edit it or cancel before anything leaves your browser.']]} />
        {!cap ? <div><Button icon="scan-text" onClick={() => setCap(true)}>Simulate capture</Button></div> : <>
          <div style={{ padding:'12px 14px', borderRadius:10, background:'var(--sage-50)', border:'1px solid var(--border-subtle)', fontSize:'.82rem', lineHeight:1.55, color:'var(--text-body)', whiteSpace:'pre-wrap', maxHeight:150, overflow:'auto' }}><b style={{ display:'block', marginBottom:6, color:'var(--text-strong)' }}>From ejobs.ro · Northstar People</b>{D.job.ad}</div>
          <Checkbox checked={consent} onChange={setConsent} label="Send only this text to Resumora" />
          <div><Button variant="primary" icon="check" disabled={!consent} onClick={() => { setMode('paste'); setCap(false); setConsent(false); }}>Use this text</Button></div>
        </>}
      </div>}
      {mode !== 'ext' && <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(min(100%,220px),1fr))', gap:16 }}><Field label="Job title" icon="briefcase" value={title} onChange={setTitle} optional={mode !== 'manual'} error={mode === 'manual' && !title.trim() ? 'Add the job title.' : undefined} /><Field label="Company" icon="building-2" value={company} onChange={setCompany} optional /></div>}
    </div></Card>
    {mode !== 'ext' && <div style={{ display:'flex', justifyContent:'flex-end' }}><Button variant="primary" size="lg" iconRight="arrow-right" disabled={!ready} onClick={run}>{mode === 'manual' ? 'Continue' : 'Read the job ad'}</Button></div>}
  </div>;
}
function RequirementsScreen({ state, go }) {
  const { Card, Button, Segmented, Pill, Alert, Select, EmptyState } = ONB_DS;
  const [rq, setRq] = React.useState(RZ_APP.reqs);
  const [changed, setChanged] = React.useState(false);
  if (state === 'No Base CV') return <div style={{ maxWidth:640, margin:'40px auto' }}><EmptyState icon="file-user" title="First, bring your CV" actions={<Button variant="primary" icon="file-up" href="onboarding.html#/import">Bring my CV</Button>}>We compare the job with your confirmed Base CV. It takes about 5 minutes, and the job is saved for when you’re back.</EmptyState></div>;
  const nReq = rq.filter(r => r.pri === 'req' && !r.gate).length, nPref = rq.filter(r => r.pri === 'pref').length;
  return <div style={{ maxWidth:1120, margin:'0 auto', display:'grid', gap:20 }}>
    <OnbTitle title="Check what the job asks for">We sorted the ad into requirements. Fix anything we got wrong — it changes how your match is weighed.</OnbTitle>
    <div style={{ display:'flex', flexWrap:'wrap', gap:24, alignItems:'flex-start' }}>
      <div style={{ flex:'2 1 480px', display:'grid', gap:14, minWidth:0 }}>
        {changed && <Alert tone="info" title="Changed">We’ll use your version when we calculate the match.</Alert>}
        <Card padding="none">{rq.map((r, i) => <div key={r.id} style={{ display:'flex', gap:16, alignItems:'center', justifyContent:'space-between', flexWrap:'wrap', padding:'16px 20px', borderTop: i ? '1px solid var(--border-subtle)' : 0, background: r.gate ? 'var(--status-warn-bg)' : 'transparent' }}>
          <div style={{ minWidth:0, flex:'1 1 260px' }}>
            <div style={{ display:'flex', gap:8, alignItems:'center', flexWrap:'wrap' }}><b style={{ fontWeight:650, color:'var(--text-strong)' }}>{r.text}</b><Pill size="sm">{r.cat}</Pill>{r.or && <Pill size="sm" tone="info">Either one counts</Pill>}</div>
            <div style={{ fontSize:'.8rem', color:'var(--text-muted)', marginTop:4, fontStyle:'italic' }}>{r.src}</div>
          </div>
          {r.gate ? <Pill tone="warn" icon="shield-alert">Must-have · checked separately</Pill> : <Segmented size="sm" value={r.pri} onChange={v => { setRq(x => x.map(y => y.id === r.id ? { ...y, pri:v } : y)); setChanged(true); }} options={[{ value:'req', label:'Required' },{ value:'pref', label:'Nice to have' }]} />}
        </div>)}</Card>
        <Alert tone="neutral" icon="info">Must-haves like the right to work never raise or lower your score. We’ll keep reminding you until it’s answered.</Alert>
      </div>
      <div style={{ position:'sticky', top:20, display:'grid', gap:16, flex:'1 1 260px' }}>
        <Card padding="sm"><div style={{ display:'grid', gap:14 }}>
          <div><div style={{ fontWeight:650, color:'var(--text-strong)' }}>Northstar People</div><div style={{ fontSize:'.84rem', color:'var(--text-muted)', marginTop:2 }}>Business Systems Analyst — Automation · Bucharest · hybrid</div></div>
          <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}><Pill size="sm">{nReq} required</Pill><Pill size="sm">{nPref} nice to have</Pill><Pill size="sm" tone="warn">1 must-have</Pill></div>
          <Select label="Compare with" icon="file-user" defaultValue="v3" options={[{ value:'v3', label:'Base CV v3', description:'Current · 23 Oct' },{ value:'v2', label:'Base CV v2', description:'20 Oct' }]} />
          <Button variant="primary" size="lg" fullWidth iconRight="arrow-right" onClick={() => go('match')}>Check my match</Button>
          <Button variant="ghost" size="sm" icon="pencil" onClick={() => go('addjob')}>Edit the job ad</Button>
        </div></Card>
      </div>
    </div>
  </div>;
}
Object.assign(window, { JobCaptureScreen, RequirementsScreen });
