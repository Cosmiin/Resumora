const RZ_M = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const rzDate = d => d.y ? (d.m ? RZ_M[+d.m - 1] + ' ' + d.y : d.y) : '—';
function rzDur(r) {
  const asOf = 2026 * 12 + 10, s = r.start, e = r.end;
  if (!s.y || (!r.current && !e.y)) return null;
  const sE = +s.y * 12 + (s.m ? +s.m : 1), sL = +s.y * 12 + (s.m ? +s.m : 12);
  const eE = r.current ? asOf : +e.y * 12 + (e.m ? +e.m : 1), eL = r.current ? asOf : +e.y * 12 + (e.m ? +e.m : 12);
  const lo = Math.max(0, eE - sL), hi = Math.max(0, eL - sE);
  const f = m => [Math.floor(m / 12) ? Math.floor(m / 12) + ' yr' : '', m % 12 ? m % 12 + ' mo' : ''].filter(Boolean).join(' ') || '0 mo';
  return lo === hi ? f(lo) : f(lo) + ' – ' + f(hi);
}
function rzSections(d) {
  return d.sections.filter(s => s.on).map(s => {
    if (s.k === 'summary') return { title:s.label, text:d.summary };
    if (s.k === 'experience') return { title:s.label, items:d.roles.map(r => ({ heading:r.title + ' — ' + r.company, dates:rzDate(r.start) + ' — ' + (r.current ? 'Present' : rzDate(r.end)), sub:r.city, bullets:r.bullets.filter(b => b.trim()) })) };
    if (s.k === 'skills') return { title:s.label, text:d.pro.join(' · ') + ' — ' + d.tech.join(' · ') };
    if (s.k === 'education') return { title:s.label, text:d.edu };
    return { title:s.label, text:d.langs };
  });
}
function RzAcc({ title, meta, open, onToggle, children }) {
  const { Card, Icon } = ONB_DS;
  return <Card padding="none"><button onClick={onToggle} style={{ width:'100%', display:'flex', alignItems:'center', justifyContent:'space-between', gap:12, padding:'16px 20px', background:'none', border:0, cursor:'pointer', textAlign:'left', font:'inherit' }}>
    <span style={{ display:'flex', alignItems:'center', gap:10, minWidth:0 }}><span style={{ font:'var(--type-section-title)', color:'var(--text-strong)', whiteSpace:'nowrap' }}>{title}</span>{meta || null}</span>
    <Icon name={open ? 'chevron-up' : 'chevron-down'} size={18} color="var(--text-muted)" /></button>
    {open && <div style={{ padding:'0 20px 20px', display:'grid', gap:16 }}>{children}</div>}</Card>;
}
function RzSkillGroup({ label, list, onAdd, onRemove }) {
  const { Pill, Field, Button } = ONB_DS;
  const [v, setV] = React.useState('');
  return <div style={{ display:'grid', gap:8 }}>
    <div style={{ font:'var(--type-label)', color:'var(--text-strong)' }}>{label}</div>
    <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>{list.map((s, i) => <button key={s} onClick={() => onRemove(i)} title="Remove" style={{ background:'none', border:0, padding:0, cursor:'pointer' }}><Pill shape="round" icon="x">{s}</Pill></button>)}</div>
    <div style={{ display:'flex', gap:8, alignItems:'end' }}><div style={{ flex:1 }}><Field size="sm" value={v} onChange={setV} placeholder={'Add a ' + label.toLowerCase().replace(' skills','') + ' skill'} /></div><Button size="sm" icon="plus" disabled={!v.trim()} onClick={() => { onAdd(v.trim()); setV(''); }}>Add</Button></div>
  </div>;
}
function BaseScreen({ state, go, flash }) {
  const { Button, Field, Select, Checkbox, Pill, CVDocument, Segmented, Alert, Icon, IconButton, Card } = ONB_DS;
  const clone = x => JSON.parse(JSON.stringify(x));
  const [d, setD] = React.useState(() => { const x = clone(RZ_APP.base); if (state === 'Unsaved draft' || state === 'Save conflict') x.summary = 'Business systems analyst with 6 years in HR operations and process automation.'; return x; });
  const [past, setPast] = React.useState(state === 'Unsaved draft' || state === 'Save conflict' ? [clone(RZ_APP.base)] : []);
  const [tab, setTab] = React.useState(state === 'Review' ? 'review' : 'edit');
  const [open, setOpen] = React.useState(state === 'Unsaved draft' ? 'summary' : 'exp');
  const [ver, setVer] = React.useState(3);
  const [err, setErr] = React.useState(false);
  const [conflict, setConflict] = React.useState(state === 'Save conflict');
  const dirty = past.length > 0;
  const up = fn => { setPast(p => [...p, d]); setD(x => { const n = clone(x); fn(n); return n; }); setErr(false); };
  const undo = () => { setD(past[past.length - 1]); setPast(p => p.slice(0, -1)); };
  const save = () => { if (d.roles.some(r => r.bullets.some(b => !b.trim()))) { setErr(true); return; } setVer(v => v + 1); setPast([]); flash('Saved — Base CV v' + (ver + 1)); };
  const tog = k => setOpen(o => o === k ? null : k);
  const monthOpts = [{ value:'u', label:'Month unknown' }].concat(RZ_M.map((m, i) => ({ value:String(i + 1), label:m })));
  const checks = [
    ['Content','circle-check','good','Every role has context and 2–3 bullets.',null],
    ['Structure & format','circle-check','good','Standard headings, one column, readable dates.',null],
    ['Job optimization','info','info','Add a job to see which facts to bring forward for it.',['Add a job',() => go('addjob')]],
    ['Writing quality','circle-alert','warn','2 bullets start with “Responsible for”. Lead with what you did and what changed.',['Answer 2 questions',() => go('enrich')]],
    ['Application readiness','circle-alert','warn','No phone number. Most recruiters in Romania call first.',['Add a phone number',() => { setTab('edit'); setOpen('about'); }]]];
  return <div style={{ maxWidth:1240, margin:'0 auto', display:'grid', gap:20 }}>
    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', gap:16, flexWrap:'wrap' }}>
      <div><h1 style={{ margin:0, font:'700 2rem/1.15 var(--font-display)', letterSpacing:'-0.04em', color:'var(--text-strong)' }}>Base CV</h1>
        <div style={{ display:'flex', gap:8, marginTop:10, flexWrap:'wrap' }}><Pill tone="good" icon="shield-check">Confirmed by you</Pill><Pill>v{ver} · saved 23 Oct</Pill>{dirty && <Pill tone="warn" icon="pencil">Unsaved changes</Pill>}</div></div>
      <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}><Button icon="history" onClick={() => go('history')}>History</Button><Button icon="sparkles" onClick={() => go('enrich')}>Improve with questions</Button></div>
    </div>
    <Segmented value={tab} onChange={setTab} options={[{ value:'edit', label:'Edit', icon:'pencil' },{ value:'review', label:'Review', icon:'list-checks' }]} />
    <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(min(100%,440px),1fr))', gap:28, alignItems:'start' }}>
      {tab === 'review' ? <div style={{ display:'grid', gap:12, minWidth:0 }}>
        <p style={{ margin:0, color:'var(--text-muted)', lineHeight:1.6 }}>Five checks on your Base CV. They’re not a score — each one is a next step.</p>
        {checks.map(([t, ic, tone, txt, act]) => <Card key={t} padding="sm"><div style={{ display:'flex', gap:14, alignItems:'flex-start' }}>
          <OnbIconTile icon={ic} tone={tone} size={40} />
          <div style={{ flex:1, minWidth:0 }}><div style={{ fontWeight:650, color:'var(--text-strong)' }}>{t}</div><div style={{ fontSize:'.86rem', color:'var(--text-muted)', marginTop:3, lineHeight:1.5 }}>{txt}</div>
            {act && <div style={{ marginTop:10 }}><Button size="sm" iconRight="arrow-right" onClick={act[1]}>{act[0]}</Button></div>}</div>
        </div></Card>)}
      </div> : <div style={{ display:'grid', gap:12, minWidth:0 }}>
        {conflict && <Alert tone="bad" title="Your Base CV changed somewhere else" action={<Button size="sm" variant="primary" onClick={() => { setConflict(false); setVer(4); }}>Keep mine as a new version</Button>}>Another tab saved v4 while you were editing. Your changes are still here — nothing was overwritten.</Alert>}
        <RzAcc title="About you" open={open === 'about'} onToggle={() => tog('about')} meta={!d.phone && <Pill size="sm" tone="warn">No phone</Pill>}>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(min(100%,200px),1fr))', gap:14 }}>
            <Field label="Full name" value={d.name} onChange={v => up(n => { n.name = v; })} error={!d.name.trim() ? 'Add your name.' : undefined} />
            <Field label="City" optional value={d.city} onChange={v => up(n => { n.city = v; })} />
            <Field label="Title" value={d.t1} onChange={v => up(n => { n.t1 = v; })} hint="Under your name. Not a past job title." />
            <Field label="Second title" optional value={d.t2} onChange={v => up(n => { n.t2 = v; })} hint="Leave empty if you don’t need one." />
            <Field label="Email" type="email" value={d.email} onChange={v => up(n => { n.email = v; })} />
            <Field label="Phone" type="tel" optional value={d.phone} onChange={v => up(n => { n.phone = v; })} placeholder="+40 7xx xxx xxx" />
          </div>
        </RzAcc>
        <RzAcc title="Summary" open={open === 'summary'} onToggle={() => tog('summary')}>
          <Field multiline rows={3} maxLength={400} value={d.summary} onChange={v => up(n => { n.summary = v; })} hint="2–3 sentences: years of experience, what you’re best at, a result." />
        </RzAcc>
        <RzAcc title="Skills" open={open === 'skills'} onToggle={() => tog('skills')} meta={<Pill size="sm">{d.pro.length + d.tech.length}</Pill>}>
          <RzSkillGroup label="Professional skills" list={d.pro} onAdd={s => up(n => { n.pro.push(s); })} onRemove={i => up(n => { n.pro.splice(i, 1); })} />
          <RzSkillGroup label="Technical skills" list={d.tech} onAdd={s => up(n => { n.tech.push(s); })} onRemove={i => up(n => { n.tech.splice(i, 1); })} />
        </RzAcc>
        <RzAcc title="Experience" open={open === 'exp'} onToggle={() => tog('exp')} meta={<Pill size="sm">{d.roles.length} roles</Pill>}>
          {d.roles.map((r, i) => { const endErr = !r.current && r.end.y && r.start.y && +r.end.y < +r.start.y; return <div key={r.id} style={{ display:'grid', gap:14, padding:16, border:'1px solid var(--border-subtle)', borderRadius:12 }}>
            <div style={{ display:'flex', justifyContent:'space-between', gap:8, flexWrap:'wrap', alignItems:'baseline' }}><b style={{ fontWeight:650, color:'var(--text-strong)' }}>{r.title} · {r.company}</b>{rzDur(r) && <span style={{ fontSize:'.78rem', color:'var(--text-muted)' }}>{rzDur(r)} · as of Oct 2026</span>}</div>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(min(100%,160px),1fr))', gap:12 }}>
              <Field size="sm" label="Job title" value={r.title} onChange={v => up(n => { n.roles[i].title = v; })} />
              <Field size="sm" label="Company" value={r.company} onChange={v => up(n => { n.roles[i].company = v; })} />
              <Field size="sm" label="City" optional value={r.city} onChange={v => up(n => { n.roles[i].city = v; })} />
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(min(100%,130px),1fr))', gap:12, alignItems:'end' }}>
              <Select size="sm" label="Start month" value={r.start.m || 'u'} onChange={v => up(n => { n.roles[i].start.m = v === 'u' ? '' : v; })} options={monthOpts} />
              <Field size="sm" label="Start year" type="number" value={r.start.y} onChange={v => up(n => { n.roles[i].start.y = v; })} />
              {!r.current && <Select size="sm" label="End month" value={r.end.m || 'u'} onChange={v => up(n => { n.roles[i].end.m = v === 'u' ? '' : v; })} options={monthOpts} />}
              {!r.current && <Field size="sm" label="End year" type="number" value={r.end.y} onChange={v => up(n => { n.roles[i].end.y = v; })} error={endErr ? 'Ends before it starts.' : undefined} />}
            </div>
            <Checkbox checked={r.current} onChange={v => up(n => { n.roles[i].current = v; })} label="I still work here" />
            <Field size="sm" label="Context" multiline rows={2} value={r.context} onChange={v => up(n => { n.roles[i].context = v; })} hint="One sentence: team, scope or product." />
            <div style={{ display:'grid', gap:8 }}>
              <div style={{ font:'var(--type-label)', color:'var(--text-strong)' }}>Bullets</div>
              {r.bullets.map((b, k) => <div key={k} style={{ display:'flex', gap:6, alignItems:'flex-start' }}><div style={{ flex:1 }}><Field size="sm" value={b} onChange={v => up(n => { n.roles[i].bullets[k] = v; })} placeholder="What you did, and what changed" error={err && !b.trim() ? 'Write something or remove this bullet.' : undefined} /></div><IconButton size="sm" variant="ghost" icon="trash-2" label="Remove bullet" onClick={() => up(n => { n.roles[i].bullets.splice(k, 1); })} /></div>)}
              <div><Button size="sm" variant="ghost" icon="plus" onClick={() => up(n => { n.roles[i].bullets.push(''); })}>Add bullet</Button></div>
            </div>
          </div>; })}
        </RzAcc>
        <RzAcc title="Education" open={open === 'edu'} onToggle={() => tog('edu')}><Field multiline rows={2} value={d.edu} onChange={v => up(n => { n.edu = v; })} /></RzAcc>
        <RzAcc title="Languages" open={open === 'lang'} onToggle={() => tog('lang')}><Field value={d.langs} onChange={v => up(n => { n.langs = v; })} hint="Add how you know the level — a certificate or daily use." /></RzAcc>
        <RzAcc title="Sections & order" open={open === 'order'} onToggle={() => tog('order')}>
          {d.sections.map((s, i) => <div key={s.k} style={{ display:'flex', alignItems:'center', gap:10 }}>
            <div style={{ flex:1 }}><Checkbox checked={s.on} onChange={v => up(n => { n.sections[i].on = v; })} label={s.label} /></div>
            <IconButton size="sm" variant="ghost" icon="arrow-up" label="Move up" disabled={i === 0} onClick={() => up(n => { const [x] = n.sections.splice(i, 1); n.sections.splice(i - 1, 0, x); })} />
            <IconButton size="sm" variant="ghost" icon="arrow-down" label="Move down" disabled={i === d.sections.length - 1} onClick={() => up(n => { const [x] = n.sections.splice(i, 1); n.sections.splice(i + 1, 0, x); })} />
          </div>)}
          <div style={{ fontSize:'.8rem', color:'var(--text-muted)' }}>Hiding a section only changes the document. Its content stays in your history.</div>
        </RzAcc>
        <div style={{ position:'sticky', bottom:16, display:'flex', justifyContent:'space-between', alignItems:'center', gap:12, flexWrap:'wrap', background:'#fff', border:'1px solid var(--border-subtle)', borderRadius:14, padding:'12px 16px', boxShadow:'var(--shadow-toast)' }}>
          <span style={{ fontSize:'.84rem', color:'var(--text-muted)', display:'flex', alignItems:'center', gap:8 }}><Icon name={dirty ? 'pencil' : 'circle-check'} size={16} color={dirty ? 'var(--status-warn-fg)' : 'var(--status-good-fg)'} />{dirty ? 'Draft · saved on this device' : 'All changes saved'}</span>
          <div style={{ display:'flex', gap:8 }}><Button variant="ghost" icon="undo-2" disabled={!dirty} onClick={undo}>Undo</Button><Button variant="primary" icon="save" disabled={!dirty || conflict} onClick={save}>Save as v{ver + 1}</Button></div>
        </div>
      </div>}
      <div style={{ position:'sticky', top:20, display:'grid', gap:10 }}>
        <div style={{ font:'var(--type-label)', color:'var(--text-strong)' }}>Preview</div>
        <CVDocument template="clar" scale={.8} name={d.name} titles={[d.t1, d.t2].filter(Boolean)} contact={[d.city, d.email, d.phone].filter(Boolean).join(' · ')} sections={rzSections(d)} />
      </div>
    </div>
  </div>;
}
function HistoryScreen({ state, go, flash }) {
  const { Button, Card, Pill, CVDocument, Dialog, EmptyState } = ONB_DS;
  const [list, setList] = React.useState(RZ_APP.versions);
  const [sel, setSel] = React.useState(list[0].v);
  const [ask, setAsk] = React.useState(null);
  if (state === 'No versions') return <div style={{ maxWidth:640, margin:'40px auto' }}><EmptyState icon="history" title="No saved versions yet" actions={<Button variant="primary" icon="file-up" href="onboarding.html#/import">Bring your CV</Button>}>Each time you save your Base CV, we keep a copy here. You can look back at any of them, or restore one.</EmptyState></div>;
  const cur = list.find(x => x.v === sel), head = list[0].v;
  const doc = Object.assign(JSON.parse(JSON.stringify(RZ_APP.base)), { summary:cur.summary });
  return <div style={{ maxWidth:1200, margin:'0 auto', display:'grid', gap:20 }}>
    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', gap:12, flexWrap:'wrap' }}>
      <OnbTitle title="Version history">Every save is kept. Restoring an old version adds it as a new one — nothing is lost.</OnbTitle>
      <Button variant="ghost" icon="arrow-left" onClick={() => go('base')}>Back to Base CV</Button>
    </div>
    <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(min(100%,380px),1fr))', gap:28, alignItems:'start' }}>
      <Card padding="none">{list.map((x, i) => <div key={x.v} onClick={() => setSel(x.v)} style={{ display:'flex', gap:14, padding:'16px 20px', cursor:'pointer', borderTop: i ? '1px solid var(--border-subtle)' : 0, background: sel === x.v ? 'var(--pine-50)' : 'transparent' }}>
        <div style={{ font:'700 1rem var(--font-display)', color:'var(--pine-700)', width:34 }}>v{x.v}</div>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ display:'flex', gap:8, alignItems:'center', flexWrap:'wrap' }}><b style={{ fontWeight:650, color:'var(--text-strong)' }}>{x.why}</b>{x.v === head && <Pill size="sm" tone="good">Current</Pill>}</div>
          <div style={{ fontSize:'.84rem', color:'var(--text-muted)', marginTop:3, lineHeight:1.5 }}>{x.detail}</div>
          <div style={{ fontSize:'.76rem', color:'var(--text-muted)', marginTop:6 }}>{x.date}</div>
        </div>
        {x.v !== head && <Button size="sm" icon="rotate-ccw" onClick={e => { e.stopPropagation(); setAsk(x); }}>Restore</Button>}
      </div>)}</Card>
      <div style={{ position:'sticky', top:20, display:'grid', gap:10 }}>
        <div style={{ font:'var(--type-label)', color:'var(--text-strong)' }}>v{cur.v} · {cur.date}</div>
        <CVDocument template="clar" scale={.78} name={doc.name} titles={[doc.t1]} contact={[doc.city, doc.email].join(' · ')} sections={rzSections(doc)} />
      </div>
    </div>
    {ask && <Dialog title={'Restore v' + ask.v + '?'} onClose={() => setAsk(null)} footer={<><Button onClick={() => setAsk(null)}>Cancel</Button><Button variant="primary" onClick={() => { const nv = head + 1; setList(l => [{ v:nv, date:'25 Oct 2026, now', why:'Restored v' + ask.v, detail:'Copy of v' + ask.v + '. v' + head + ' is still in history.', summary:ask.summary }, ...l]); setSel(nv); setAsk(null); flash('Restored — saved as v' + nv); }}>Restore as v{head + 1}</Button></>}>We’ll save a copy of v{ask.v} as v{head + 1}. Your current v{head} stays in history, so you can switch back anytime.</Dialog>}
  </div>;
}
Object.assign(window, { RZ_M, rzDate, rzDur, rzSections, RzAcc, BaseScreen, HistoryScreen });
