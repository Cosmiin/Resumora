function JobEditorScreen({ go, flash }) {
  const { Card, Button, Field, Checkbox, Alert, Pill, IconButton, CVDocument, Dialog } = ONB_DS;
  const C = window.CVZ_DATA.changes;
  const [sum, setSum] = React.useState(C[0].after);
  const [bw, setBw] = React.useState([{ t:C[1].after, on:true },{ t:'Mapped approval workflows with stakeholders across finance and HR.', on:true },{ t:'Wrote SQL reports used in monthly payroll reconciliation.', on:true },{ t:C[2].after, on:true }]);
  const [cr, setCr] = React.useState([{ t:'Coordinated onboarding for 40+ hires per quarter.', on:true },{ t:'Built monthly headcount and turnover reports for store managers.', on:false }]);
  const [sk, setSk] = React.useState([['Process automation',true],['SQL',true],['REST APIs',true],['Requirements analysis',true],['Gestionarea părților interesate',true],['Excel',false]]);
  const [dirty, setDirty] = React.useState(false);
  const [ver, setVer] = React.useState(1);
  const [promo, setPromo] = React.useState(false);
  const [pick, setPick] = React.useState({ sum:true, out:true });
  const ch = f => (...a) => { f(...a); setDirty(true); };
  const move = (set, i, d) => set(x => { const n = [...x]; const [y] = n.splice(i, 1); n.splice(i + d, 0, y); return n; });
  const Bullets = ({ list, set }) => <div style={{ display:'grid', gap:8 }}>{list.map((b, i) => <div key={b.t} style={{ display:'flex', gap:6, alignItems:'flex-start', padding:'10px 12px', borderRadius:10, border:'1px solid var(--border-subtle)', background: b.on ? '#fff' : 'var(--sage-50)' }}>
    <div style={{ flex:1, opacity: b.on ? 1 : .6 }}><Checkbox checked={b.on} onChange={ch(v => set(x => x.map((y, k) => k === i ? { ...y, on:v } : y)))} label={b.t} /></div>
    <IconButton size="sm" variant="ghost" icon="arrow-up" label="Move up" disabled={i === 0} onClick={ch(() => move(set, i, -1))} />
    <IconButton size="sm" variant="ghost" icon="arrow-down" label="Move down" disabled={i === list.length - 1} onClick={ch(() => move(set, i, 1))} />
  </div>)}</div>;
  const sections = [{ title:'Summary', text:sum },{ title:'Experience', items:[{ heading:'Systems Analyst — BridgeWorks', dates:'2021 — Present', sub:'Cluj-Napoca', bullets:bw.filter(b => b.on).map(b => b.t) },{ heading:'HR Operations Specialist — Carpatia Retail', dates:'Mar 2019 — 2021', sub:'Cluj-Napoca', bullets:cr.filter(b => b.on).map(b => b.t) }] },{ title:'Skills', text:sk.filter(s => s[1]).map(s => s[0]).join(' · ') }];
  return <div style={{ maxWidth:1240, margin:'0 auto', display:'grid', gap:20 }}>
    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', gap:16, flexWrap:'wrap' }}>
      <div><h1 style={{ margin:0, font:'700 2rem/1.15 var(--font-display)', letterSpacing:'-0.04em', color:'var(--text-strong)' }}>Edit the Northstar People CV</h1>
        <div style={{ display:'flex', gap:8, marginTop:10, flexWrap:'wrap' }}><Pill icon="git-branch">From Base CV v3</Pill><Pill>Job CV v{ver}</Pill>{dirty && <Pill tone="warn" icon="pencil">Unsaved changes</Pill>}</div></div>
      <Button variant="ghost" icon="arrow-left" onClick={() => go('compare')}>Back to suggestions</Button>
    </div>
    <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(min(100%,440px),1fr))', gap:28, alignItems:'start' }}>
      <div style={{ display:'grid', gap:14, minWidth:0 }}>
        <Alert tone="info" icon="git-branch">Changes here stay in this job’s CV. Your Base CV doesn’t change.</Alert>
        <Card><div style={{ display:'grid', gap:10 }}><div style={{ font:'var(--type-section-title)', color:'var(--text-strong)' }}>Summary</div><Field multiline rows={3} maxLength={400} value={sum} onChange={ch(setSum)} /></div></Card>
        <Card><div style={{ display:'grid', gap:12 }}><div style={{ font:'var(--type-section-title)', color:'var(--text-strong)' }}>BridgeWorks · Systems Analyst</div><div style={{ fontSize:'.8rem', color:'var(--text-muted)' }}>Untick to hide a bullet from this CV. Order it so the most relevant comes first.</div><Bullets list={bw} set={setBw} /></div></Card>
        <Card><div style={{ display:'grid', gap:12 }}><div style={{ font:'var(--type-section-title)', color:'var(--text-strong)' }}>Carpatia Retail · HR Operations</div><Bullets list={cr} set={setCr} /></div></Card>
        <Card><div style={{ display:'grid', gap:12 }}><div style={{ font:'var(--type-section-title)', color:'var(--text-strong)' }}>Skills in this CV</div>
          <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>{sk.map(([t, on], i) => <button key={t} onClick={ch(() => setSk(x => x.map((y, k) => k === i ? [y[0], !y[1]] : y)))} style={{ display:'inline-flex', alignItems:'center', gap:6, padding:'6px 12px', borderRadius:999, cursor:'pointer', font:'600 .8rem var(--font-sans)', border:'1px solid ' + (on ? 'var(--pine-600)' : 'var(--border-subtle)'), background: on ? 'var(--pine-50)' : '#fff', color: on ? 'var(--pine-700)' : 'var(--text-muted)' }}>{on ? '✓' : '+'} {t}</button>)}</div>
        </div></Card>
        <div style={{ position:'sticky', bottom:16, display:'flex', justifyContent:'space-between', alignItems:'center', gap:10, flexWrap:'wrap', background:'#fff', border:'1px solid var(--border-subtle)', borderRadius:14, padding:'12px 16px', boxShadow:'var(--shadow-toast)' }}>
          <Button variant="ghost" icon="upload" onClick={() => setPromo(true)}>Also add to Base CV…</Button>
          <div style={{ display:'flex', gap:8 }}><Button icon="save" disabled={!dirty} onClick={() => { setVer(v => v + 1); setDirty(false); flash('Saved — Job CV v' + (ver + 1) + ' · Base CV unchanged'); }}>Save as job CV v{ver + 1}</Button><Button variant="primary" iconRight="arrow-right" disabled={dirty} onClick={() => go('preview')}>Preview</Button></div>
        </div>
      </div>
      <div style={{ position:'sticky', top:20 }}><CVDocument template="clar" scale={.8} name="Mara Ionescu" titles={['Business Systems Analyst']} contact="Cluj-Napoca · mara.ionescu@example.ro" sections={sections} /></div>
    </div>
    {promo && <Dialog title="Add to your Base CV?" onClose={() => setPromo(false)} footer={<><Button onClick={() => setPromo(false)}>Cancel</Button><Button variant="primary" disabled={!pick.sum && !pick.out} onClick={() => { setPromo(false); flash('Saved — Base CV v4'); }}>Save to Base as v4</Button></>}>
      <p style={{ margin:'0 0 14px', color:'var(--text-muted)', lineHeight:1.55 }}>Choose what every future job should start with. We’ll save Base CV v4 — v3 stays in history.</p>
      <div style={{ display:'grid', gap:10 }}>
        <Checkbox variant="card" checked={pick.sum} onChange={v => setPick(p => ({ ...p, sum:v }))} label="New summary" description={sum} />
        <Checkbox variant="card" checked={pick.out} onChange={v => setPick(p => ({ ...p, out:v }))} label="Outcome bullet at BridgeWorks" description={C[2].after} />
      </div>
    </Dialog>}
  </div>;
}
function PreviewScreen({ state, go, flash, rtw }) {
  const { Card, Button, Select, Checkbox, Alert, Spinner, Pill, CVDocument, Icon } = ONB_DS;
  const [tpl, setTpl] = React.useState('clar');
  const [lang, setLang] = React.useState('en');
  const [show, setShow] = React.useState({ city:true, email:true, phone:true });
  const [ack, setAck] = React.useState(false);
  const [st, setSt] = React.useState('idle');
  const [tries, setTries] = React.useState(0);
  const dl = () => { if (state === 'No plan') { setSt('plan'); return; } setSt('busy'); const t = tries; setTries(t + 1); setTimeout(() => setSt(state === 'Export failed' && t === 0 ? 'failed' : 'done'), 1300); };
  const contact = [show.city && 'Cluj-Napoca', show.email && 'mara.ionescu@example.ro', show.phone && '+40 7xx xxx xxx'].filter(Boolean).join(' · ');
  const T = ({ v, name, desc }) => <Card padding="sm" interactive selected={tpl === v} onClick={() => setTpl(v)}><div style={{ display:'flex', gap:12, alignItems:'center' }}>
    <div style={{ width:38, height:50, borderRadius:3, background:'#fff', border:'1px solid var(--border-subtle)', boxShadow:'var(--shadow-paper)', display:'grid', alignContent:'start', gap:3, padding:5, boxSizing:'border-box', flex:'none' }}>{v === 'contur' && <div style={{ height:7, background:'var(--pine-600)', margin:'-5px -5px 2px' }}></div>}{[90,60,100,80,95].map((w, i) => <div key={i} style={{ height:2, width:w + '%', background:'var(--sage-300)' }}></div>)}</div>
    <div><div style={{ fontWeight:650, color:'var(--text-strong)', fontFamily: v === 'clar' ? 'var(--font-document)' : 'var(--font-sans)' }}>{name}</div><div style={{ fontSize:'.78rem', color:'var(--text-muted)', marginTop:2 }}>{desc}</div></div>
  </div></Card>;
  return <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(min(100%,340px),1fr))', gap:24, alignItems:'start', maxWidth:1180, margin:'0 auto' }}>
    <div style={{ display:'grid', gap:16, minWidth:0 }}>
      <OnbTitle title="Choose how it looks">Same facts in every template. Check it, then download.</OnbTitle>
      <div style={{ display:'grid', gap:8 }}><T v="clar" name="Clar" desc="Serif, editorial, generous spacing" /><T v="contur" name="Contur" desc="Sans, pine accent band, compact" /></div>
      <Select label="CV language" icon="languages" value={lang} onChange={setLang} options={[{ value:'en', label:'English' },{ value:'ro', label:'Română' }]} hint={lang === 'ro' ? 'We translate text we know. Check anything you wrote yourself.' : 'Separate from the app language.'} />
      <div style={{ display:'grid', gap:8 }}><div style={{ font:'var(--type-label)', color:'var(--text-strong)' }}>Contact details on this CV</div>
        <div style={{ display:'flex', gap:16, flexWrap:'wrap' }}>{[['city','City'],['email','Email'],['phone','Phone']].map(([k, l]) => <Checkbox key={k} checked={show[k]} onChange={v => setShow(s => ({ ...s, [k]:v }))} label={l} />)}</div></div>
      {!rtw && <Alert tone="warn" title="Still to check">Right to work in Romania — the job requires it. <a href="#/match" onClick={() => {}}>Answer</a></Alert>}
      <div style={{ display:'flex', alignItems:'center', gap:8, fontSize:'.82rem', color:'var(--text-muted)' }}><Icon name="scan-text" size={16} />PDF readability is checked on the real file when you download.</div>
      <Card padding="sm"><div style={{ display:'grid', gap:14 }}>
        {st === 'plan' ? <div style={{ display:'grid', gap:10 }}>
          <div style={{ fontWeight:650, color:'var(--text-strong)' }}>Downloading needs a plan</div>
          <div style={{ fontSize:'.86rem', color:'var(--text-muted)', lineHeight:1.5 }}>Editing, your match and this preview stay free. Your CV is saved and waits here.</div>
          <Button variant="primary" fullWidth iconRight="arrow-right" onClick={() => go('plans')}>See plans</Button>
        </div> : st === 'busy' ? <Spinner size={28} label="Preparing your PDF and checking it reads correctly…" /> : <>
          {st === 'failed' && <Alert tone="bad" title="We couldn’t prepare the PDF">Your CV is saved — nothing was lost. Try again in a moment.</Alert>}
          {st === 'done' && <Alert tone="good" title="Downloaded">Job CV v1 · {tpl === 'clar' ? 'Clar' : 'Contur'} · {lang === 'en' ? 'English' : 'Română'}. Text, headings and dates read in the right order.</Alert>}
          {st !== 'done' && <Checkbox checked={ack} onChange={setAck} label="I’ve read this CV and everything in it is true" />}
          <Button variant="primary" size="lg" fullWidth icon={st === 'failed' ? 'rotate-cw' : 'download'} disabled={!ack} onClick={dl}>{st === 'failed' ? 'Try again' : st === 'done' ? 'Download again' : 'Download PDF'}</Button>
          {st === 'done' && <Button fullWidth icon="send" onClick={() => go('application')}>Record this application</Button>}
        </>}
      </div></Card>
      <Button variant="ghost" size="sm" icon="file-json" onClick={() => flash('Exported — northstar-cv.json')}>Export CV data (JSON)</Button>
    </div>
    <div style={{ position:'sticky', top:20, display:'grid', gap:10 }}>
      <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}><Pill size="sm" icon="git-branch">Job CV v1 · from Base v3</Pill><Pill size="sm" icon="languages">{lang === 'en' ? 'English' : 'Română'}</Pill></div>
      <CVDocument template={tpl} scale={.9} name="Mara Ionescu" titles={['Business Systems Analyst']} contact={contact} sections={window.CVZ_cv(['sum','api','out'])} />
    </div>
  </div>;
}
Object.assign(window, { JobEditorScreen, PreviewScreen });
