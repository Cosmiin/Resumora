const ONB_MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
function OnbSection({ title, count, confirmed, onConfirm, onEdit, summary, children }) {
  const { Card, Pill, Button } = ONB_DS;
  return <Card selected={false} style={confirmed ? { background:'var(--surface-card)' } : undefined}>
    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', gap:12, flexWrap:'wrap' }}>
      <div style={{ display:'flex', alignItems:'center', gap:10, flexWrap:'wrap' }}>
        <h2 style={{ margin:0, font:'var(--type-section-title)', color:'var(--text-strong)' }}>{title}</h2>
        {confirmed ? <Pill size="sm" tone="good" icon="shield-check">Confirmed by you</Pill> : <Pill size="sm">Extracted · not confirmed</Pill>}
        {!confirmed && count > 0 && <Pill size="sm" tone="warn" icon="circle-help">{count} to check</Pill>}
      </div>
      {confirmed ? <Button size="sm" variant="ghost" icon="pencil" onClick={onEdit}>Edit</Button> : null}
    </div>
    {confirmed ? <div style={{ marginTop:8, fontSize:'.86rem', color:'var(--text-muted)' }}>{summary}</div> : <div style={{ display:'grid', gap:16, marginTop:18 }}>
      {children}
      <div style={{ display:'flex', justifyContent:'flex-end', paddingTop:4 }}><Button variant="secondary" icon="check" disabled={count > 0} onClick={onConfirm}>{count > 0 ? 'Check the highlighted items first' : 'This is right'}</Button></div>
    </div>}
  </Card>;
}
function OnbCheck({ children }) {
  return <div style={{ display:'grid', gap:12, padding:14, borderRadius:10, background:'var(--status-warn-bg)', border:'1px solid var(--status-warn-border)' }}>{children}</div>;
}
function OnbReview({ acct, goals, manual, onSave, onBack }) {
  const { Field, Select, Checkbox, Button, Pill, CVDocument, ProgressBar, Alert, EmptyState, Icon } = ONB_DS;
  const [f, setF] = React.useState({ name: acct.name || 'Mara Ionescu', email: acct.email || 'mara.ionescu@example.ro', phone:'', city:'Cluj-Napoca', t1:'Business Systems Analyst', t2: goals.target || '', month:'', monthDone:false, workday:null, ack:false });
  const set = p => setF(s => ({ ...s, ...p }));
  const [ok, setOk] = React.useState({ about:false, exp:false, skills:false, edu:false });
  const conf = (k, v = true) => setOk(s => ({ ...s, [k]:v }));
  const nOk = Object.values(ok).filter(Boolean).length;
  const expCheck = f.monthDone ? 0 : 1, skillCheck = f.workday === null ? 1 : 0;
  const tech = ['SQL','Excel','REST APIs'].concat(f.workday ? ['Workday'] : []);
  const start = (f.month ? ONB_MONTHS[+f.month - 1] + ' ' : '') + '2021';
  const bw = ['Mapped approval workflows with stakeholders across finance and HR.','Wrote SQL reports used in monthly payroll reconciliation.','Automated payroll exports via REST APIs for 3 HR teams.'];
  const sections = manual ? [] : [
    { title:'Summary', text:'Analyst with 6 years in HR operations and process improvement.' },
    { title:'Experience', items:[{ heading:'Systems Analyst — BridgeWorks', dates:start+' — Present', sub:'Cluj-Napoca', bullets:bw },{ heading:'HR Operations Specialist — Carpatia Retail', dates:'Mar 2019 — 2021', sub:'Cluj-Napoca', bullets:['Coordinated onboarding for 40+ hires per quarter.'] }] },
    { title:'Skills', text:'Process automation · Requirements analysis · Stakeholder management — ' + tech.join(' · ') },
    { title:'Education', items:[{ heading:'BSc Economic Informatics — Babeș-Bolyai University', dates:'2013 — 2016' }] }];
  const total = manual ? 1 : 4, done = manual ? (ok.about ? 1 : 0) : nOk;
  const canSave = done === total && f.ack;
  return <div style={{ maxWidth:1200, margin:'0 auto', display:'grid', gap:24 }}>
    <OnbTitle title={manual ? 'Start your Base CV' : 'Check what we found'}>{manual ? 'Begin with the basics. You’ll add roles and skills in the editor — at your own pace.' : 'Nothing is saved until you confirm. Fix anything that’s wrong — we only keep what you approve.'}</OnbTitle>
    <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(min(100%,440px),1fr))', gap:28, alignItems:'start' }}>
      <div style={{ display:'grid', gap:16, minWidth:0 }}>
        <ProgressBar value={done} max={total} label="Sections confirmed" valueLabel={`${done} of ${total}`} />
        <OnbSection title="About you" count={0} confirmed={ok.about} onConfirm={() => conf('about')} onEdit={() => conf('about', false)} summary={[f.name, f.email, f.city, f.t1].filter(Boolean).join(' · ')}>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(min(100%,220px),1fr))', gap:16 }}>
            <Field label="Full name" icon="user" value={f.name} onChange={v => set({ name:v })} />
            <Field label="Email" icon="mail" type="email" value={f.email} onChange={v => set({ email:v })} />
            <Field label="Phone" icon="phone" type="tel" optional value={f.phone} onChange={v => set({ phone:v })} hint="We didn’t find one in your CV." />
            <Field label="City" icon="map-pin" optional value={f.city} onChange={v => set({ city:v })} />
            <Field label="Title" value={f.t1} onChange={v => set({ t1:v })} hint="Under your name. Not a past job title." />
            <Field label="Second title" optional value={f.t2} onChange={v => set({ t2:v })} hint={goals.target ? 'From your answer earlier.' : 'Useful if you apply for two kinds of role.'} />
          </div>
        </OnbSection>
        {manual ? <EmptyState icon="briefcase" title="Your roles come next" actions={<Pill tone="info" icon="info">You’ll add them in the editor</Pill>}>After you save, we’ll walk you through your most recent role first.</EmptyState> : <>
          <OnbSection title="Experience" count={expCheck} confirmed={ok.exp} onConfirm={() => conf('exp')} onEdit={() => conf('exp', false)} summary="2 roles · 2019 — Present · about 6 years (overlaps counted once)">
            {[['Systems Analyst','BridgeWorks',start+' — Present',bw.length],['HR Operations Specialist','Carpatia Retail','Mar 2019 — 2021',1]].map(([t,c,d,n], i) => <div key={c} style={{ display:'grid', gap:12, paddingBottom: i ? 0 : 16, borderBottom: i ? 0 : '1px solid var(--border-subtle)' }}>
              <div style={{ display:'flex', justifyContent:'space-between', gap:12, flexWrap:'wrap' }}>
                <div><div style={{ fontWeight:650, color:'var(--text-strong)' }}>{t} · {c}</div><div style={{ fontSize:'.82rem', color:'var(--text-muted)', marginTop:2 }}>{d} · Cluj-Napoca · {n} {n === 1 ? 'bullet' : 'bullets'}</div></div>
                <Button size="sm" variant="ghost" icon="pencil">Edit role</Button>
              </div>
              {i === 0 && !f.monthDone && <OnbCheck>
                <div style={{ display:'flex', gap:10, fontSize:'.86rem', color:'var(--text-strong)', lineHeight:1.5 }}><Icon name="circle-help" size={18} color="var(--status-warn-fg)" /><span>We found only the year you started: <b style={{ fontWeight:650 }}>2021</b>. Add the month if you know it — or keep just the year. We won’t guess.</span></div>
                <div style={{ display:'flex', gap:10, alignItems:'end', flexWrap:'wrap' }}>
                  <div style={{ width:200 }}><Select label="Start month" size="sm" value={f.month} onChange={v => set({ month:v })} placeholder="Not sure" options={ONB_MONTHS.map((m, k) => ({ value:String(k + 1), label:m }))} /></div>
                  <Button size="sm" variant="primary" onClick={() => set({ monthDone:true })}>{f.month ? 'Use ' + start : 'Keep “2021”'}</Button>
                </div>
              </OnbCheck>}
            </div>)}
          </OnbSection>
          <OnbSection title="Skills" count={skillCheck} confirmed={ok.skills} onConfirm={() => conf('skills')} onEdit={() => conf('skills', false)} summary={`3 professional · ${tech.length} technical`}>
            {[['Professional', ['Process automation','Requirements analysis','Stakeholder management']],['Technical', tech]].map(([g, list]) => <div key={g} style={{ display:'grid', gap:8 }}>
              <div style={{ font:'var(--type-label)', color:'var(--text-strong)' }}>{g}</div>
              <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>{list.map(s => <Pill key={s} shape="round">{s}</Pill>)}</div>
            </div>)}
            {f.workday === null && <OnbCheck>
              <div style={{ display:'flex', gap:10, fontSize:'.86rem', color:'var(--text-strong)', lineHeight:1.5 }}><Icon name="circle-help" size={18} color="var(--status-warn-fg)" /><span>Your CV says “familiar with Workday”. Should we list <b style={{ fontWeight:650 }}>Workday</b> as a technical skill?</span></div>
              <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}><Button size="sm" variant="primary" onClick={() => set({ workday:true })}>Yes, I use it</Button><Button size="sm" onClick={() => set({ workday:false })}>No, leave it out</Button></div>
            </OnbCheck>}
          </OnbSection>
          <OnbSection title="Education" count={0} confirmed={ok.edu} onConfirm={() => conf('edu')} onEdit={() => conf('edu', false)} summary="BSc Economic Informatics · Babeș-Bolyai University · 2013 — 2016">
            <div><div style={{ fontWeight:650, color:'var(--text-strong)' }}>BSc Economic Informatics · Babeș-Bolyai University</div><div style={{ fontSize:'.82rem', color:'var(--text-muted)', marginTop:2 }}>2013 — 2016 · Cluj-Napoca</div></div>
          </OnbSection>
        </>}
        <div style={{ display:'grid', gap:16, padding:'20px 0 0', borderTop:'1px solid var(--border-subtle)' }}>
          <Checkbox variant="card" checked={f.ack} onChange={v => set({ ack:v })} label="Everything here is true and about me" description="We’ll only ever use these facts. Wording can change per job — facts can’t." />
          <OnbActions back={<Button variant="ghost" icon="arrow-left" onClick={onBack}>Back</Button>}>
            <Button variant="primary" size="lg" icon="shield-check" disabled={!canSave} onClick={() => onSave(f)}>Save as my Base CV</Button>
          </OnbActions>
          {!canSave && <div style={{ fontSize:'.8rem', color:'var(--text-muted)', textAlign:'right' }}>{done < total ? `Confirm ${total - done} more ${total - done === 1 ? 'section' : 'sections'} to save.` : 'Tick the box above to save.'}</div>}
        </div>
      </div>
      <div style={{ position:'sticky', top:20, display:'grid', gap:10 }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}><div style={{ font:'var(--type-label)', color:'var(--text-strong)' }}>Preview</div><Pill size="sm" icon="languages">{goals.where === 'ro' ? 'Română' : 'English'}</Pill></div>
        <CVDocument template="clar" name={f.name} titles={[f.t1, f.t2].filter(Boolean)} contact={[f.email, f.phone, f.city].filter(Boolean).join(' · ')} sections={sections} />
      </div>
    </div>
  </div>;
}
function OnbReady({ name, onFirstJob }) {
  const { Card, Button, TaskCard, Pill, Icon } = ONB_DS;
  return <div style={{ maxWidth:880, margin:'0 auto', display:'grid', gap:24 }}>
    <section style={{ display:'grid', gridTemplateColumns:'auto minmax(0,1fr)', gap:24, alignItems:'center', background:'var(--surface-hero)', border:'1px solid #d6e4d9', borderRadius:'var(--radius-hero)', padding:'38px' }}>
      <OnbIconTile icon="shield-check" tone="inverse" size={64} />
      <div>
        <h1 style={{ margin:0, font:'700 2.3rem/1.1 var(--font-display)', letterSpacing:'-0.045em', color:'var(--text-strong)', textWrap:'balance' }}>Your Base CV is ready, {(name || 'Mara').split(' ')[0]}</h1>
        <p style={{ margin:'12px 0 0', color:'var(--text-muted)', lineHeight:1.6, maxWidth:520 }}>v1 · saved just now. Every job version starts from here — and it only changes when you say so.</p>
        <div style={{ display:'flex', gap:10, marginTop:22, flexWrap:'wrap' }}><Button variant="primary" size="lg" iconRight="arrow-right" onClick={onFirstJob}>Add my first job</Button><Button size="lg" icon="file-user">Open my Base CV</Button></div>
      </div>
    </section>
    <div style={{ display:'grid', gap:12 }}>
      <h2 style={{ margin:0, font:'var(--type-section-title)', color:'var(--text-strong)' }}>When you have a few minutes</h2>
      <TaskCard icon="sparkles" title="Make your CV stronger" meta={<><Pill size="sm">About 3 min</Pill><Pill size="sm" tone="info" icon="shield-check">Only facts you confirm</Pill></>}>4 short questions about results you haven’t written down yet.</TaskCard>
      <TaskCard icon="layout-template" title="Choose how your CV looks" meta={<Pill size="sm">2 templates</Pill>}>Clar or Contur. Same facts, different presentation.</TaskCard>
    </div>
  </div>;
}
Object.assign(window, { OnbReview, OnbReady });
