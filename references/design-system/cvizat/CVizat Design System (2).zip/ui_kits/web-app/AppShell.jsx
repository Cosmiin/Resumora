function rzParse(str) {
  const raw = str != null ? str : location.hash.replace(/^#\/?/, '');
  const [r, s] = raw.split('/').map(x => decodeURIComponent(x || ''));
  const route = RZ_ROUTES[r] ? r : (r ? 'notfound' : 'home');
  const st = RZ_ROUTES[route].states.includes(s) ? s : RZ_ROUTES[route].states[0];
  return { route, state:st };
}
function RzGuideBar({ route, state, go, notes, setNotes, compact }) {
  const R = RZ_ROUTES[route], px = compact ? 16 : 44;
  const chip = on => ({ padding:'5px 10px', borderRadius:999, border:'1px solid ' + (on ? 'var(--pine-600)' : 'var(--border-subtle)'), background: on ? 'var(--pine-600)' : '#fff', color: on ? '#fff' : 'var(--text-body)', font:'600 .74rem var(--font-sans)', cursor:'pointer', whiteSpace:'nowrap', flex:'none' });
  return <div style={{ background:'var(--sage-50)', borderBottom:'1px dashed var(--sage-300)', flex:'none' }}>
    <div style={{ display:'flex', alignItems:'center', gap:'8px 16px', flexWrap:'wrap', padding:'10px ' + px + 'px' }}>
      <span style={{ font:'600 .72rem var(--font-mono, monospace)', color:'var(--pine-700)', background:'#fff', border:'1px solid var(--border-subtle)', borderRadius:6, padding:'3px 7px' }}>{R.id}</span>
      <b style={{ fontWeight:650, fontSize:'.86rem', color:'var(--text-strong)' }}>{R.name}</b>
      <span style={{ display:'flex', gap:4, alignItems:'center', fontSize:'.76rem', color:'var(--text-muted)' }}>Journey {R.journeys.map(j => <a key={j} href={'journeys.html#' + j} style={{ fontWeight:700 }}>{j}</a>)}</span>
      <span style={{ flex:1 }}></span>
      {R.states.length > 1 && <span style={{ display:'flex', gap:6, alignItems:'center', overflowX:'auto', maxWidth:'100%' }}><span style={{ fontSize:'.72rem', fontWeight:700, letterSpacing:'.08em', textTransform:'uppercase', color:'var(--text-muted)', flex:'none' }}>State</span>{R.states.map(s => <button key={s} style={chip(s === state)} onClick={() => go(route, s)}>{s}</button>)}</span>}
      <button style={chip(false)} onClick={() => setNotes(!notes)}>{notes ? 'Hide notes' : 'Notes'}</button>
    </div>
    {notes && <ul style={{ margin:0, padding:'0 ' + px + 'px 12px ' + (px + 18) + 'px', display:'grid', gap:4, fontSize:'.8rem', color:'var(--text-body)', lineHeight:1.5 }}>{R.notes.map(n => <li key={n}>{n}</li>)}</ul>}
  </div>;
}
function RzTabBar({ value, go, bottom }) {
  const { Icon } = ONB_DS;
  const items = [['home','Home','house'],['base','Base CV','file-user'],['enrich','Improve','sparkles'],['applications','Applications','briefcase'],['account','Account','circle-user']];
  return <nav style={{ display:'grid', gridTemplateColumns:'repeat(5,1fr)', borderTop:'1px solid var(--border-subtle)', background:'#fff', paddingBottom:bottom, flex:'none' }}>
    {items.map(([v, l, ic]) => { const on = value === v; return <button key={v} onClick={() => go(v)} aria-current={on ? 'page' : undefined} style={{ minHeight:58, display:'grid', justifyItems:'center', alignContent:'center', gap:3, background:'none', border:0, cursor:'pointer', color: on ? 'var(--pine-700)' : 'var(--text-muted)', font:'650 .66rem var(--font-sans)' }}>
      <span style={{ display:'grid', placeItems:'center', padding:'4px 14px', borderRadius:999, background: on ? 'var(--pine-100)' : 'transparent' }}><Icon name={ic} size={20} /></span>{l}</button>; })}
  </nav>;
}
function RzFirstHome({ go }) {
  const { Button, EmptyState } = ONB_DS;
  return <div style={{ display:'grid', gap:24, maxWidth:1040 }}>
    <div style={{ background:'var(--surface-hero)', border:'1px solid #d6e4d9', borderRadius:'var(--radius-hero)', padding:'clamp(22px,4cqi,38px)' }}>
      <div style={{ font:'750 .73rem var(--font-sans)', letterSpacing:'.14em', textTransform:'uppercase', color:'var(--text-accent)', marginBottom:12 }}>Welcome, Mara</div>
      <h1 style={{ margin:0, font:'700 clamp(2rem,6cqi,2.65rem)/1.1 var(--font-display)', letterSpacing:'-0.045em', color:'var(--text-strong)', maxWidth:620, textWrap:'balance' }}>Prepare your next application</h1>
      <p style={{ margin:'16px 0 0', color:'var(--text-muted)', lineHeight:1.6, maxWidth:520 }}>Start with the job you want, or bring your CV first. Either way, you confirm every fact before we use it.</p>
      <div style={{ display:'flex', gap:10, marginTop:24, flexWrap:'wrap' }}><Button variant="primary" size="lg" iconRight="arrow-right" onClick={() => go('addjob')}>Start with a job</Button><Button size="lg" icon="file-up" href="onboarding.html#/import">Create my Base CV</Button></div>
    </div>
    <EmptyState icon="briefcase" title="No applications yet">Each job you add gets its own CV, contact and next step — they’ll appear here.</EmptyState>
  </div>;
}
function RzMatch({ state, go, rtw, setRtw }) {
  const { Alert, Button, Card, Spinner } = ONB_DS;
  const [st, setSt] = React.useState(state);
  React.useEffect(() => { if (st !== 'busy') return; const t = setTimeout(() => setSt('ok'), 1300); return () => clearTimeout(t); }, [st]);
  if (st === 'busy') return <Card style={{ maxWidth:640, margin:'40px auto', textAlign:'center' }}><div style={{ padding:'40px 0' }}><Spinner label="Comparing the job with Base CV v3…" /></div></Card>;
  if (st === 'Failed') return <div style={{ maxWidth:640, margin:'40px auto' }}><Alert tone="bad" title="We couldn’t calculate your match" action={<Button size="sm" variant="primary" icon="rotate-cw" onClick={() => setSt('busy')}>Try again</Button>}>Your CV and the job are saved. This was on our side.</Alert></div>;
  return <div style={{ display:'grid', gridTemplateColumns:'minmax(0,1fr)', gap:16 }}>
    {st === 'Outdated' && <div style={{ maxWidth:1120, margin:'0 auto', width:'100%' }}><Alert tone="warn" title="This match is out of date" action={<Button size="sm" variant="primary" icon="rotate-cw" onClick={() => setSt('busy')}>Recalculate</Button>}>You saved Base CV v3 after it was calculated. The results below are from v2.</Alert></div>}
    <MatchReportScreen rtw={rtw} setRtw={setRtw} onNext={() => go('compare')} />
  </div>;
}
function ResumoraApp({ initial, embed }) {
  const { SideNav, TopBar, Stepper, IconButton, Button, Toast, Logo } = ONB_DS;
  const mobile = rzUseMobile(embed);
  const [loc, setLoc] = React.useState(() => rzParse(initial));
  const [toast, setToast] = React.useState(null);
  const [accepted, setAccepted] = React.useState(['sum','api','out']);
  const [rtw, setRtw] = React.useState(false);
  const [notes, setNotesRaw] = React.useState(!embed && localStorage.getItem('rz-notes') !== '0');
  const mainRef = React.useRef(null);
  const tRef = React.useRef(null);
  const setNotes = v => { setNotesRaw(v); localStorage.setItem('rz-notes', v ? '1' : '0'); };
  React.useEffect(() => { if (embed) return; const h = () => setLoc(rzParse()); window.addEventListener('hashchange', h); return () => window.removeEventListener('hashchange', h); }, []);
  React.useEffect(() => { if (mainRef.current) mainRef.current.scrollTop = 0; if (!embed) window.scrollTo(0, 0); }, [loc.route, loc.state]);
  const go = (r, s) => { if (embed) setLoc(rzParse(r + (s ? '/' + encodeURIComponent(s) : ''))); else location.hash = '#/' + r + (s ? '/' + encodeURIComponent(s) : ''); };
  const flash = m => { setToast(m); clearTimeout(tRef.current); tRef.current = setTimeout(() => setToast(null), 2800); };
  const { route, state } = loc, R = RZ_ROUTES[route];
  const p = { state, go, flash, rtw };
  const body = {
    home: () => state === 'First visit' ? <RzFirstHome go={go} /> : <HomeScreen applied={false} onJob={() => go('addjob')} onOpen={() => go('application')} onBase={() => go('base')} onImprove={() => go('base', 'Review')} />,
    base: () => <BaseScreen {...p} />, history: () => <HistoryScreen {...p} />, enrich: () => <EnrichScreen {...p} />,
    addjob: () => <JobCaptureScreen {...p} />, requirements: () => <RequirementsScreen {...p} />,
    match: () => <RzMatch state={state} go={go} rtw={rtw} setRtw={setRtw} />,
    compare: () => <div style={{ display:'grid', gridTemplateColumns:'minmax(0,1fr)', gap:14 }}><ImproveScreen accepted={accepted} setAccepted={setAccepted} onNext={b => { flash(b ? 'Saved — Base CV is now v4' : 'Saved — Job CV v1 · Base CV unchanged'); go('preview'); }} /><div style={{ maxWidth:1180, margin:'0 auto', width:'100%' }}><Button variant="ghost" icon="pencil" onClick={() => go('jobeditor')}>Prefer to edit it yourself? Open the editor</Button></div></div>,
    jobeditor: () => <JobEditorScreen {...p} />, preview: () => <PreviewScreen {...p} />,
    applications: () => <ApplicationsScreen {...p} />, application: () => <ApplicationScreen {...p} />, linkedin: () => <LinkedInScreen {...p} />,
    plans: () => <PlansScreen {...p} />, checkout: () => <CheckoutScreen {...p} />, account: () => <AccountScreen {...p} />,
    login: () => <LoginScreen {...p} />, forgot: () => <ForgotScreen {...p} />, reset: () => <ResetScreen {...p} />, expired: () => <ExpiredScreen {...p} />, session: () => <SessionScreen {...p} />,
    notfound: () => <NotFoundScreen {...p} />, error: () => <ServerErrorScreen {...p} />, offline: () => <OfflineScreen {...p} />, maintenance: () => <MaintenanceScreen {...p} />,
  }[route];
  const top = embed ? 44 : 0;
  const guide = !embed && <RzGuideBar route={route} state={state} go={go} notes={notes} setNotes={setNotes} compact={mobile} />;
  const tst = toast && <Toast icon="circle-check" action="Undo" onAction={() => setToast(null)}>{toast}</Toast>;
  const main = pad => <main ref={mainRef} style={{ flex:1, minHeight:0, overflowY: mobile ? 'auto' : undefined, padding:pad, containerType:'inline-size' }}><div key={route + state}>{body()}</div></main>;
  const root = { display:'flex', flexDirection:'column', background:'var(--surface-page)', fontFamily:'var(--font-sans)', color:'var(--text-body)', textAlign:'left', height: mobile ? (embed ? '100%' : '100dvh') : undefined, minHeight: mobile ? undefined : '100vh', overflow: mobile ? 'hidden' : undefined, transform: embed ? 'translateZ(0)' : undefined };
  const fr = ['addjob','requirements','match','compare','preview'], fsteps = ['Add job','Requirements','Match','Improve','Download'];
  if (R.bare) return <div style={root}>
    <header style={{ padding:(top + (mobile ? 14 : 22)) + 'px ' + (mobile ? 16 : 44) + 'px 0', flex:'none' }}><a href="#/home" onClick={e => { if (embed) { e.preventDefault(); go('home'); } }} aria-label="Resumora home"><Logo size={mobile ? 26 : 30} /></a></header>
    {guide && <div style={{ marginTop:12 }}>{guide}</div>}{main(mobile ? '20px 16px 48px' : '24px 44px 80px')}{tst}
  </div>;
  if (R.flow !== undefined) return <div style={root}>
    {mobile ? <RzMobileHead top={top} onClose={() => go('application')} eyebrow={`Northstar People · step ${R.flow + 1} of 5`} title={fsteps[R.flow]} progress={[R.flow + 1, 5]} right={<Button size="sm" variant="ghost" onClick={() => go('applications')}>Save & exit</Button>} />
      : <TopBar back={<><IconButton icon="x" label="Exit to application" onClick={() => go('application')} /><Logo variant="mark" size={28} /></>} title="Northstar People" right={<Button size="sm" onClick={() => go('applications')}>Save & exit</Button>}><Stepper steps={fsteps} current={R.flow} onStepClick={i => go(fr[i])} /></TopBar>}
    {guide}{main(mobile ? '20px 16px 40px' : '32px 44px 80px')}{tst}
  </div>;
  if (mobile) return <div style={root}>
    <RzMobileHead top={top} logo title={R.name} right={<IconButton variant="ghost" icon="scan-search" label="LinkedIn check" onClick={() => go('linkedin')} />} />
    {guide}{main('20px 16px 32px')}
    <RzTabBar value={R.nav} go={go} bottom={embed ? 18 : 'env(safe-area-inset-bottom)'} />{tst}
  </div>;
  return <div style={{ display:'flex', minHeight:'100vh' }}>
    <SideNav value={R.nav} onChange={v => go(v)} items={[{ value:'home', label:'Home', icon:'house' },{ value:'base', label:'Base CV', icon:'file-user' },{ value:'enrich', label:'Improve profile', icon:'sparkles', badge:'4' },{ value:'applications', label:'Applications', icon:'briefcase', badge:'4' },{ value:'linkedin', label:'LinkedIn check', icon:'scan-search' },{ value:'account', label:'Account', icon:'circle-user' }]}
      footer={<div style={{ padding:'0 12px', display:'grid', gap:6, fontSize:'.74rem' }}><a href="journeys.html">Customer journeys</a><a href="mobile.html">Mobile screens</a><a href="onboarding.html#/welcome">Onboarding flow</a><span style={{ color:'var(--text-muted)' }}>resumora.ro · demo data</span></div>} />
    <div style={{ flex:1, minWidth:0, display:'flex', flexDirection:'column' }}>{guide}{main('32px 44px 80px')}</div>
    {tst}
  </div>;
}
window.ResumoraApp = ResumoraApp;
if (!window.RZ_EMBED_PAGE) ReactDOM.createRoot(document.getElementById('root')).render(<ResumoraApp />);
