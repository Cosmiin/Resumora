function OnbImport({ flags, file, setFile, onRead, onManual, onBack, notice }) {
  const { Card, Dropzone, Button, Alert, RadioGroup } = ONB_DS;
  const [mode, setMode] = React.useState('upload');
  const scanned = flags.scanned && !!file;
  return <div style={{ maxWidth:980, margin:'0 auto', display:'grid', gap:24 }}>
    <OnbTitle title="Bring your CV once">We read it, you check every detail, and it becomes your Base CV — the starting point for every job.</OnbTitle>
    {notice && <Alert tone="neutral" icon="circle-stop">{notice}</Alert>}
    <div style={{ display:'flex', flexWrap:'wrap', gap:24, alignItems:'flex-start' }}>
      <div style={{ display:'grid', gap:20, flex:'2 1 480px', minWidth:0 }}>
        <Card><div style={{ display:'grid', gap:20 }}>
          <RadioGroup name="src" direction="row" value={mode} onChange={setMode} options={[
            { value:'upload', label:'Upload my CV', description:'Fastest. PDF or Word.' },
            { value:'manual', label:'Start from scratch', description:'We guide you, about 10 minutes.' }]} />
          {mode === 'upload' ? <>
            <Dropzone title="Drop your CV here, or choose a file" acceptLabel="PDF or DOCX · up to 10 MB" accept=".pdf,.docx" file={file} onFile={f => setFile({ name:f.name, size:f.size })} onRemove={() => setFile(null)} />
            {!file && <button onClick={() => setFile({ name:'Mara_Ionescu_CV_2026.pdf', size:'184 KB' })} style={{ justifySelf:'start', background:'none', border:0, padding:0, font:'600 .82rem var(--font-sans)', color:'var(--pine-600)', cursor:'pointer' }}>Use the example CV instead</button>}
            {scanned && <Alert tone="warn" title="This looks like a scanned image" action={<Button size="sm" onClick={onManual}>Type it in</Button>}>We can’t read text from photos or scans yet. Try a PDF with selectable text — or type it in, we’ll guide you.</Alert>}
          </> : <div style={{ display:'grid', gap:12, padding:'4px 0' }}>
            <OnbPromise items={[['list-checks','One section at a time','Contact, roles, skills, education. Skip what you don’t have.'],['calendar','Dates as precise as you know them','Only the year? That’s fine — we won’t invent a month.']]} />
          </div>}
        </div></Card>
        <OnbActions back={<Button variant="ghost" icon="arrow-left" onClick={onBack}>Back</Button>}>
          {mode === 'upload'
            ? <Button variant="primary" size="lg" iconRight="arrow-right" disabled={!file || scanned} onClick={onRead}>Read my CV</Button>
            : <Button variant="primary" size="lg" iconRight="arrow-right" onClick={onManual}>Start writing</Button>}
        </OnbActions>
      </div>
      <Card tone="sunken" style={{ flex:'1 1 260px', width:'auto' }}><div style={{ display:'grid', gap:16 }}>
        <div style={{ font:'var(--type-section-title)', color:'var(--text-strong)' }}>What happens to your file</div>
        <OnbPromise items={[['scan-text','We read it to build your Base CV','Nothing is saved until you confirm it.'],['lock','It stays private','Never shared with employers or other users.'],['trash-2','You stay in control','Delete the file or your whole account from Account.']]} />
      </div></Card>
    </div>
  </div>;
}
function OnbReading({ flags, fileName, onDone, onCancel }) {
  const { Card, Button, Alert, ProgressBar, Icon, Spinner } = ONB_DS;
  const stages = ['Reading the text','Finding your roles and dates','Grouping your skills','Preparing it for you to check'];
  const [i, setI] = React.useState(0);
  const [failed, setFailed] = React.useState(false);
  const [run, setRun] = React.useState(0);
  React.useEffect(() => {
    setI(0); setFailed(false);
    const t = setInterval(() => setI(n => {
      if (flags.fail && run === 0 && n === 1) { clearInterval(t); setFailed(true); return n; }
      if (n >= stages.length - 1) { clearInterval(t); setTimeout(onDone, 700); return stages.length; }
      return n + 1;
    }), 950);
    return () => clearInterval(t);
  }, [run]);
  return <div style={{ maxWidth:560, margin:'24px auto 0', display:'grid', gap:20 }}>
    <Card padding="lg"><div style={{ display:'grid', gap:22 }}>
      <div style={{ display:'flex', gap:16, alignItems:'center' }}>
        {failed ? <OnbIconTile icon="file-x" tone="bad" size={48} /> : <Spinner size={44} />}
        <div style={{ minWidth:0 }}>
          <div style={{ font:'700 1.35rem/1.2 var(--font-display)', letterSpacing:'-0.03em', color:'var(--text-strong)' }}>{failed ? 'We couldn’t finish reading it' : 'Reading your CV…'}</div>
          <div style={{ fontSize:'.84rem', color:'var(--text-muted)', marginTop:4, overflow:'hidden', textOverflow:'ellipsis' }}>{fileName || 'Mara_Ionescu_CV_2026.pdf'}</div>
        </div>
      </div>
      {!failed && <ProgressBar value={Math.min(i, stages.length)} max={stages.length} tone="primary" />}
      <div style={{ display:'grid', gap:12 }}>{stages.map((s, n) => {
        const done = n < i, now = n === i && !failed, stop = failed && n === i;
        return <div key={s} style={{ display:'flex', gap:12, alignItems:'center', fontSize:'.9rem', color: done || now ? 'var(--text-strong)' : 'var(--text-muted)', fontWeight: now ? 650 : 400 }}>
          <Icon name={done ? 'circle-check' : stop ? 'circle-x' : now ? 'loader-circle' : 'circle'} size={18} color={done ? 'var(--status-good-fg)' : stop ? 'var(--status-bad-fg)' : now ? 'var(--pine-600)' : 'var(--sage-300)'} />{s}
        </div>;
      })}</div>
      {failed
        ? <Alert tone="bad" action={<Button size="sm" variant="primary" icon="rotate-cw" onClick={() => setRun(r => r + 1)}>Try again</Button>}>Your file is fine — this was on our side. Nothing was saved.</Alert>
        : <div style={{ fontSize:'.82rem', color:'var(--text-muted)' }}>Usually under a minute. You’ll check everything before it’s saved.</div>}
    </div></Card>
    <div style={{ textAlign:'center' }}><Button variant="ghost" size="sm" onClick={onCancel}>{failed ? 'Choose another file' : 'Stop reading'}</Button></div>
  </div>;
}
Object.assign(window, { OnbImport, OnbReading });
