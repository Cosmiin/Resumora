const ONB_DS = window.CVizatDesignSystem_0f8e2e;
function OnbTitle({ eyebrow, title, children, center }) {
  return <div style={{ textAlign: center ? 'center' : 'left' }}>
    {eyebrow && <div style={{ font:'750 .73rem var(--font-sans)', letterSpacing:'.14em', textTransform:'uppercase', color:'var(--text-accent)', marginBottom:10 }}>{eyebrow}</div>}
    <h1 style={{ margin:0, font:'700 2rem/1.15 var(--font-display)', letterSpacing:'-0.04em', color:'var(--text-strong)', textWrap:'balance' }}>{title}</h1>
    {children && <p style={{ margin:'10px 0 0', color:'var(--text-muted)', lineHeight:1.6, textWrap:'pretty', maxWidth: center ? 520 : 600, marginInline: center ? 'auto' : 0 }}>{children}</p>}
  </div>;
}
function OnbIconTile({ icon, tone = 'good', size = 56 }) {
  const { Icon } = ONB_DS;
  const inv = tone === 'inverse';
  return <div style={{ width:size, height:size, borderRadius:16, display:'grid', placeItems:'center', background: inv ? 'var(--pine-600)' : 'var(--status-'+tone+'-bg)', color: inv ? '#fff' : 'var(--status-'+tone+'-fg)', flex:'none' }}><Icon name={icon} size={Math.round(size*.46)} /></div>;
}
function OnbActions({ back, children }) {
  return <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', gap:12, flexWrap:'wrap' }}><div>{back}</div><div style={{ display:'flex', gap:10, flexWrap:'wrap' }}>{children}</div></div>;
}
function OnbPromise({ items }) {
  const { Icon } = ONB_DS;
  return <div style={{ display:'grid', gap:12 }}>{items.map(([ic, t, d]) => <div key={t} style={{ display:'flex', gap:12, alignItems:'flex-start' }}>
    <span style={{ color:'var(--pine-600)', marginTop:1 }}><Icon name={ic} size={18} /></span>
    <div><div style={{ fontWeight:650, fontSize:'.88rem', color:'var(--text-strong)' }}>{t}</div>{d && <div style={{ fontSize:'.82rem', color:'var(--text-muted)', lineHeight:1.5, marginTop:2 }}>{d}</div>}</div>
  </div>)}</div>;
}
function OnbDemoBar({ screen, setScreen, flags, setFlags }) {
  const [open, setOpen] = React.useState(false);
  const screens = [['welcome','Welcome'],['account','Create account'],['verify','Verify email'],['goals','Your search'],['import','Import CV'],['reading','Reading'],['review','Check details'],['ready','Ready']];
  const chip = on => ({ padding:'6px 10px', borderRadius:999, border:'1px solid '+(on?'var(--pine-600)':'var(--border-subtle)'), background:on?'var(--pine-50)':'#fff', color:on?'var(--pine-700)':'var(--text-body)', font:'600 .74rem var(--font-sans)', cursor:'pointer' });
  return <div style={{ position:'fixed', left:16, bottom:16, zIndex:50, display:'grid', gap:8, justifyItems:'start' }}>
    {open && <div style={{ background:'#fff', border:'1px solid var(--border-subtle)', borderRadius:14, boxShadow:'var(--shadow-toast)', padding:14, display:'grid', gap:10, width:300 }}>
      <div style={{ font:'700 .7rem var(--font-sans)', letterSpacing:'.12em', textTransform:'uppercase', color:'var(--text-muted)' }}>Jump to screen</div>
      <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>{screens.map(([v,l]) => <button key={v} style={chip(screen===v)} onClick={() => setScreen(v)}>{l}</button>)}</div>
      <div style={{ font:'700 .7rem var(--font-sans)', letterSpacing:'.12em', textTransform:'uppercase', color:'var(--text-muted)', marginTop:4 }}>Simulate</div>
      <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>
        <button style={chip(flags.scanned)} onClick={() => setFlags(f => ({ ...f, scanned:!f.scanned }))}>Scanned file</button>
        <button style={chip(flags.fail)} onClick={() => setFlags(f => ({ ...f, fail:!f.fail }))}>Reading fails</button>
      </div>
    </div>}
    <button onClick={() => setOpen(o => !o)} style={{ ...chip(open), boxShadow:'var(--shadow-toast)', padding:'8px 14px' }}>{open ? 'Close demo' : 'Demo controls'}</button>
  </div>;
}
function rzUseMobile(force) {
  const q = '(max-width: 760px)';
  const [m, setM] = React.useState(() => window.matchMedia(q).matches);
  React.useEffect(() => { const mq = window.matchMedia(q); const f = () => setM(mq.matches); mq.addEventListener('change', f); return () => mq.removeEventListener('change', f); }, []);
  return !!force || m;
}
function RzMobileHead({ top = 0, onClose, eyebrow, title, right, progress, logo }) {
  const { IconButton, ProgressBar, Logo } = ONB_DS;
  return <header style={{ padding: (top + 10) + 'px 12px 10px', background:'#fff', borderBottom:'1px solid var(--border-subtle)', display:'grid', gap:10, flex:'none' }}>
    <div style={{ display:'flex', alignItems:'center', gap:10, minHeight:44 }}>
      {onClose && <IconButton variant="ghost" icon="x" label="Exit" onClick={onClose} />}{logo && <span style={{ paddingLeft:4, display:'flex' }}><Logo variant="mark" size={28} /></span>}
      <div style={{ flex:1, minWidth:0 }}>{eyebrow && <div style={{ fontSize:'.72rem', color:'var(--text-muted)' }}>{eyebrow}</div>}<div style={{ fontWeight:650, color:'var(--text-strong)', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{title}</div></div>{right}
    </div>
    {progress && <ProgressBar value={progress[0]} max={progress[1]} height={4} />}
  </header>;
}
Object.assign(window, { ONB_DS, OnbTitle, OnbIconTile, OnbActions, OnbPromise, OnbDemoBar, rzUseMobile, RzMobileHead });
