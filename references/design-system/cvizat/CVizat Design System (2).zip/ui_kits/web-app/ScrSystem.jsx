function RzSysPage({ icon, tone = 'good', code, title, children, actions, foot }) {
  return <div style={{ maxWidth:520, margin:'min(8vh,64px) auto 0', display:'grid', gap:20, justifyItems:'center', textAlign:'center' }}>
    {code ? <div aria-hidden="true" style={{ font:'700 clamp(4.5rem,18cqi,7rem)/1 var(--font-display)', letterSpacing:'-0.06em', color:'var(--pine-200)' }}>{code}</div> : <OnbIconTile icon={icon} tone={tone} size={64} />}
    <OnbTitle center title={title}>{children}</OnbTitle>
    {actions && <div style={{ display:'flex', gap:10, flexWrap:'wrap', justifyContent:'center' }}>{actions}</div>}
    {foot && <div style={{ fontSize:'.82rem', color:'var(--text-muted)', display:'flex', gap:'6px 14px', flexWrap:'wrap', justifyContent:'center', alignItems:'center' }}>{foot}</div>}
  </div>;
}
function NotFoundScreen({ go }) {
  const { Button } = ONB_DS;
  return <RzSysPage code="404" title="We can’t find that page" actions={<><Button variant="primary" icon="house" onClick={() => go('home')}>Go to Home</Button><Button icon="briefcase" onClick={() => go('applications')}>My applications</Button></>}
    foot={<><span>Looking for something else?</span><a href="#/base">Base CV</a><a href="#/account">Account</a><a href="mailto:ajutor@resumora.ro">Contact us</a></>}>The link may be old or mistyped. Your CVs and applications are safe.</RzSysPage>;
}
function ServerErrorScreen({ go, flash }) {
  const { Button } = ONB_DS;
  const [busy, setBusy] = React.useState(false);
  return <RzSysPage code="500" title="Something went wrong on our side" actions={<><Button variant="primary" icon="rotate-cw" loading={busy} onClick={() => { setBusy(true); setTimeout(() => { setBusy(false); flash('Still not working — try again in a minute'); }, 1200); }}>Try again</Button><Button icon="house" onClick={() => go('home')}>Go to Home</Button></>}
    foot={<><span style={{ font:'600 .74rem var(--font-mono, monospace)' }}>Reference RZ-7F3K-251026</span><a href="mailto:ajutor@resumora.ro">Send it to us</a></>}>Everything up to your last save is safe. It’s not something you did — try again in a minute.</RzSysPage>;
}
function OfflineScreen({ flash }) {
  const { Button, Pill } = ONB_DS;
  return <RzSysPage icon="wifi-off" tone="warn" title="You’re offline" actions={<Button variant="primary" icon="rotate-cw" onClick={() => flash('Still offline — we’ll keep trying')}>Try again</Button>}
    foot={<Pill size="sm" tone="warn" icon="cloud-off">2 changes waiting to save</Pill>}>You can keep editing. Changes stay on this device and save as soon as you’re back online.</RzSysPage>;
}
function MaintenanceScreen() {
  return <RzSysPage icon="wrench" tone="info" title="We’re updating Resumora" foot={<span>Updates at <a href="#/maintenance">status.resumora.ro</a></span>}>We’ll be back by 14:00, Bucharest time. Everything you’ve saved is safe and unchanged.</RzSysPage>;
}
function SessionScreen({ go }) {
  const { Button } = ONB_DS;
  return <RzSysPage icon="log-out" tone="info" title="You’ve been signed out" actions={<Button variant="primary" icon="log-in" onClick={() => go('login')}>Log in again</Button>}>For your safety we sign you out after a while. Your unsaved draft is kept on this device — you’ll find it after you log in.</RzSysPage>;
}
function RzAuthCard({ title, sub, children, foot }) {
  const { Card } = ONB_DS;
  return <div style={{ maxWidth:440, margin:'min(6vh,48px) auto 0', display:'grid', gap:20 }}>
    <OnbTitle title={title}>{sub}</OnbTitle>
    <Card><div style={{ display:'grid', gap:18 }}>{children}</div></Card>
    {foot && <div style={{ textAlign:'center', fontSize:'.86rem', color:'var(--text-muted)' }}>{foot}</div>}
  </div>;
}
function LoginScreen({ state, go }) {
  const { Field, Button, Alert, Checkbox } = ONB_DS;
  const [email, setEmail] = React.useState(state === 'Default' ? '' : 'mara.ionescu@example.ro');
  const [pw, setPw] = React.useState(state === 'Default' ? '' : 'wrongpass');
  const [tried, setTried] = React.useState(false);
  const locked = state === 'Too many attempts', wrong = state === 'Wrong password';
  const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);
  const submit = () => { setTried(true); if (emailOk && pw && !wrong && !locked) go('home'); };
  return <RzAuthCard title="Welcome back" sub="Log in to see your Base CV and applications." foot={<span>New to Resumora? <a href="onboarding.html#/account">Create an account</a></span>}>
    {locked && <Alert tone="warn" title="Too many tries">For your safety, wait 5 minutes — or reset your password now.</Alert>}
    <Field label="Email" icon="mail" type="email" value={email} onChange={setEmail} placeholder="name@example.ro" error={tried && !emailOk ? 'Check the email — it should look like name@example.ro.' : undefined} />
    <div style={{ display:'grid', gap:6 }}>
      <Field label="Password" icon="lock" type="password" value={pw} onChange={setPw} error={wrong ? 'Email or password doesn’t match. Check both, or reset your password.' : tried && !pw ? 'Enter your password.' : undefined} />
      <a href="#/forgot" style={{ justifySelf:'end', fontSize:'.82rem' }}>Forgot password?</a>
    </div>
    <Checkbox defaultChecked label="Keep me logged in on this device" />
    <Button variant="primary" size="lg" fullWidth disabled={locked} onClick={submit}>Log in</Button>
  </RzAuthCard>;
}
function ForgotScreen({ state, go }) {
  const { Field, Button } = ONB_DS;
  const [email, setEmail] = React.useState('mara.ionescu@example.ro');
  const [sent, setSent] = React.useState(state === 'Sent');
  const [wait, setWait] = React.useState(0);
  React.useEffect(() => { if (!wait) return; const t = setTimeout(() => setWait(w => w - 1), 1000); return () => clearTimeout(t); }, [wait]);
  const ok = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);
  if (sent) return <RzSysPage icon="mail-check" title="Check your inbox" actions={<><Button icon="rotate-cw" disabled={wait > 0} onClick={() => setWait(30)}>{wait ? `Resend in ${wait}s` : 'Resend link'}</Button><Button variant="ghost" onClick={() => go('login')}>Back to log in</Button></>} foot={<span>Can’t find it? Look in Spam or Promotions.</span>}>If an account exists for <b style={{ color:'var(--text-strong)', fontWeight:650 }}>{email}</b>, we sent a link to reset your password. It works for 1 hour.</RzSysPage>;
  return <RzAuthCard title="Reset your password" sub="We’ll email you a link to choose a new one." foot={<a href="#/login">Back to log in</a>}>
    <Field label="Email" icon="mail" type="email" value={email} onChange={setEmail} error={email && !ok ? 'Check the email — it should look like name@example.ro.' : undefined} />
    <Button variant="primary" size="lg" fullWidth disabled={!ok} onClick={() => setSent(true)}>Send reset link</Button>
  </RzAuthCard>;
}
function ResetScreen({ state, go }) {
  const { Field, Button } = ONB_DS;
  const [a, setA] = React.useState('');
  const [b, setB] = React.useState('');
  const [done, setDone] = React.useState(state === 'Done');
  if (done) return <RzSysPage icon="circle-check" tone="inverse" title="Password changed" actions={<Button variant="primary" iconRight="arrow-right" onClick={() => go('home')}>Go to Home</Button>}>You’re logged in on this device. For safety, we logged you out everywhere else.</RzSysPage>;
  const ok = a.length >= 8 && a === b;
  return <RzAuthCard title="Choose a new password" sub="For mara.ionescu@example.ro">
    <Field label="New password" icon="lock" type="password" value={a} onChange={setA} hint="At least 8 characters." error={a && a.length < 8 ? 'Use at least 8 characters.' : undefined} success={a.length >= 8 ? 'Strong enough' : undefined} />
    <Field label="Repeat it" icon="lock" type="password" value={b} onChange={setB} error={b && a !== b ? 'The two passwords don’t match.' : undefined} />
    <Button variant="primary" size="lg" fullWidth disabled={!ok} onClick={() => setDone(true)}>Save new password</Button>
  </RzAuthCard>;
}
function ExpiredScreen({ go }) {
  const { Button } = ONB_DS;
  return <RzSysPage icon="link-2-off" tone="warn" title="This link has expired" actions={<><Button variant="primary" icon="mail" onClick={() => go('forgot')}>Send a new link</Button><Button onClick={() => go('login')}>Log in</Button></>}>Password links work for 1 hour and email links for 24 hours. Ask for a new one — it only takes a moment.</RzSysPage>;
}
Object.assign(window, { RzSysPage, NotFoundScreen, ServerErrorScreen, OfflineScreen, MaintenanceScreen, SessionScreen, LoginScreen, ForgotScreen, ResetScreen, ExpiredScreen });
