const RZ_STAGE_TONE = { 'To send':'info', 'Sent':'neutral', 'Interview':'good', 'Offer':'good', 'Closed':'neutral' };
function ApplicationsScreen({ state, go }) {
  const { Card, Button, Field, Segmented, Pill, EmptyState, Icon } = ONB_DS;
  const [q, setQ] = React.useState(state === 'No results' ? 'Siemens' : '');
  const [f, setF] = React.useState('All');
  const apps = state === 'Empty' ? [] : RZ_APP.apps;
  const list = apps.filter(a => (f === 'All' || a.stage === f) && (a.role + ' ' + a.company).toLowerCase().includes(q.trim().toLowerCase()));
  const sent = apps.filter(a => a.stage !== 'To send').length;
  return <div style={{ maxWidth:1040, margin:'0 auto', display:'grid', gap:20 }}>
    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', gap:12, flexWrap:'wrap' }}>
      <OnbTitle title="Applications">{apps.length ? `${sent} sent so far — counted when you mark an application as sent.` : 'Each job you add gets a record here.'}</OnbTitle>
      <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}><Button icon="scan-search" onClick={() => go('linkedin')}>LinkedIn check</Button><Button variant="primary" icon="plus" onClick={() => go('addjob')}>Add a job</Button></div>
    </div>
    {!apps.length ? <EmptyState icon="briefcase" title="No applications yet" actions={<Button variant="primary" iconRight="arrow-right" onClick={() => go('addjob')}>Add a job</Button>}>Add a job you’re applying for. We’ll keep its CV, contact and next step together.</EmptyState> : <>
      <div style={{ display:'flex', gap:12, flexWrap:'wrap', alignItems:'center' }}>
        <div style={{ flex:'1 1 260px' }}><Field icon="search" value={q} onChange={setQ} placeholder="Search role or company" /></div>
        <div style={{ overflowX:'auto', maxWidth:'100%' }}><Segmented size="sm" value={f} onChange={setF} options={['All','To send','Sent','Interview','Closed']} /></div>
      </div>
      {!list.length ? <EmptyState icon="search-x" title={`No applications match “${q}”`} actions={<Button onClick={() => { setQ(''); setF('All'); }}>Clear search</Button>}>Try a company name or part of the role.</EmptyState> :
      <Card padding="none">{list.map((a, i) => <button key={a.id} onClick={() => go('application', a.id === 'a1' ? 'To send' : 'Sent')} style={{ width:'100%', display:'flex', gap:16, alignItems:'center', flexWrap:'wrap', padding:'16px 20px', border:0, borderTop: i ? '1px solid var(--border-subtle)' : 0, background:'transparent', textAlign:'left', cursor:'pointer', font:'inherit' }}>
        <div style={{ flex:'1 1 240px', minWidth:0 }}><div style={{ fontWeight:650, color:'var(--text-strong)' }}>{a.role}</div><div style={{ fontSize:'.84rem', color:'var(--text-muted)', marginTop:2 }}>{a.company}</div></div>
        <div style={{ display:'flex', gap:6, flexWrap:'wrap', flex:'0 1 auto' }}><Pill size="sm" tone={RZ_STAGE_TONE[a.stage]}>{a.stage}</Pill><Pill size="sm" icon={a.tailored ? 'git-branch' : 'file'}>{a.cv}</Pill></div>
        <div style={{ flex:'1 1 200px', fontSize:'.84rem', color:'var(--text-body)' }}>{a.next}{a.date && <span style={{ color:'var(--text-muted)' }}> · {a.date}</span>}</div>
        <Icon name="chevron-right" size={18} color="var(--text-muted)" />
      </button>)}</Card>}
    </>}
  </div>;
}
function ApplicationScreen({ state, go, flash, rtw }) {
  const { Card, Button, Field, Select, Pill, Alert, Dialog, Checkbox, Icon } = ONB_DS;
  const sentInit = state === 'Sent';
  const [stage, setStage] = React.useState(sentInit ? 'Sent' : 'To send');
  const [cv, setCv] = React.useState(sentInit ? 'tailored' : null);
  const [snap, setSnap] = React.useState(sentInit ? '25 Oct 2026' : null);
  const [ask, setAsk] = React.useState(false);
  const [att, setAtt] = React.useState(false);
  const cvLabel = cv === 'tailored' ? 'Tailored CV v1 · Clar · English' : 'Base CV v3 · Clar · English';
  return <div style={{ maxWidth:1040, margin:'0 auto', display:'grid', gap:20 }}>
    <div><Button variant="ghost" size="sm" icon="arrow-left" onClick={() => go('applications')}>Applications</Button></div>
    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', gap:16, flexWrap:'wrap' }}>
      <OnbTitle eyebrow="Northstar People · Bucharest · hybrid" title="Business Systems Analyst — Automation"></OnbTitle>
      <div style={{ width:200 }}><Select label="Stage" value={stage} onChange={setStage} options={['To send','Sent','Interview','Offer','Closed']} /></div>
    </div>
    <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(min(100%,320px),1fr))', gap:20, alignItems:'start' }}>
      <div style={{ display:'grid', gap:16, minWidth:0 }}>
        <Card><div style={{ display:'grid', gap:14 }}>
          <div style={{ font:'var(--type-section-title)', color:'var(--text-strong)' }}>CV for this job</div>
          {cv ? <div style={{ display:'flex', gap:12, alignItems:'center', flexWrap:'wrap' }}>
            <OnbIconTile icon="file-text" size={44} />
            <div style={{ flex:1, minWidth:180 }}><div style={{ fontWeight:650, color:'var(--text-strong)' }}>{cvLabel}</div><div style={{ marginTop:6 }}><Pill size="sm" tone={cv === 'tailored' ? 'good' : 'neutral'} icon={cv === 'tailored' ? 'git-branch' : 'file'}>{cv === 'tailored' ? 'Tailored for this job' : 'Not tailored'}</Pill></div></div>
            <Button size="sm" icon="eye" onClick={() => go('preview')}>Preview</Button>
          </div> : <div style={{ display:'grid', gap:12 }}>
            <div style={{ fontSize:'.88rem', color:'var(--text-muted)', lineHeight:1.5 }}>Not tailored yet. See how you match and get a version for this job — about 2 minutes.</div>
            <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}><Button variant="primary" iconRight="arrow-right" onClick={() => go('requirements')}>Tailor my CV</Button><Button onClick={() => setCv('base')}>Attach Base CV v3 as is</Button></div>
          </div>}
        </div></Card>
        {!rtw && <Alert tone="warn" title="Right to work in Romania still needs an answer" action={<Button size="sm" onClick={() => go('match')}>Answer</Button>}>The job requires it. It doesn’t change your score.</Alert>}
        <Card><div style={{ display:'grid', gap:12 }}>
          <div style={{ font:'var(--type-section-title)', color:'var(--text-strong)' }}>Sent</div>
          {snap ? <div style={{ display:'flex', gap:12, alignItems:'center', flexWrap:'wrap' }}>
            <Icon name="send" size={18} color="var(--pine-600)" />
            <div style={{ flex:1, minWidth:180 }}><div style={{ fontWeight:650, color:'var(--text-strong)' }}>Sent {snap}</div><div style={{ fontSize:'.82rem', color:'var(--text-muted)', marginTop:2 }}>{cvLabel} — copy kept exactly as sent</div></div>
            <Button size="sm" variant="ghost" icon="eye">View sent copy</Button>
          </div> : <div style={{ display:'grid', gap:8, justifyItems:'start' }}>
            <Button variant={cv ? 'primary' : 'secondary'} icon="send" disabled={!cv} onClick={() => setAsk(true)}>I’ve sent this application</Button>
            {!cv && <div style={{ fontSize:'.8rem', color:'var(--text-muted)' }}>Attach a CV first, so we can keep a copy of what you sent.</div>}
          </div>}
        </div></Card>
      </div>
      <div style={{ display:'grid', gap:16 }}>
        <Card><div style={{ display:'grid', gap:14 }}>
          <div style={{ font:'var(--type-section-title)', color:'var(--text-strong)' }}>Contact</div>
          <Field size="sm" label="Name" icon="user" defaultValue="Ana Pop" optional />
          <Field size="sm" label="Email" icon="mail" type="email" defaultValue="ana.pop@northstar.example" optional />
        </div></Card>
        <Card><div style={{ display:'grid', gap:14 }}>
          <div style={{ font:'var(--type-section-title)', color:'var(--text-strong)' }}>Next step</div>
          <Field size="sm" label="What’s next" defaultValue={snap ? 'Follow up with Ana' : 'Tailor CV and send'} />
          <Field size="sm" label="By" icon="calendar" defaultValue={snap ? '30.10.2026' : '27.10.2026'} hint="dd.mm.yyyy" />
          <Field size="sm" label="Notes" multiline rows={3} optional placeholder="Anything to remember" />
        </div></Card>
      </div>
    </div>
    {ask && <Dialog title="Mark as sent?" onClose={() => setAsk(false)} footer={<><Button onClick={() => setAsk(false)}>Cancel</Button><Button variant="primary" icon="send" disabled={!att} onClick={() => { setSnap('25 Oct 2026'); setStage('Sent'); setAsk(false); flash('Marked as sent · copy kept'); }}>Mark as sent</Button></>}>
      <p style={{ margin:'0 0 14px', color:'var(--text-muted)', lineHeight:1.55 }}>We’ll keep a copy of <b style={{ color:'var(--text-strong)', fontWeight:650 }}>{cvLabel}</b> exactly as it is now, so you can always see what Northstar People received.</p>
      <Checkbox checked={att} onChange={setAtt} label="I sent this CV to Northstar People" />
    </Dialog>}
  </div>;
}
function LinkedInScreen({ state, go }) {
  const { Card, Button, Field, Alert, Pill } = ONB_DS;
  const [txt, setTxt] = React.useState(state === 'Compared' ? RZ_APP.linkedin : '');
  const [done, setDone] = React.useState(state === 'Compared');
  const L = RZ_APP.li;
  const ok = txt.trim().length >= 20;
  const Group = ({ title, tone, list, note, action }) => <Card padding="sm"><div style={{ display:'grid', gap:10 }}>
    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', gap:8 }}><b style={{ fontWeight:650, color:'var(--text-strong)' }}>{title}</b><Pill size="sm" shape="round">{list.length}</Pill></div>
    <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>{list.map(s => <Pill key={s} tone={tone} shape="round">{s}</Pill>)}</div>
    {note && <div style={{ fontSize:'.82rem', color:'var(--text-muted)', lineHeight:1.5 }}>{note}</div>}{action}
  </div></Card>;
  return <div style={{ maxWidth:1040, margin:'0 auto', display:'grid', gap:20 }}>
    <OnbTitle title="Check your LinkedIn against your CV">Paste the text from your profile. We’ll show what matches and what differs — nothing changes on either side.</OnbTitle>
    <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(min(100%,360px),1fr))', gap:24, alignItems:'start' }}>
      <div style={{ display:'grid', gap:14 }}>
        <Card><div style={{ display:'grid', gap:14 }}>
          <Field label="Text from your LinkedIn profile" multiline rows={8} value={txt} onChange={v => { setTxt(v); setDone(false); }} hint="Headline, About and Skills. At least 20 characters." error={txt && !ok ? 'Paste a bit more — at least 20 characters.' : undefined} />
          {!txt && <button onClick={() => setTxt(RZ_APP.linkedin)} style={{ justifySelf:'start', background:'none', border:0, padding:0, font:'600 .82rem var(--font-sans)', color:'var(--pine-600)', cursor:'pointer' }}>Use example text</button>}
          <div><Button variant="primary" icon="git-compare" disabled={!ok} onClick={() => setDone(true)}>Compare with my Base CV</Button></div>
        </div></Card>
        <Alert tone="neutral" icon="lock">We only read what you paste. We don’t connect to LinkedIn or change anything there.</Alert>
      </div>
      {done ? <div style={{ display:'grid', gap:12 }}>
        <Group title="In both" tone="good" list={L.both} />
        <Group title="Only on LinkedIn" tone="info" list={L.onlyLi} note="Not added to your Base CV. If they’re true, add them yourself — or answer a question about them." action={<div><Button size="sm" iconRight="arrow-right" onClick={() => go('base')}>Open Base CV</Button></div>} />
        <Group title="Only in your Base CV" tone="neutral" list={L.onlyCv} note="Consider adding these to your LinkedIn profile." />
      </div> : <Card tone="sunken"><div style={{ fontSize:'.88rem', color:'var(--text-muted)', lineHeight:1.6, padding:'8px 4px' }}>Results appear here: skills in both, only on LinkedIn, and only in your CV.</div></Card>}
    </div>
  </div>;
}
Object.assign(window, { ApplicationsScreen, ApplicationScreen, LinkedInScreen });
