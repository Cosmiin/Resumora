repo: Cosmiin/AI-CV-Maker-V2
branch: main

## Last sync
date: 2026-10-25T12:53:33Z

### Updated in this project
- Customer journeys A–G guide and every app screen UX01–UX21 with switchable states
- Onboarding journey (welcome → account → verify → search → import → reading → check details → ready)
- Romanian copy guide + string catalogue from PRD §1–17 and prototype/app.js copy
- Custom dropdown replacing the native select
- Brand renamed to Resumora (resumora.ro); logo and favicons created in-project

## Screen map
| Project screen | Repo files |
|---|---|
| tokens/*.css | prototype/styles.css |
| guidelines/discovery.md | docs/product/prd.md, research/ux/screen-specifications.md, research/ux/journeys.md, research/ux/handoff-v1.md, research/strategy/publication/docs/product/decisions.md |
| guidelines/romanian-copy.md, guidelines/copy/strings.json, guidelines/ro-*.html | docs/product/prd.md, prototype/app.js |
| ui_kits/web-app/journeys.html, routes.js | research/ux/journeys.md, docs/product/prd.md §12, §15–16 |
| ui_kits/web-app/app.html (UX06–UX08, UX10, UX14–UX21) | research/ux/screen-specifications.md, research/ux/handoff-v1.md, docs/product/prd.md §5–10 |
| ui_kits/web-app/onboarding.html | research/ux/screen-specifications.md (UX01–UX05) |
| ui_kits/web-app — Home | research/ux/screen-specifications.md (UX01, UX20), docs/product/prd.md §15 |
| ui_kits/web-app — Add job | research/ux/screen-specifications.md (UX09, UX10) |
| ui_kits/web-app — Match report | research/ux/screen-specifications.md (UX11, UX12), docs/product/prd.md §7–8 |
| ui_kits/web-app — Review changes | research/ux/screen-specifications.md (UX13, UX14) |
| ui_kits/web-app — Preview & download | research/ux/screen-specifications.md (UX15, UX16) |
