/* @ds-bundle: {"format":4,"namespace":"CVizatDesignSystem_0f8e2e","components":[{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Logo","sourcePath":"components/core/Logo.jsx"},{"name":"Pill","sourcePath":"components/core/Pill.jsx"},{"name":"BTN_CSS","sourcePath":"components/core/buttonCss.js"},{"name":"LOGO_WORD_D","sourcePath":"components/core/logoPaths.js"},{"name":"LOGO_W","sourcePath":"components/core/logoPaths.js"},{"name":"DOOR_RAYS","sourcePath":"components/core/logoPaths.js"},{"name":"DOOR_LEAF","sourcePath":"components/core/logoPaths.js"},{"name":"CVDocument","sourcePath":"components/document/CVDocument.jsx"},{"name":"PlanCard","sourcePath":"components/document/PlanCard.jsx"},{"name":"TaskCard","sourcePath":"components/document/TaskCard.jsx"},{"name":"Alert","sourcePath":"components/feedback/Alert.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"EmptyState","sourcePath":"components/feedback/EmptyState.jsx"},{"name":"Spinner","sourcePath":"components/feedback/Spinner.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Dropzone","sourcePath":"components/forms/Dropzone.jsx"},{"name":"Field","sourcePath":"components/forms/Field.jsx"},{"name":"FieldShell","sourcePath":"components/forms/FieldShell.jsx"},{"name":"RadioGroup","sourcePath":"components/forms/RadioGroup.jsx"},{"name":"Segmented","sourcePath":"components/forms/Segmented.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"FIELD_CSS","sourcePath":"components/forms/fieldCss.js"},{"name":"ChangeCard","sourcePath":"components/match/ChangeCard.jsx"},{"name":"FindingGroup","sourcePath":"components/match/FindingGroup.jsx"},{"name":"KeywordRow","sourcePath":"components/match/KeywordRow.jsx"},{"name":"MatchVerdict","sourcePath":"components/match/MatchVerdict.jsx"},{"name":"SideNav","sourcePath":"components/navigation/SideNav.jsx"},{"name":"TopBar","sourcePath":"components/navigation/TopBar.jsx"},{"name":"ProgressBar","sourcePath":"components/progress/ProgressBar.jsx"},{"name":"ScoreRing","sourcePath":"components/progress/ScoreRing.jsx"},{"name":"Stepper","sourcePath":"components/progress/Stepper.jsx"}],"sourceHashes":{"components/core/Button.jsx":"d307644d72d8","components/core/Card.jsx":"68a036792308","components/core/Icon.jsx":"0c0987a71a35","components/core/IconButton.jsx":"4ca5e46f44a1","components/core/Logo.jsx":"9ea507e2d152","components/core/Pill.jsx":"fc4c837fc9c6","components/core/buttonCss.js":"6d97604c0990","components/core/injectCss.js":"e1574583ee92","components/core/logoPaths.js":"2c8644b475b4","components/document/CVDocument.jsx":"001f5aac9933","components/document/PlanCard.jsx":"67110eb4ea32","components/document/TaskCard.jsx":"124a6ac83b2e","components/feedback/Alert.jsx":"c4c6f1a3b701","components/feedback/Dialog.jsx":"9a5705be1ad7","components/feedback/EmptyState.jsx":"1fc04141b2a7","components/feedback/Spinner.jsx":"1ca33b064c1a","components/feedback/Toast.jsx":"9e987b7d9f5a","components/forms/Checkbox.jsx":"4707f453ca7e","components/forms/Dropzone.jsx":"6fb61a5a4c5a","components/forms/Field.jsx":"8d115cbd3e6f","components/forms/FieldShell.jsx":"18bd2db4028d","components/forms/RadioGroup.jsx":"d01acee8a3e3","components/forms/Segmented.jsx":"16bcb35be0f2","components/forms/Select.jsx":"bfc837f4e1fe","components/forms/fieldCss.js":"bca0b7087ac4","components/match/ChangeCard.jsx":"c2e38c6cb7cf","components/match/FindingGroup.jsx":"458e64884ae1","components/match/KeywordRow.jsx":"5767071491cf","components/match/MatchVerdict.jsx":"38aa09d08841","components/navigation/SideNav.jsx":"716d675a5255","components/navigation/TopBar.jsx":"ea0651cdabd9","components/progress/ProgressBar.jsx":"dcce68785950","components/progress/ScoreRing.jsx":"954173707145","components/progress/Stepper.jsx":"78cb96a40ae3","ui_kits/web-app/AddJob.jsx":"636748b17488","ui_kits/web-app/App.jsx":"dc13e1c99c45","ui_kits/web-app/AppShell.jsx":"c3239f240430","ui_kits/web-app/Download.jsx":"b2644fe65aaa","ui_kits/web-app/Home.jsx":"55d8439814a6","ui_kits/web-app/Improve.jsx":"2131dde9076e","ui_kits/web-app/Journeys.jsx":"c4de76492828","ui_kits/web-app/MatchReport.jsx":"aa74a4d30dfc","ui_kits/web-app/Mobile.jsx":"0012c26cabec","ui_kits/web-app/OnbApp.jsx":"e647496bb3b8","ui_kits/web-app/OnbImport.jsx":"0adaa056163b","ui_kits/web-app/OnbReview.jsx":"cd4362a3f42e","ui_kits/web-app/OnbShared.jsx":"0c6497631827","ui_kits/web-app/OnbStart.jsx":"aabd7d759ca9","ui_kits/web-app/ScrAccount.jsx":"6388c1c7c763","ui_kits/web-app/ScrApps.jsx":"4c8f4e0d90ed","ui_kits/web-app/ScrBase.jsx":"1214e5137a96","ui_kits/web-app/ScrEditor.jsx":"5427ded20d02","ui_kits/web-app/ScrEnrich.jsx":"4d8a3e36a3a2","ui_kits/web-app/ScrJobs.jsx":"426f1fc962c2","ui_kits/web-app/ScrSystem.jsx":"40c0bbed30e9","ui_kits/web-app/appdata.js":"4755afb195f8","ui_kits/web-app/data.js":"86649f5b41e5","ui_kits/web-app/ios-frame.jsx":"24642b887be3","ui_kits/web-app/routes.js":"625fb466e3d4"},"inlinedExternals":[],"unexposedExports":[{"name":"injectCss","sourcePath":"components/core/injectCss.js"}]} */

(() => {

const __ds_ns = (window.CVizatDesignSystem_0f8e2e = window.CVizatDesignSystem_0f8e2e || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Card.jsx
try { (() => {
function Card({
  tone = 'default',
  padding = 'md',
  interactive,
  selected,
  children,
  onClick,
  style
}) {
  const bg = {
    default: 'var(--surface-card)',
    hero: 'var(--surface-hero)',
    sunken: 'var(--surface-sunken)',
    inverse: 'var(--surface-inverse)'
  }[tone];
  const pad = {
    none: 0,
    sm: 'var(--space-6)',
    md: 'var(--pad-card)',
    lg: 'var(--pad-hero)'
  }[padding];
  const border = selected ? '2px solid var(--border-selected)' : tone === 'hero' ? '1px solid #d6e4d9' : tone === 'inverse' ? '1px solid transparent' : '1px solid var(--border-subtle)';
  const Tag = onClick ? 'button' : 'div';
  return /*#__PURE__*/React.createElement(Tag, {
    onClick: onClick,
    style: {
      display: 'block',
      width: '100%',
      textAlign: 'left',
      font: 'inherit',
      color: tone === 'inverse' ? 'var(--text-on-inverse)' : 'inherit',
      background: bg,
      border,
      borderRadius: tone === 'hero' ? 'var(--radius-hero)' : 'var(--radius-card)',
      padding: pad,
      minWidth: 0,
      cursor: onClick ? 'pointer' : undefined,
      transition: 'border-color var(--dur-fast) var(--ease-out), box-shadow var(--dur-fast) var(--ease-out)',
      boxShadow: interactive ? 'var(--shadow-card)' : 'none',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/buttonCss.js
try { (() => {
const BTN_CSS = ".cvz-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:var(--control-height);padding:10px 16px;border-radius:var(--radius-md);border:1px solid var(--border-subtle);background:var(--surface-card);color:var(--text-strong);font:var(--weight-semibold) var(--text-sm)/1.3 var(--font-sans);cursor:pointer;text-decoration:none;text-align:center;transition:background var(--dur-fast) var(--ease-out),transform var(--dur-fast) var(--ease-out),box-shadow var(--dur-fast) var(--ease-out);box-shadow:var(--shadow-press-secondary);-webkit-tap-highlight-color:transparent}\n.cvz-btn:hover{background:var(--action-secondary-hover)}\n.cvz-btn:active:not(:disabled){transform:translateY(2px);box-shadow:none}\n.cvz-btn--primary{background:var(--action-primary);border-color:var(--action-primary);color:var(--text-on-primary);box-shadow:var(--shadow-press)}\n.cvz-btn--primary:hover{background:var(--action-primary-hover);border-color:var(--action-primary-hover)}\n.cvz-btn--ghost{background:transparent;border-color:transparent;box-shadow:none;color:var(--text-accent)}\n.cvz-btn--ghost:hover{background:var(--surface-sunken)}\n.cvz-btn--danger{background:var(--surface-card);border-color:var(--status-bad-border);color:var(--action-danger)}\n.cvz-btn--danger:hover{background:var(--status-bad-bg)}\n.cvz-btn--sm{min-height:var(--control-height-sm);font-size:.75rem;padding:7px 10px;gap:6px}\n.cvz-btn--lg{min-height:50px;padding:13px 22px;font-size:.95rem;border-radius:var(--radius-lg)}\n.cvz-btn--full{width:100%}\n.cvz-btn:disabled{opacity:.45;cursor:not-allowed}\n.cvz-btn--icon{padding:0;width:var(--control-height);flex-shrink:0}\n.cvz-btn--icon.cvz-btn--sm{width:var(--control-height-sm)}\n.cvz-spin{width:16px;height:16px;border:2px solid currentColor;border-right-color:transparent;border-radius:50%;animation:cvz-spin .8s linear infinite}\n@keyframes cvz-spin{to{transform:rotate(360deg)}}\n@media (max-width:760px){.cvz-btn{min-height:var(--control-height-touch)}}";
Object.assign(__ds_scope, { BTN_CSS });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/buttonCss.js", error: String((e && e.message) || e) }); }

// components/core/injectCss.js
try { (() => {
const done = new Set();
function injectCss(id, css) {
  if (typeof document === 'undefined' || done.has(id)) return;
  done.add(id);
  const s = document.createElement('style');
  s.setAttribute('data-cvz', id);
  s.textContent = css;
  document.head.appendChild(s);
}
Object.assign(__ds_scope, { injectCss });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/injectCss.js", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
const CSS = '.cvz-icon{display:inline-block;flex-shrink:0;background:currentColor;-webkit-mask:var(--cvz-icon) center/contain no-repeat;mask:var(--cvz-icon) center/contain no-repeat;vertical-align:middle}';
function Icon({
  name,
  size = 18,
  color,
  label,
  style
}) {
  __ds_scope.injectCss('icon', CSS);
  const url = 'url("https://unpkg.com/lucide-static@0.460.0/icons/' + name + '.svg")';
  return /*#__PURE__*/React.createElement("span", {
    className: "cvz-icon",
    role: label ? 'img' : undefined,
    "aria-label": label,
    "aria-hidden": label ? undefined : true,
    style: {
      width: size,
      height: size,
      color,
      '--cvz-icon': url,
      ...style
    }
  });
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function Button({
  variant = 'secondary',
  size = 'md',
  icon,
  iconRight,
  fullWidth,
  loading,
  disabled,
  children,
  onClick,
  type = 'button',
  href,
  style
}) {
  __ds_scope.injectCss('btn', __ds_scope.BTN_CSS);
  const cls = ['cvz-btn', 'cvz-btn--' + variant, size !== 'md' && 'cvz-btn--' + size, fullWidth && 'cvz-btn--full'].filter(Boolean).join(' ');
  const isz = size === 'sm' ? 16 : 18;
  const inner = /*#__PURE__*/React.createElement(React.Fragment, null, loading ? /*#__PURE__*/React.createElement("span", {
    className: "cvz-spin",
    "aria-hidden": "true"
  }) : icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: isz
  }), children, iconRight && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconRight,
    size: isz
  }));
  if (href) return /*#__PURE__*/React.createElement("a", {
    className: cls,
    href: href,
    style: style
  }, inner);
  return /*#__PURE__*/React.createElement("button", {
    type: type,
    className: cls,
    disabled: disabled || loading,
    "aria-busy": loading || undefined,
    onClick: onClick,
    style: style
  }, inner);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function IconButton({
  icon,
  label,
  variant = 'ghost',
  size = 'md',
  onClick,
  disabled
}) {
  __ds_scope.injectCss('btn', __ds_scope.BTN_CSS);
  const cls = ['cvz-btn', 'cvz-btn--icon', 'cvz-btn--' + variant, size === 'sm' && 'cvz-btn--sm'].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: cls,
    "aria-label": label,
    title: label,
    onClick: onClick,
    disabled: disabled
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: size === 'sm' ? 16 : 18
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Pill.jsx
try { (() => {
const TONES = {
  neutral: 'neutral',
  good: 'good',
  warn: 'warn',
  bad: 'bad',
  info: 'info'
};
function Pill({
  tone = 'neutral',
  icon,
  children,
  size = 'md',
  shape = 'tag'
}) {
  const t = TONES[tone] || 'neutral';
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      border: '1px solid var(--status-' + t + '-border)',
      background: 'var(--status-' + t + '-bg)',
      color: 'var(--status-' + t + '-fg)',
      borderRadius: shape === 'round' ? 'var(--radius-pill)' : 'var(--radius-sm)',
      padding: size === 'sm' ? '2px 7px' : '4px 9px',
      fontSize: size === 'sm' ? '.68rem' : '.72rem',
      fontWeight: 600,
      lineHeight: 1.35,
      fontFamily: 'var(--font-sans)',
      whiteSpace: 'nowrap'
    }
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: size === 'sm' ? 12 : 14
  }), children);
}
Object.assign(__ds_scope, { Pill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Pill.jsx", error: String((e && e.message) || e) }); }

// components/core/logoPaths.js
try { (() => {
const LOGO_WORD_D = "M86.91 47L78 47L78 10.47L93.55 10.47Q96.60 10.47 99.09 10.94Q101.58 11.41 103.49 12.32Q105.40 13.24 106.73 14.54Q108.06 15.84 108.72 17.53Q109.38 19.21 109.38 21.26L109.38 21.26Q109.38 23.20 108.77 24.75Q108.17 26.30 106.92 27.46Q105.68 28.62 103.79 29.34Q101.91 30.06 99.42 30.39L99.42 30.39L99.42 31.23Q102.58 31.56 104.32 32.64Q106.06 33.72 107.00 35.49Q107.94 37.26 108.66 39.75L108.66 39.75L110.77 47L100.86 47L99.25 40.30Q98.76 38.09 97.90 36.87Q97.04 35.65 95.71 35.18Q94.38 34.71 92.39 34.71L92.39 34.71L86.91 34.71L86.91 47ZM86.91 17.22L86.91 28.13L92.94 28.13Q96.32 28.13 98.20 26.80Q100.08 25.47 100.08 22.65L100.08 22.65Q100.08 19.88 98.37 18.55Q96.65 17.22 93.17 17.22L93.17 17.22L86.91 17.22ZM129.59 47.77L129.59 47.77Q125.93 47.77 123.06 46.81Q120.18 45.84 118.16 43.96Q116.14 42.07 115.08 39.31Q114.03 36.54 114.03 32.94L114.03 32.94Q114.03 29.45 115.06 26.52Q116.08 23.59 117.99 21.46Q119.90 19.32 122.70 18.16Q125.49 17.00 128.98 17.00L128.98 17.00Q132.52 17.00 135.20 18.13Q137.89 19.27 139.63 21.48Q141.38 23.70 142.21 26.88Q143.04 30.06 142.76 34.16L142.76 34.16L122.61 34.32Q122.89 37.70 124.55 39.36L124.55 39.36Q126.49 41.41 129.53 41.41L129.53 41.41Q131.03 41.41 132.02 40.99Q133.02 40.58 133.65 39.94Q134.29 39.31 134.65 38.53Q135.01 37.76 135.23 37.04L135.23 37.04L142.98 38.70Q142.54 40.75 141.57 42.41Q140.60 44.07 138.97 45.28Q137.34 46.50 135.04 47.14Q132.74 47.77 129.59 47.77ZM122.83 29.68L122.83 29.68L134.62 29.56Q134.62 28.18 134.18 27.13L134.18 27.13Q133.46 25.41 132.08 24.61Q130.69 23.81 129.09 23.81L129.09 23.81Q127.15 23.81 125.68 24.86Q124.22 25.91 123.39 27.90L123.39 27.90Q123.06 28.68 122.83 29.68ZM160.14 47.77L160.14 47.77Q157.21 47.77 154.83 47.25Q152.45 46.72 150.68 45.73Q148.90 44.73 147.77 43.32Q146.63 41.91 146.19 40.19L146.19 40.19L152.83 37.26Q153.22 38.20 154.19 39.17Q155.16 40.14 156.79 40.75Q158.42 41.35 160.75 41.35L160.75 41.35Q162.96 41.35 164.21 40.72Q165.45 40.08 165.45 38.86L165.45 38.86Q165.45 37.98 164.76 37.45Q164.07 36.93 162.69 36.51Q161.30 36.10 159.25 35.71L159.25 35.71Q157.15 35.27 154.99 34.68Q152.83 34.10 150.95 33.08Q149.07 32.06 147.94 30.37Q146.80 28.68 146.80 26.08L146.80 26.08Q146.80 23.37 148.24 21.35Q149.68 19.32 152.53 18.16Q155.38 17.00 159.48 17.00L159.48 17.00Q163.13 17.00 165.90 17.94Q168.66 18.88 170.52 20.63Q172.37 22.37 173.09 24.80L173.09 24.80L165.95 27.35Q165.68 26.13 164.82 25.25Q163.96 24.36 162.66 23.89Q161.36 23.42 159.59 23.42L159.59 23.42Q157.43 23.42 156.24 24.08Q155.05 24.75 155.05 25.86L155.05 25.86Q155.05 26.74 155.85 27.32Q156.65 27.90 158.15 28.29Q159.64 28.68 161.69 29.12L161.69 29.12Q163.85 29.56 165.98 30.15Q168.11 30.73 169.85 31.70Q171.60 32.66 172.62 34.24Q173.65 35.82 173.65 38.31L173.65 38.31Q173.65 41.24 172.10 43.37Q170.55 45.51 167.53 46.64Q164.51 47.77 160.14 47.77ZM188.59 47.77L188.59 47.77Q183.39 47.77 180.76 44.26Q178.13 40.75 178.13 33.55L178.13 33.55L178.13 17.77L187.10 17.77L187.10 32.39Q187.10 36.48 188.31 38.50Q189.53 40.52 192.02 40.52L192.02 40.52Q193.52 40.52 194.60 39.78Q195.68 39.03 196.42 37.67Q197.17 36.32 197.53 34.55Q197.89 32.77 197.89 30.67L197.89 30.67L197.89 17.77L206.80 17.77L206.80 47L199.72 47L199.55 37.98L198.44 37.98Q197.61 41.41 196.37 43.60Q195.12 45.78 193.24 46.78Q191.36 47.77 188.59 47.77ZM222.58 47L213.66 47L213.66 17.77L220.69 17.77L220.80 26.35L221.91 26.35Q222.69 23.20 223.96 21.12Q225.23 19.05 227.06 18.02Q228.89 17.00 231.32 17.00L231.32 17.00Q233.87 17.00 235.56 18.08Q237.24 19.16 238.24 21.23Q239.24 23.31 239.57 26.35L239.57 26.35L240.51 26.35Q241.39 23.09 242.83 21.01Q244.27 18.94 246.27 17.97Q248.26 17.00 250.58 17.00L250.58 17.00Q253.07 17.00 254.93 17.97Q256.78 18.94 258.03 20.85Q259.27 22.76 259.88 25.61Q260.49 28.46 260.49 32.22L260.49 32.22L260.49 47L251.52 47L251.52 33.33Q251.52 30.39 251.05 28.46Q250.58 26.52 249.59 25.55Q248.59 24.58 247.04 24.58L247.04 24.58Q245.27 24.58 244.02 25.75Q242.78 26.91 242.11 28.98Q241.45 31.06 241.45 33.66L241.45 33.66L241.45 47L232.70 47L232.70 33.49Q232.70 30.45 232.18 28.51Q231.65 26.58 230.63 25.58Q229.61 24.58 228.06 24.58L228.06 24.58Q226.28 24.58 225.07 25.75Q223.85 26.91 223.21 28.98Q222.58 31.06 222.58 33.66L222.58 33.66L222.58 47ZM280.42 47.77L280.42 47.77Q275.99 47.77 272.58 46.06Q269.18 44.34 267.24 40.91Q265.31 37.48 265.31 32.33L265.31 32.33Q265.31 27.18 267.24 23.78Q269.18 20.38 272.61 18.69Q276.04 17.00 280.47 17.00L280.47 17.00Q284.90 17.00 288.33 18.72Q291.76 20.43 293.70 23.84Q295.64 27.24 295.64 32.39L295.64 32.39Q295.64 37.65 293.65 41.08Q291.65 44.51 288.19 46.14Q284.73 47.77 280.42 47.77ZM280.69 41.30L280.69 41.30Q282.69 41.30 284.01 40.39Q285.34 39.47 286.01 37.59Q286.67 35.71 286.67 32.94L286.67 32.94Q286.67 30.01 285.95 27.99Q285.23 25.97 283.82 24.89Q282.41 23.81 280.20 23.81L280.20 23.81Q278.31 23.81 276.96 24.72Q275.60 25.63 274.94 27.52Q274.27 29.40 274.27 32.22L274.27 32.22Q274.27 36.76 275.96 39.03Q277.65 41.30 280.69 41.30ZM309.81 47L300.84 47L300.84 17.77L308.15 17.77L308.31 27.68L309.42 27.68Q309.81 23.81 310.89 21.51Q311.97 19.21 313.99 18.16Q316.01 17.11 319.00 17.11L319.00 17.11Q319.44 17.11 319.99 17.14Q320.55 17.17 321.27 17.28L321.27 17.28L320.93 26.80Q320.05 26.35 319.02 26.22Q318.00 26.08 317.23 26.08L317.23 26.08Q315.07 26.08 313.49 26.91Q311.91 27.74 311.00 29.45Q310.08 31.17 309.81 33.77L309.81 33.77L309.81 47ZM332.39 47.77L332.39 47.77Q329.96 47.77 328.07 46.81Q326.19 45.84 325.14 43.98Q324.09 42.13 324.09 39.47L324.09 39.47Q324.09 36.98 325.06 35.35Q326.03 33.72 327.88 32.75Q329.73 31.78 332.34 31.14Q334.94 30.51 338.26 30.01L338.26 30.01Q339.86 29.73 340.94 29.48Q342.02 29.23 342.58 28.68Q343.13 28.13 343.13 27.07L343.13 27.07Q343.13 25.69 342.13 24.69Q341.14 23.70 338.92 23.70L338.92 23.70Q337.37 23.70 336.13 24.25Q334.88 24.80 334.00 25.86Q333.11 26.91 332.67 28.40L332.67 28.40L324.81 26.08Q325.53 23.75 326.83 22.04Q328.13 20.32 329.96 19.19Q331.78 18.05 334.13 17.53Q336.49 17.00 339.14 17.00L339.14 17.00Q343.57 17.00 346.37 18.41Q349.16 19.82 350.52 22.78Q351.87 25.75 351.87 30.39L351.87 30.39L351.87 34.88Q351.87 36.87 351.96 38.89Q352.04 40.91 352.18 42.93Q352.32 44.95 352.54 47L352.54 47L344.68 47Q344.46 45.73 344.24 43.93Q344.01 42.13 343.90 40.25L343.90 40.25L342.85 40.25Q342.08 42.35 340.61 44.09Q339.14 45.84 337.07 46.81Q334.99 47.77 332.39 47.77ZM336.43 41.46L336.43 41.46Q337.43 41.46 338.45 41.11Q339.48 40.75 340.42 40.11Q341.36 39.47 342.13 38.53Q342.91 37.59 343.30 36.48L343.30 36.48L343.18 33.00Q342.69 33.27 342.08 33.44L342.08 33.44Q340.80 33.83 339.50 34.05Q338.20 34.27 336.96 34.52Q335.71 34.77 334.74 35.15Q333.77 35.54 333.22 36.21Q332.67 36.87 332.67 38.03L332.67 38.03Q332.67 39.58 333.72 40.52Q334.77 41.46 336.43 41.46Z";
const LOGO_W = 355;
const DOOR_RAYS = ["M41 14.5L66 5V14L41 21Z", "M41 25L66 23.5V33L41 32Z", "M41 37L66 42.5V53L41 44Z"];
const DOOR_LEAF = "M19 13L30.5 17.5V46.5L19 51Z";
Object.assign(__ds_scope, { LOGO_WORD_D, LOGO_W, DOOR_RAYS, DOOR_LEAF });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/logoPaths.js", error: String((e && e.message) || e) }); }

// components/core/Logo.jsx
try { (() => {
const TONES = {
  default: {
    sq: '#17695d',
    leaf: '#ffffff',
    knob: '#17695d',
    a: '#f9d67a',
    b: '#ffb38a',
    word: '#173b39'
  },
  inverse: {
    sq: '#ffffff',
    leaf: '#17695d',
    knob: '#ffffff',
    a: '#f6c35f',
    b: '#ff9f70',
    word: '#ffffff'
  },
  mono: {
    sq: '#173b39',
    leaf: '#ffffff',
    knob: '#173b39',
    a: '#ffffff',
    b: '#ffffff',
    word: '#173b39'
  }
};
let seq = 0;
function Logo({
  variant = 'full',
  tone = 'default',
  size = 32,
  title = 'Resumora',
  rays
}) {
  const t = TONES[tone] || TONES.default;
  const id = React.useMemo(() => 'rzl' + ++seq, []);
  const showRays = rays ?? size >= 24;
  const mark = /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: id + 'g',
    x1: "0",
    y1: "0",
    x2: "0.35",
    y2: "1"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0",
    stopColor: t.a
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "1",
    stopColor: t.b
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: id + 'r',
    x1: "0",
    y1: "0",
    x2: "1",
    y2: "0"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0",
    stopColor: t.b,
    stopOpacity: ".75"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "1",
    stopColor: t.b,
    stopOpacity: "0"
  })), /*#__PURE__*/React.createElement("clipPath", {
    id: id + 'c'
  }, /*#__PURE__*/React.createElement("rect", {
    width: "64",
    height: "64",
    rx: "16"
  }))), /*#__PURE__*/React.createElement("rect", {
    width: "64",
    height: "64",
    rx: "16",
    fill: t.sq
  }), /*#__PURE__*/React.createElement("g", {
    clipPath: 'url(#' + id + 'c)'
  }, showRays && __ds_scope.DOOR_RAYS.map((d, i) => /*#__PURE__*/React.createElement("path", {
    key: i,
    d: d,
    fill: 'url(#' + id + 'r)',
    opacity: [1, .8, .6][i]
  })), /*#__PURE__*/React.createElement("rect", {
    x: "19",
    y: "13",
    width: "22",
    height: "38",
    rx: "3",
    fill: 'url(#' + id + 'g)'
  }), /*#__PURE__*/React.createElement("path", {
    d: __ds_scope.DOOR_LEAF,
    fill: t.leaf,
    stroke: t.leaf,
    strokeWidth: "2",
    strokeLinejoin: "round"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "27.6",
    cy: "32.5",
    r: "1.9",
    fill: t.knob
  })));
  if (variant === 'mark') return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 64 64",
    role: "img",
    "aria-label": title,
    style: {
      display: 'block',
      flexShrink: 0
    }
  }, mark);
  if (variant === 'wordmark') {
    const w = __ds_scope.LOGO_W - 78;
    return /*#__PURE__*/React.createElement("svg", {
      width: size * w / 64,
      height: size,
      viewBox: '78 0 ' + w + ' 64',
      role: "img",
      "aria-label": title,
      style: {
        display: 'block',
        flexShrink: 0
      }
    }, /*#__PURE__*/React.createElement("path", {
      d: __ds_scope.LOGO_WORD_D,
      fill: t.word
    }));
  }
  return /*#__PURE__*/React.createElement("svg", {
    width: size * __ds_scope.LOGO_W / 64,
    height: size,
    viewBox: '0 0 ' + __ds_scope.LOGO_W + ' 64',
    role: "img",
    "aria-label": title,
    style: {
      display: 'block',
      flexShrink: 0
    }
  }, mark, /*#__PURE__*/React.createElement("path", {
    d: __ds_scope.LOGO_WORD_D,
    fill: t.word
  }));
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Logo.jsx", error: String((e && e.message) || e) }); }

// components/document/CVDocument.jsx
try { (() => {
function CVDocument({
  template = 'clar',
  name,
  titles = [],
  contact,
  sections = [],
  highlight,
  scale = 1
}) {
  const clar = template === 'clar';
  const accent = 'var(--pine-600)';
  return /*#__PURE__*/React.createElement("article", {
    style: {
      background: 'var(--surface-document)',
      color: 'var(--text-document)',
      padding: 36 * scale,
      border: '1px solid #d7dfda',
      borderTop: clar ? '1px solid #d7dfda' : 7 * scale + 'px solid ' + accent,
      borderRadius: 'var(--radius-xs)',
      fontFamily: clar ? 'var(--font-document)' : 'var(--font-sans)',
      fontSize: 13.3 * scale + 'px',
      lineHeight: 1.55,
      boxShadow: 'var(--shadow-document)',
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontSize: (clar ? 27 : 30) * scale,
      letterSpacing: 0,
      fontWeight: 700,
      color: clar ? 'var(--text-document)' : accent,
      fontFamily: clar ? 'var(--font-document)' : 'var(--font-display)'
    }
  }, name), titles.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14 * scale,
      marginTop: 4,
      color: '#334c45'
    }
  }, titles.join(' · ')), contact && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11.5 * scale,
      margin: 10 * scale + 'px 0',
      color: '#334c45'
    }
  }, contact), sections.map((s, i) => /*#__PURE__*/React.createElement("section", {
    key: i
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 12 * scale,
      textTransform: 'uppercase',
      letterSpacing: '.1em',
      padding: clar ? '0 0 ' + 7 * scale + 'px' : 9 * scale + 'px',
      margin: 22 * scale + 'px 0 ' + 10 * scale + 'px',
      borderBottom: clar ? '1px solid #c2d4ca' : 0,
      background: clar ? 'transparent' : '#e9f1eb',
      fontWeight: 700
    }
  }, s.title), s.text && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: '#334c45'
    }
  }, s.text), (s.items || []).map((it, j) => /*#__PURE__*/React.createElement("div", {
    key: j,
    style: {
      marginBottom: 10 * scale
    }
  }, it.heading && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 12,
      fontWeight: 700
    }
  }, /*#__PURE__*/React.createElement("span", null, it.heading), it.dates && /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 400,
      fontSize: 12 * scale,
      color: '#334c45',
      whiteSpace: 'nowrap'
    }
  }, it.dates)), it.sub && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12 * scale,
      color: '#334c45'
    }
  }, it.sub), it.bullets && /*#__PURE__*/React.createElement("ul", {
    style: {
      paddingLeft: 18 * scale,
      margin: 6 * scale + 'px 0 0'
    }
  }, it.bullets.map((b, k) => {
    const hi = highlight && highlight.includes(b);
    return /*#__PURE__*/React.createElement("li", {
      key: k,
      style: {
        margin: 5 * scale + 'px 0',
        fontSize: 12.8 * scale,
        background: hi ? 'var(--marigold-100)' : 'transparent',
        boxShadow: hi ? '0 0 0 3px var(--marigold-100)' : 'none',
        borderRadius: 2
      }
    }, b);
  })))))));
}
Object.assign(__ds_scope, { CVDocument });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/document/CVDocument.jsx", error: String((e && e.message) || e) }); }

// components/document/PlanCard.jsx
try { (() => {
function PlanCard({
  term,
  price = '— RON',
  note,
  features = [],
  selected,
  badge,
  onSelect
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onSelect,
    "aria-pressed": !!selected,
    style: {
      position: 'relative',
      textAlign: 'left',
      font: 'inherit',
      color: 'var(--text-body)',
      background: 'var(--surface-card)',
      border: selected ? '2px solid var(--border-selected)' : '1px solid var(--border-subtle)',
      padding: selected ? 24 : 25,
      borderRadius: 'var(--radius-card)',
      cursor: 'pointer',
      display: 'grid',
      gap: 6,
      minWidth: 0,
      transition: 'border-color var(--dur-fast)'
    }
  }, badge && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: -11,
      left: 22,
      background: 'var(--marigold-300)',
      color: 'var(--pine-900)',
      fontSize: '.7rem',
      fontWeight: 750,
      padding: '3px 9px',
      borderRadius: 'var(--radius-pill)'
    }
  }, badge), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 650,
      fontSize: '.95rem',
      color: 'var(--text-strong)'
    }
  }, term), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: '2rem',
      fontWeight: 700,
      letterSpacing: 'var(--tracking-stat)',
      color: 'var(--text-strong)',
      margin: '10px 0 0'
    }
  }, price), note && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '.78rem',
      color: 'var(--text-muted)'
    }
  }, note), features.length > 0 && /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      padding: 0,
      margin: '14px 0 0',
      display: 'grid',
      gap: 8
    }
  }, features.map((f, i) => /*#__PURE__*/React.createElement("li", {
    key: i,
    style: {
      display: 'flex',
      gap: 8,
      fontSize: '.83rem',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 16,
    color: "var(--text-accent)",
    style: {
      marginTop: 2
    }
  }), f))));
}
Object.assign(__ds_scope, { PlanCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/document/PlanCard.jsx", error: String((e && e.message) || e) }); }

// components/document/TaskCard.jsx
try { (() => {
function TaskCard({
  icon = 'briefcase',
  title,
  children,
  meta,
  onClick,
  emphasis
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    style: {
      display: 'flex',
      gap: 14,
      alignItems: 'flex-start',
      width: '100%',
      padding: 19,
      textAlign: 'left',
      font: 'inherit',
      color: 'var(--text-body)',
      background: emphasis ? 'var(--surface-hero)' : 'var(--surface-card)',
      border: '1px solid ' + (emphasis ? '#d6e4d9' : 'var(--border-subtle)'),
      borderRadius: 'var(--radius-card)',
      cursor: 'pointer',
      transition: 'border-color var(--dur-fast), transform var(--dur-fast) var(--ease-out)'
    },
    onMouseEnter: e => e.currentTarget.style.borderColor = 'var(--border-strong)',
    onMouseLeave: e => e.currentTarget.style.borderColor = emphasis ? '#d6e4d9' : 'var(--border-subtle)'
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 12,
      background: emphasis ? 'var(--action-primary)' : 'var(--surface-hero)',
      color: emphasis ? 'var(--text-on-primary)' : 'var(--text-accent)',
      display: 'grid',
      placeItems: 'center',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 20
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      display: 'block',
      fontSize: '.95rem',
      fontWeight: 650,
      color: 'var(--text-strong)'
    }
  }, title), children && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontSize: '.82rem',
      color: 'var(--text-muted)',
      marginTop: 4,
      lineHeight: 1.5
    }
  }, children), meta && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: 6,
      marginTop: 10,
      flexWrap: 'wrap'
    }
  }, meta)), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)',
      alignSelf: 'center'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-right",
    size: 18
  })));
}
Object.assign(__ds_scope, { TaskCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/document/TaskCard.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Alert.jsx
try { (() => {
const MAP = {
  info: ['info', 'info'],
  good: ['good', 'circle-check'],
  warn: ['warn', 'circle-alert'],
  bad: ['bad', 'circle-x'],
  neutral: ['neutral', 'info']
};
function Alert({
  tone = 'info',
  title,
  children,
  action,
  icon
}) {
  const [t, ic] = MAP[tone] || MAP.info;
  return /*#__PURE__*/React.createElement("div", {
    role: tone === 'bad' ? 'alert' : 'status',
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'flex-start',
      padding: '14px 16px',
      background: 'var(--status-' + t + '-bg)',
      border: '1px solid var(--status-' + t + '-border)',
      borderRadius: 'var(--radius-lg)',
      color: 'var(--text-body)',
      fontSize: '.84rem',
      lineHeight: 1.55
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--status-' + t + '-fg)',
      marginTop: 1
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon || ic,
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      color: 'var(--status-' + t + '-fg)',
      marginBottom: children ? 2 : 0
    }
  }, title), children), action && /*#__PURE__*/React.createElement("div", {
    style: {
      flexShrink: 0,
      alignSelf: 'center'
    }
  }, action));
}
Object.assign(__ds_scope, { Alert });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Alert.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function Dialog({
  open = true,
  title,
  children,
  footer,
  onClose,
  width = 560,
  inline
}) {
  if (!open) return null;
  const box = /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-modal": !inline,
    "aria-label": typeof title === 'string' ? title : undefined,
    style: {
      background: 'var(--surface-card)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-dialog)',
      width: '100%',
      maxWidth: width,
      boxShadow: inline ? 'none' : 'var(--shadow-raised)',
      color: 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 12,
      padding: '22px 22px 0 25px'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      font: 'var(--type-section-title)',
      color: 'var(--text-strong)',
      letterSpacing: 'var(--tracking-heading)'
    }
  }, title), onClose && /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Close",
    size: "sm",
    onClick: onClose
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 25px 0',
      fontSize: '.9rem',
      lineHeight: 1.6
    }
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      justifyContent: 'flex-end',
      flexWrap: 'wrap',
      padding: '22px 25px 25px'
    }
  }, footer), !footer && /*#__PURE__*/React.createElement("div", {
    style: {
      height: 25
    }
  }));
  if (inline) return box;
  return /*#__PURE__*/React.createElement("div", {
    onClick: e => e.target === e.currentTarget && onClose && onClose(),
    style: {
      position: 'fixed',
      inset: 0,
      background: 'var(--backdrop)',
      display: 'grid',
      placeItems: 'center',
      padding: 16,
      zIndex: 40
    }
  }, box);
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/EmptyState.jsx
try { (() => {
function EmptyState({
  icon = 'file-plus',
  title,
  children,
  actions
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '46px 25px',
      display: 'grid',
      justifyItems: 'center',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 56,
      height: 56,
      borderRadius: 16,
      background: 'var(--surface-hero)',
      color: 'var(--text-accent)',
      display: 'grid',
      placeItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 26
  })), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      font: 'var(--type-section-title)',
      color: 'var(--text-strong)'
    }
  }, title), children && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: 'var(--text-muted)',
      maxWidth: 420,
      lineHeight: 1.6,
      fontSize: '.9rem'
    }
  }, children), actions && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      flexWrap: 'wrap',
      justifyContent: 'center',
      marginTop: 4
    }
  }, actions));
}
Object.assign(__ds_scope, { EmptyState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/EmptyState.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Spinner.jsx
try { (() => {
function Spinner({
  size = 40,
  label
}) {
  __ds_scope.injectCss('spinner', '@keyframes cvz-ring{to{transform:rotate(360deg)}}');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      justifyItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    role: "progressbar",
    "aria-label": label || 'Working',
    style: {
      width: size,
      height: size,
      border: (size > 24 ? 4 : 2) + 'px solid var(--pine-200)',
      borderTopColor: 'var(--action-primary)',
      borderRadius: '50%',
      animation: 'cvz-ring 1s linear infinite',
      display: 'block'
    }
  }), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '.85rem',
      color: 'var(--text-muted)'
    }
  }, label));
}
Object.assign(__ds_scope, { Spinner });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Spinner.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function Toast({
  children,
  icon = 'check',
  action,
  onAction,
  floating = true
}) {
  return /*#__PURE__*/React.createElement("div", {
    role: "status",
    "aria-live": "polite",
    style: {
      position: floating ? 'fixed' : 'relative',
      bottom: floating ? 22 : undefined,
      left: floating ? '50%' : undefined,
      transform: floating ? 'translateX(-50%)' : undefined,
      zIndex: 50,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      background: 'var(--surface-inverse)',
      color: 'var(--text-on-inverse)',
      padding: '11px 14px 11px 16px',
      borderRadius: 'var(--radius-md)',
      fontSize: '.85rem',
      boxShadow: 'var(--shadow-toast)',
      maxWidth: 'calc(100vw - 30px)'
    }
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 16,
    color: "var(--pine-200)"
  }), /*#__PURE__*/React.createElement("span", null, children), action && /*#__PURE__*/React.createElement("button", {
    onClick: onAction,
    style: {
      marginLeft: 6,
      background: 'transparent',
      border: 0,
      color: 'var(--marigold-300)',
      font: '700 .82rem var(--font-sans)',
      cursor: 'pointer',
      padding: '4px 6px'
    }
  }, action));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/forms/FieldShell.jsx
try { (() => {
function FieldShell({
  id,
  label,
  hint,
  error,
  success,
  optional,
  children
}) {
  const msg = error || success || hint;
  const kind = error ? 'error' : success ? 'success' : 'hint';
  return /*#__PURE__*/React.createElement("div", {
    className: "rz-field"
  }, label && /*#__PURE__*/React.createElement("div", {
    className: "rz-lrow"
  }, /*#__PURE__*/React.createElement("label", {
    htmlFor: id,
    className: "rz-label"
  }, label), optional && /*#__PURE__*/React.createElement("span", {
    className: "rz-opt"
  }, "Optional")), children, msg && /*#__PURE__*/React.createElement("div", {
    id: id + '-msg',
    className: 'rz-msg rz-msg--' + kind
  }, kind !== 'hint' && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: error ? 'circle-alert' : 'circle-check',
    size: 14
  }), /*#__PURE__*/React.createElement("span", null, msg)));
}
Object.assign(__ds_scope, { FieldShell });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/FieldShell.jsx", error: String((e && e.message) || e) }); }

// components/forms/Segmented.jsx
try { (() => {
function Segmented({
  options = [],
  value,
  onChange,
  size = 'md',
  fullWidth
}) {
  return /*#__PURE__*/React.createElement("div", {
    role: "tablist",
    style: {
      display: fullWidth ? 'flex' : 'inline-flex',
      gap: 4,
      padding: 4,
      background: 'var(--sage-100)',
      borderRadius: 12,
      border: '1px solid var(--sage-150)'
    }
  }, options.map(o => {
    const v = typeof o === 'string' ? o : o.value;
    const l = typeof o === 'string' ? o : o.label;
    const ic = typeof o === 'string' ? null : o.icon;
    const on = v === value;
    return /*#__PURE__*/React.createElement("button", {
      key: v,
      role: "tab",
      "aria-selected": on,
      onClick: () => onChange && onChange(v),
      style: {
        flex: fullWidth ? 1 : undefined,
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 7,
        border: 0,
        borderRadius: 9,
        padding: size === 'sm' ? '6px 12px' : '9px 16px',
        minHeight: size === 'sm' ? 32 : 40,
        font: '650 ' + (size === 'sm' ? '.78rem' : '.86rem') + '/1.2 var(--font-sans)',
        cursor: 'pointer',
        background: on ? 'var(--surface-card)' : 'transparent',
        color: on ? 'var(--text-strong)' : 'var(--sage-600)',
        boxShadow: on ? '0 1px 3px rgba(23,59,57,.12), 0 0 0 1px rgba(23,59,57,.05)' : 'none',
        transition: 'background var(--dur-fast), color var(--dur-fast), box-shadow var(--dur-fast)',
        whiteSpace: 'nowrap'
      }
    }, ic && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: ic,
      size: 16,
      color: on ? 'var(--pine-600)' : undefined
    }), l);
  }));
}
Object.assign(__ds_scope, { Segmented });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Segmented.jsx", error: String((e && e.message) || e) }); }

// components/forms/fieldCss.js
try { (() => {
const FIELD_CSS = ".rz-field{display:grid;gap:8px;min-width:0}\n.rz-lrow{display:flex;justify-content:space-between;align-items:baseline;gap:8px}\n.rz-label{font:650 .86rem/1.35 var(--font-sans);color:var(--text-strong)}\n.rz-opt{font:500 .74rem var(--font-sans);color:var(--text-muted)}\n.rz-control{position:relative;display:flex;align-items:center;gap:10px;min-height:48px;padding:0 14px;background:var(--sage-25);border:1.5px solid var(--sage-200);border-radius:12px;color:var(--text-body);transition:border-color var(--dur-fast) var(--ease-out),background var(--dur-fast) var(--ease-out),box-shadow var(--dur-base) var(--ease-out)}\n.rz-control:hover{border-color:var(--sage-300);background:#fff}\n.rz-control:focus-within{background:#fff;border-color:var(--pine-600);box-shadow:0 0 0 4px var(--pine-100)}\n.rz-control[data-state=error]{border-color:var(--rose-400);background:#fffafa}\n.rz-control[data-state=error]:focus-within{box-shadow:0 0 0 4px var(--rose-50)}\n.rz-control[data-state=success]{border-color:var(--pine-300)}\n.rz-control[data-disabled=true]{background:var(--sage-100);border-color:var(--sage-150);color:var(--text-muted);box-shadow:none}\n.rz-control--multi{align-items:stretch;padding:13px 14px 32px}\n.rz-control--sm{min-height:40px;border-radius:10px}\n.rz-native{flex:1;min-width:0;width:100%;border:0;outline:0;background:transparent;padding:12px 0;font:450 .95rem/1.5 var(--font-sans);color:inherit}\n.rz-native:focus-visible{outline:none}\n.rz-control--sm .rz-native{padding:8px 0;font-size:.88rem}\n.rz-native::placeholder{color:var(--sage-500)}\ntextarea.rz-native{resize:vertical;min-height:96px;padding:0}\nselect.rz-native{appearance:none;-webkit-appearance:none;cursor:pointer;padding-right:26px}\n.rz-adorn{color:var(--sage-500);display:flex;flex-shrink:0;transition:color var(--dur-fast)}\n.rz-control:focus-within .rz-adorn{color:var(--pine-600)}\n.rz-chev{position:absolute;right:14px;pointer-events:none;color:var(--sage-600)}\n.rz-suffix{font:500 .82rem var(--font-sans);color:var(--text-muted);flex-shrink:0}\n.rz-count{position:absolute;right:14px;bottom:9px;font:500 .72rem var(--font-sans);color:var(--text-muted)}\n.rz-count[data-over=true]{color:var(--status-bad-fg)}\n.rz-msg{display:flex;gap:6px;align-items:flex-start;font:500 .78rem/1.45 var(--font-sans);color:var(--text-muted)}\n.rz-msg>span:first-child{margin-top:1px}\n.rz-msg--error{color:var(--status-bad-fg)}.rz-msg--success{color:var(--status-good-fg)}\n.rz-check{position:relative;display:flex;gap:12px;align-items:flex-start;cursor:pointer;font:450 .9rem/1.45 var(--font-sans);color:var(--text-body);-webkit-tap-highlight-color:transparent}\n.rz-check input{position:absolute;opacity:0;width:1px;height:1px;margin:0}\n.rz-box{width:22px;height:22px;border-radius:7px;border:1.5px solid var(--sage-300);background:#fff;display:grid;place-items:center;flex-shrink:0;color:transparent;transition:background var(--dur-fast),border-color var(--dur-fast),box-shadow var(--dur-fast),transform var(--dur-fast) var(--ease-spring)}\n.rz-box--radio{border-radius:50%}\n.rz-check:hover .rz-box{border-color:var(--pine-500)}\n.rz-check input:checked+.rz-box{background:var(--pine-600);border-color:var(--pine-600);color:#fff;box-shadow:0 2px 0 var(--pine-800)}\n.rz-check input:checked+.rz-box--radio{background:#fff;border:7px solid var(--pine-600);box-shadow:none}\n.rz-check:active .rz-box{transform:scale(.92)}\n.rz-check input:focus-visible+.rz-box{outline:3px solid var(--focus-ring);outline-offset:2px}\n.rz-check input:disabled~*{opacity:.5}.rz-check:has(input:disabled){cursor:not-allowed}\n.rz-check--card{padding:14px 16px;border:1.5px solid var(--sage-200);border-radius:14px;background:#fff;transition:border-color var(--dur-fast),background var(--dur-fast)}\n.rz-check--card:hover{border-color:var(--sage-300)}\n.rz-check--card:has(input:checked){border-color:var(--pine-600);background:var(--pine-50)}\n.rz-check-t{display:grid;gap:2px;min-width:0}.rz-check-d{font-size:.8rem;color:var(--text-muted)}\n.rz-drop{display:grid;justify-items:center;gap:10px;text-align:center;padding:30px 24px;border:2px dashed var(--sage-300);border-radius:16px;background:var(--sage-25);cursor:pointer;transition:border-color var(--dur-fast),background var(--dur-fast)}\n.rz-drop:hover,.rz-drop[data-drag=true]{border-color:var(--pine-600);background:var(--pine-50)}\n.rz-drop:focus-within{outline:3px solid var(--focus-ring);outline-offset:3px}\n.rz-drop input{position:absolute;opacity:0;width:1px;height:1px}\n.rz-drop-ic{width:52px;height:52px;border-radius:16px;background:var(--pine-100);color:var(--pine-600);display:grid;place-items:center;transition:transform var(--dur-base) var(--ease-spring)}\n.rz-drop[data-drag=true] .rz-drop-ic{transform:translateY(-4px)}\n.rz-file{display:flex;align-items:center;gap:12px;padding:12px 12px 12px 14px;border:1.5px solid var(--pine-300);border-radius:14px;background:#fff}\n.rz-select{position:relative;min-width:0}\n.rz-trigger{width:100%;text-align:left;cursor:pointer;font:inherit;-webkit-tap-highlight-color:transparent}\n.rz-trigger:focus-visible{outline:none}\n.rz-trigger[data-open=true]{background:#fff;border-color:var(--pine-600);box-shadow:0 0 0 4px var(--pine-100)}\n.rz-trigger:disabled{cursor:not-allowed}\n.rz-val{flex:1;min-width:0;padding:12px 0;font:500 .95rem/1.5 var(--font-sans);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--text-body)}\n.rz-val[data-ph=true]{color:var(--sage-500);font-weight:450}\n.rz-control--sm .rz-val{padding:8px 0;font-size:.88rem}\n.rz-chev2{color:var(--sage-600);display:flex;transition:transform var(--dur-base) var(--ease-out),color var(--dur-fast)}\n.rz-trigger[data-open=true] .rz-chev2{transform:rotate(180deg);color:var(--pine-600)}\n.rz-pop{position:absolute;left:0;right:0;top:calc(100% + 6px);z-index:30;background:#fff;border:1px solid var(--sage-200);border-radius:14px;box-shadow:0 14px 34px rgba(23,59,57,.14),0 2px 6px rgba(23,59,57,.06);padding:6px;animation:rz-pop 160ms var(--ease-out);transform-origin:top center}\n.rz-pop[data-up=true]{top:auto;bottom:calc(100% + 6px);transform-origin:bottom center}\n@keyframes rz-pop{from{opacity:0;transform:translateY(-4px) scale(.98)}to{opacity:1;transform:none}}\n.rz-list{list-style:none;margin:0;padding:0;max-height:264px;overflow:auto;display:grid;gap:2px;overscroll-behavior:contain}\n.rz-oi{display:flex;align-items:center;gap:11px;padding:9px 10px;border-radius:9px;cursor:pointer;color:var(--text-body);font:500 .9rem/1.35 var(--font-sans);transition:background var(--dur-fast)}\n.rz-oi[data-active=true]{background:var(--sage-50)}\n.rz-oi[aria-selected=true]{color:var(--pine-700);font-weight:650;background:var(--pine-50)}\n.rz-oi[aria-selected=true][data-active=true]{background:var(--pine-100)}\n.rz-oi[aria-disabled=true]{opacity:.45;cursor:not-allowed}\n.rz-oi-ic{width:32px;height:32px;border-radius:9px;background:var(--sage-100);color:var(--sage-600);display:grid;place-items:center;flex-shrink:0;transition:background var(--dur-fast),color var(--dur-fast)}\n.rz-oi[aria-selected=true] .rz-oi-ic{background:#fff;color:var(--pine-600);box-shadow:0 0 0 1px var(--pine-200)}\n.rz-oi-t{flex:1;min-width:0}\n.rz-oi-d{display:block;font-weight:450;font-size:.77rem;color:var(--text-muted);margin-top:2px;line-height:1.4}\n.rz-oi-ck{color:var(--pine-600);display:flex;flex-shrink:0}\n.rz-search{display:flex;align-items:center;gap:8px;padding:2px 10px 8px;margin:0 0 6px;border-bottom:1px solid var(--sage-150);color:var(--sage-500)}\n.rz-search input{flex:1;min-width:0;border:0;outline:0;font:450 .9rem var(--font-sans);padding:7px 0;background:transparent;color:var(--text-body)}\n.rz-empty{padding:14px 12px;font-size:.84rem;color:var(--text-muted)}\n.rz-grp{padding:9px 10px 4px;font:700 .66rem var(--font-sans);letter-spacing:.12em;text-transform:uppercase;color:var(--text-muted)}";
Object.assign(__ds_scope, { FIELD_CSS });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/fieldCss.js", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  label,
  description,
  checked,
  defaultChecked,
  onChange,
  disabled,
  variant = 'plain'
}) {
  __ds_scope.injectCss('field', __ds_scope.FIELD_CSS);
  return /*#__PURE__*/React.createElement("label", {
    className: 'rz-check' + (variant === 'card' ? ' rz-check--card' : '')
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: checked,
    defaultChecked: defaultChecked,
    disabled: disabled,
    onChange: onChange && (e => onChange(e.target.checked, e))
  }), /*#__PURE__*/React.createElement("span", {
    className: "rz-box"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 14,
    style: {
      strokeWidth: 3
    }
  })), /*#__PURE__*/React.createElement("span", {
    className: "rz-check-t"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: description ? 650 : 450,
      color: 'var(--text-strong)'
    }
  }, label), description && /*#__PURE__*/React.createElement("span", {
    className: "rz-check-d"
  }, description)));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Dropzone.jsx
try { (() => {
function Dropzone({
  title = 'Drop your CV here',
  accept = '.pdf,.docx',
  acceptLabel = 'PDF or DOCX, up to 10 MB',
  file,
  onFile,
  onRemove
}) {
  __ds_scope.injectCss('field', __ds_scope.FIELD_CSS);
  const [drag, setDrag] = React.useState(false);
  if (file) return /*#__PURE__*/React.createElement("div", {
    className: "rz-file"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 12,
      background: 'var(--pine-100)',
      color: 'var(--pine-600)',
      display: 'grid',
      placeItems: 'center',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "file-text",
    size: 20
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      display: 'block',
      fontSize: '.9rem',
      fontWeight: 650,
      color: 'var(--text-strong)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, file.name), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 5,
      fontSize: '.76rem',
      color: 'var(--status-good-fg)',
      marginTop: 2
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "circle-check",
    size: 13
  }), "Uploaded", file.size ? ' · ' + file.size : '')), onRemove && /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Remove file",
    size: "sm",
    onClick: onRemove
  }));
  const pick = f => f && onFile && onFile({
    name: f.name,
    size: Math.max(1, Math.round(f.size / 1024)) + ' KB',
    file: f
  });
  return /*#__PURE__*/React.createElement("label", {
    className: "rz-drop",
    "data-drag": drag,
    onDragOver: e => {
      e.preventDefault();
      setDrag(true);
    },
    onDragLeave: () => setDrag(false),
    onDrop: e => {
      e.preventDefault();
      setDrag(false);
      pick(e.dataTransfer.files[0]);
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "file",
    accept: accept,
    onChange: e => pick(e.target.files[0])
  }), /*#__PURE__*/React.createElement("span", {
    className: "rz-drop-ic"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "upload",
    size: 24
  })), /*#__PURE__*/React.createElement("b", {
    style: {
      font: '650 1rem var(--font-display)',
      color: 'var(--text-strong)'
    }
  }, drag ? 'Drop to upload' : title), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '.82rem',
      color: 'var(--text-muted)'
    }
  }, "or ", /*#__PURE__*/React.createElement("u", {
    style: {
      color: 'var(--text-accent)',
      fontWeight: 650,
      textUnderlineOffset: 2
    }
  }, "browse files"), " \xB7 ", acceptLabel));
}
Object.assign(__ds_scope, { Dropzone });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Dropzone.jsx", error: String((e && e.message) || e) }); }

// components/forms/Field.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
let n = 0;
function Field({
  id,
  label,
  hint,
  error,
  success,
  optional,
  icon,
  suffix,
  multiline,
  rows = 4,
  maxLength,
  value,
  defaultValue,
  placeholder,
  onChange,
  type = 'text',
  disabled,
  size = 'md'
}) {
  __ds_scope.injectCss('field', __ds_scope.FIELD_CSS);
  const fid = React.useMemo(() => id || 'rz-f' + ++n, [id]);
  const [len, setLen] = React.useState(String(value ?? defaultValue ?? '').length);
  const cur = value != null ? String(value).length : len;
  const state = error ? 'error' : success ? 'success' : undefined;
  const p = {
    id: fid,
    className: 'rz-native',
    value,
    defaultValue,
    placeholder,
    disabled,
    onChange: e => {
      setLen(e.target.value.length);
      onChange && onChange(e.target.value, e);
    },
    'aria-invalid': !!error,
    'aria-describedby': error || success || hint ? fid + '-msg' : undefined
  };
  return /*#__PURE__*/React.createElement(__ds_scope.FieldShell, {
    id: fid,
    label: label,
    hint: hint,
    error: error,
    success: success,
    optional: optional
  }, /*#__PURE__*/React.createElement("div", {
    className: 'rz-control' + (multiline ? ' rz-control--multi' : '') + (size === 'sm' ? ' rz-control--sm' : ''),
    "data-state": state,
    "data-disabled": !!disabled
  }, icon && !multiline && /*#__PURE__*/React.createElement("span", {
    className: "rz-adorn"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 18
  })), multiline ? /*#__PURE__*/React.createElement("textarea", _extends({
    rows: rows
  }, p)) : /*#__PURE__*/React.createElement("input", _extends({
    type: type
  }, p)), suffix && !multiline && /*#__PURE__*/React.createElement("span", {
    className: "rz-suffix"
  }, suffix), success && !multiline && /*#__PURE__*/React.createElement("span", {
    className: "rz-adorn",
    style: {
      color: 'var(--status-good-fg)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "circle-check",
    size: 18
  })), maxLength && /*#__PURE__*/React.createElement("span", {
    className: "rz-count",
    "data-over": cur > maxLength
  }, cur, " / ", maxLength)));
}
Object.assign(__ds_scope, { Field });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Field.jsx", error: String((e && e.message) || e) }); }

// components/forms/RadioGroup.jsx
try { (() => {
let n = 0;
function RadioGroup({
  label,
  name,
  options = [],
  value,
  onChange,
  variant = 'card',
  direction = 'column'
}) {
  __ds_scope.injectCss('field', __ds_scope.FIELD_CSS);
  const nm = React.useMemo(() => name || 'rz-r' + ++n, [name]);
  return /*#__PURE__*/React.createElement("fieldset", {
    style: {
      border: 0,
      padding: 0,
      margin: 0,
      display: 'grid',
      gap: 10,
      minWidth: 0
    }
  }, label && /*#__PURE__*/React.createElement("legend", {
    className: "rz-label",
    style: {
      padding: 0,
      marginBottom: 8
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: direction,
      gap: 10,
      flexWrap: 'wrap'
    }
  }, options.map(o => {
    const v = typeof o === 'string' ? o : o.value;
    const l = typeof o === 'string' ? o : o.label;
    return /*#__PURE__*/React.createElement("label", {
      key: v,
      className: 'rz-check' + (variant === 'card' ? ' rz-check--card' : ''),
      style: {
        flex: direction === 'row' ? '1 1 0' : undefined
      }
    }, /*#__PURE__*/React.createElement("input", {
      type: "radio",
      name: nm,
      value: v,
      checked: value === v,
      onChange: () => onChange && onChange(v)
    }), /*#__PURE__*/React.createElement("span", {
      className: "rz-box rz-box--radio"
    }), /*#__PURE__*/React.createElement("span", {
      className: "rz-check-t"
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontWeight: o.description ? 650 : 500,
        color: 'var(--text-strong)'
      }
    }, l), o.description && /*#__PURE__*/React.createElement("span", {
      className: "rz-check-d"
    }, o.description)));
  })));
}
Object.assign(__ds_scope, { RadioGroup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/RadioGroup.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
let n = 0;
const norm = s => String(s || '').toLocaleLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
function Select({
  id,
  label,
  hint,
  error,
  optional,
  icon,
  options = [],
  value,
  defaultValue,
  onChange,
  disabled,
  size = 'md',
  placeholder = 'Choose an option',
  searchable,
  searchPlaceholder = 'Search…',
  emptyText = 'No matches',
  defaultOpen = false
}) {
  __ds_scope.injectCss('field', __ds_scope.FIELD_CSS);
  const fid = React.useMemo(() => id || 'rz-s' + ++n, [id]);
  const opts = options.map(o => typeof o === 'string' ? {
    value: o,
    label: o
  } : o);
  const [inner, setInner] = React.useState(defaultValue ?? '');
  const cur = value !== undefined ? value : inner;
  const [open, setOpen] = React.useState(defaultOpen);
  const [q, setQ] = React.useState('');
  const [active, setActive] = React.useState(() => Math.max(0, opts.findIndex(o => o.value === (value !== undefined ? value : defaultValue))));
  const [up, setUp] = React.useState(false);
  const root = React.useRef(null),
    trig = React.useRef(null),
    list = React.useRef(null),
    typed = React.useRef({
      s: '',
      t: 0
    });
  const shown = searchable && q ? opts.filter(o => norm(o.label + ' ' + (o.description || '') + ' ' + (o.group || '')).includes(norm(q))) : opts;
  const sel = opts.find(o => o.value === cur);
  React.useEffect(() => {
    if (!open) return;
    const h = e => {
      if (root.current && !root.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, [open]);
  React.useEffect(() => {
    const l = list.current;
    if (!open || !l || active < 0) return;
    const el = l.querySelector('[data-idx="' + active + '"]');
    if (!el) return;
    if (el.offsetTop < l.scrollTop) l.scrollTop = el.offsetTop - 4;else if (el.offsetTop + el.offsetHeight > l.scrollTop + l.clientHeight) l.scrollTop = el.offsetTop + el.offsetHeight - l.clientHeight + 4;
  }, [active, open]);
  const openIt = () => {
    if (disabled) return;
    const r = trig.current.getBoundingClientRect();
    setUp(window.innerHeight - r.bottom < 300 && r.top > 300);
    setQ('');
    setActive(Math.max(0, opts.findIndex(o => o.value === cur)));
    setOpen(true);
  };
  const close = () => {
    setOpen(false);
    trig.current && trig.current.focus();
  };
  const pick = o => {
    if (!o || o.disabled) return;
    if (value === undefined) setInner(o.value);
    onChange && onChange(o.value);
    close();
  };
  const move = d => {
    if (!shown.length) return;
    let i = active;
    for (let k = 0; k < shown.length; k++) {
      i = (i + d + shown.length) % shown.length;
      if (!shown[i].disabled) break;
    }
    setActive(i);
  };
  const onKey = e => {
    if (!open) {
      if (['ArrowDown', 'ArrowUp', 'Enter', ' '].includes(e.key)) {
        e.preventDefault();
        openIt();
      }
      return;
    }
    if (e.key === 'Escape') {
      e.preventDefault();
      close();
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      move(1);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      move(-1);
    } else if (e.key === 'Home' && !searchable) {
      e.preventDefault();
      setActive(0);
    } else if (e.key === 'End' && !searchable) {
      e.preventDefault();
      setActive(shown.length - 1);
    } else if (e.key === 'Enter' || e.key === ' ' && !searchable) {
      e.preventDefault();
      pick(shown[active]);
    } else if (e.key === 'Tab') setOpen(false);else if (!searchable && e.key.length === 1) {
      const now = Date.now();
      typed.current.s = (now - typed.current.t > 600 ? '' : typed.current.s) + norm(e.key);
      typed.current.t = now;
      const i = shown.findIndex(o => norm(o.label).startsWith(typed.current.s));
      if (i >= 0) setActive(i);
    }
  };
  const lead = icon || sel && sel.icon;
  const actId = open && active >= 0 && shown[active] ? fid + '-o' + active : undefined;
  return /*#__PURE__*/React.createElement(__ds_scope.FieldShell, {
    id: fid,
    label: label,
    hint: hint,
    error: error,
    optional: optional
  }, /*#__PURE__*/React.createElement("div", {
    className: "rz-select",
    ref: root,
    onKeyDown: onKey
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    ref: trig,
    id: fid,
    className: 'rz-control rz-trigger' + (size === 'sm' ? ' rz-control--sm' : ''),
    "data-open": open,
    "data-state": error ? 'error' : undefined,
    "data-disabled": !!disabled,
    disabled: disabled,
    role: "combobox",
    "aria-haspopup": "listbox",
    "aria-expanded": open,
    "aria-controls": fid + '-list',
    "aria-activedescendant": searchable ? undefined : actId,
    "aria-invalid": !!error,
    "aria-describedby": error || hint ? fid + '-msg' : undefined,
    onClick: () => open ? setOpen(false) : openIt()
  }, lead && /*#__PURE__*/React.createElement("span", {
    className: "rz-adorn"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: lead,
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    className: "rz-val",
    "data-ph": !sel
  }, sel ? sel.label : placeholder), /*#__PURE__*/React.createElement("span", {
    className: "rz-chev2"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 18
  }))), open && /*#__PURE__*/React.createElement("div", {
    className: "rz-pop",
    "data-up": up
  }, searchable && /*#__PURE__*/React.createElement("div", {
    className: "rz-search"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "search",
    size: 16
  }), /*#__PURE__*/React.createElement("input", {
    autoFocus: true,
    value: q,
    placeholder: searchPlaceholder,
    "aria-label": searchPlaceholder,
    "aria-controls": fid + '-list',
    "aria-activedescendant": actId,
    onChange: e => {
      setQ(e.target.value);
      setActive(0);
    }
  })), /*#__PURE__*/React.createElement("ul", {
    className: "rz-list",
    role: "listbox",
    id: fid + '-list',
    "aria-labelledby": fid,
    ref: list
  }, shown.length ? shown.map((o, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: o.value
  }, o.group && (i === 0 || shown[i - 1].group !== o.group) && /*#__PURE__*/React.createElement("li", {
    role: "presentation",
    className: "rz-grp"
  }, o.group), /*#__PURE__*/React.createElement("li", {
    id: fid + '-o' + i,
    "data-idx": i,
    role: "option",
    className: "rz-oi",
    "aria-selected": o.value === cur,
    "aria-disabled": !!o.disabled,
    "data-active": i === active,
    onMouseEnter: () => setActive(i),
    onMouseDown: e => e.preventDefault(),
    onClick: () => pick(o)
  }, o.icon && /*#__PURE__*/React.createElement("span", {
    className: "rz-oi-ic"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: o.icon,
    size: 17
  })), /*#__PURE__*/React.createElement("span", {
    className: "rz-oi-t"
  }, o.label, o.description && /*#__PURE__*/React.createElement("span", {
    className: "rz-oi-d"
  }, o.description)), o.value === cur && /*#__PURE__*/React.createElement("span", {
    className: "rz-oi-ck"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 18
  }))))) : /*#__PURE__*/React.createElement("li", {
    className: "rz-empty",
    role: "presentation"
  }, emptyText)))));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/match/ChangeCard.jsx
try { (() => {
function ChangeCard({
  section,
  source,
  before,
  after,
  checked,
  onChange,
  why
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      border: checked ? '2px solid var(--border-selected)' : '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-card)',
      background: 'var(--surface-card)',
      padding: checked ? 19 : 20,
      display: 'grid',
      gap: 14,
      transition: 'border-color var(--dur-fast)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 12,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Checkbox, {
    checked: checked,
    onChange: onChange,
    label: /*#__PURE__*/React.createElement("b", {
      style: {
        color: 'var(--text-strong)'
      }
    }, section)
  }), source && /*#__PURE__*/React.createElement(__ds_scope.Pill, {
    size: "sm",
    tone: "good",
    icon: "shield-check"
  }, source)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: before ? 'minmax(0,1fr) minmax(0,1fr)' : '1fr',
      gap: 10
    }
  }, before && /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#f6f7f3',
      borderRadius: 'var(--radius-md)',
      padding: '12px 14px',
      fontSize: '.84rem',
      lineHeight: 1.55,
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.68rem',
      fontWeight: 750,
      letterSpacing: '.1em',
      textTransform: 'uppercase',
      marginBottom: 6
    }
  }, "Now"), before), /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#ecf5ee',
      border: '1px solid #b8d4c1',
      borderRadius: 'var(--radius-md)',
      padding: '12px 14px',
      fontSize: '.84rem',
      lineHeight: 1.55,
      color: 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.68rem',
      fontWeight: 750,
      letterSpacing: '.1em',
      textTransform: 'uppercase',
      marginBottom: 6,
      color: 'var(--text-accent)'
    }
  }, before ? 'Suggested' : 'Add'), after)), why && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.78rem',
      color: 'var(--text-muted)',
      lineHeight: 1.5
    }
  }, why));
}
Object.assign(__ds_scope, { ChangeCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/match/ChangeCard.jsx", error: String((e && e.message) || e) }); }

// components/match/FindingGroup.jsx
try { (() => {
const TONE = {
  good: ['var(--status-good-bg)', 'var(--status-good-fg)'],
  info: ['var(--status-info-bg)', 'var(--status-info-fg)'],
  warn: ['var(--status-warn-bg)', 'var(--status-warn-fg)'],
  neutral: ['var(--status-neutral-bg)', 'var(--status-neutral-fg)']
};
function FindingGroup({
  tone = 'good',
  icon = 'check',
  title,
  count,
  subtitle,
  children,
  defaultOpen = true
}) {
  const [open, setOpen] = React.useState(defaultOpen);
  const [bg, fg] = TONE[tone] || TONE.good;
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--surface-card)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-card)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setOpen(!open),
    "aria-expanded": open,
    style: {
      width: '100%',
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      padding: '18px 22px',
      background: 'transparent',
      border: 0,
      cursor: 'pointer',
      textAlign: 'left',
      font: 'inherit',
      color: 'inherit'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 36,
      height: 36,
      borderRadius: 11,
      background: bg,
      color: fg,
      display: 'grid',
      placeItems: 'center',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: 8,
      alignItems: 'baseline'
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 650,
      fontSize: '1.05rem',
      color: 'var(--text-strong)'
    }
  }, title), count != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '.8rem',
      color: 'var(--text-muted)',
      fontWeight: 600
    }
  }, count)), subtitle && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontSize: '.8rem',
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, subtitle)), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)',
      transform: open ? 'rotate(180deg)' : 'none',
      transition: 'transform var(--dur-base) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 18
  }))), open && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 22px 6px',
      borderTop: '1px solid var(--border-subtle)'
    }
  }, children));
}
Object.assign(__ds_scope, { FindingGroup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/match/FindingGroup.jsx", error: String((e && e.message) || e) }); }

// components/match/KeywordRow.jsx
try { (() => {
const STATE = {
  included: {
    tone: 'good',
    icon: 'check',
    label: 'In your CV'
  },
  equivalent: {
    tone: 'good',
    icon: 'languages',
    label: 'In your CV · similar wording'
  },
  omitted: {
    tone: 'info',
    icon: 'archive',
    label: 'You have it · not in this CV'
  },
  confirm: {
    tone: 'warn',
    icon: 'circle-help',
    label: 'Is this true for you?'
  },
  gap: {
    tone: 'neutral',
    icon: 'minus',
    label: 'Not in your experience'
  }
};
function KeywordRow({
  term,
  state = 'included',
  required,
  detail,
  action,
  last
}) {
  const s = STATE[state] || STATE.included;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 15,
      padding: '15px 0',
      borderBottom: last ? 0 : '1px solid var(--border-subtle)',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0,
      flex: '1 1 260px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      fontSize: '.92rem',
      color: 'var(--text-strong)',
      fontWeight: 650
    }
  }, term), required ? /*#__PURE__*/React.createElement(__ds_scope.Pill, {
    size: "sm",
    tone: "neutral"
  }, "Required") : /*#__PURE__*/React.createElement(__ds_scope.Pill, {
    size: "sm",
    tone: "neutral"
  }, "Nice to have")), detail && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '6px 0 0',
      fontSize: '.8rem',
      lineHeight: 1.55,
      color: 'var(--text-muted)'
    }
  }, detail)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Pill, {
    tone: s.tone,
    icon: s.icon
  }, s.label), action));
}
Object.assign(__ds_scope, { KeywordRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/match/KeywordRow.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SideNav.jsx
try { (() => {
function SideNav({
  items = [],
  value,
  onChange,
  footer
}) {
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      width: 'var(--sidebar-width)',
      flexShrink: 0,
      background: 'var(--surface-card)',
      borderRight: '1px solid var(--border-subtle)',
      padding: '22px 14px',
      display: 'flex',
      flexDirection: 'column',
      gap: 4,
      minHeight: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '4px 12px 22px'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Logo, {
    size: 28
  })), items.map(it => {
    const on = it.value === value;
    return /*#__PURE__*/React.createElement("button", {
      key: it.value,
      onClick: () => onChange && onChange(it.value),
      "aria-current": on ? 'page' : undefined,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        padding: '11px 12px',
        border: 0,
        borderRadius: 'var(--radius-md)',
        background: on ? 'var(--surface-selected)' : 'transparent',
        color: on ? 'var(--text-accent)' : 'var(--text-muted)',
        fontWeight: on ? 700 : 500,
        fontSize: '.88rem',
        textAlign: 'left',
        cursor: 'pointer',
        fontFamily: 'var(--font-sans)'
      },
      onMouseEnter: e => {
        if (!on) e.currentTarget.style.background = 'var(--surface-hover)';
      },
      onMouseLeave: e => {
        if (!on) e.currentTarget.style.background = 'transparent';
      }
    }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: it.icon,
      size: 18
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1
      }
    }, it.label), it.badge && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: '.7rem',
        fontWeight: 700,
        background: 'var(--marigold-300)',
        color: 'var(--pine-900)',
        borderRadius: 'var(--radius-pill)',
        padding: '1px 7px'
      }
    }, it.badge));
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), footer);
}
Object.assign(__ds_scope, { SideNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SideNav.jsx", error: String((e && e.message) || e) }); }

// components/navigation/TopBar.jsx
try { (() => {
function TopBar({
  title,
  back,
  right,
  children
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      justifyContent: 'space-between',
      padding: '14px 28px',
      background: 'var(--surface-card)',
      borderBottom: '1px solid var(--border-subtle)',
      minHeight: 64
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      minWidth: 0
    }
  }, back, title && /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 650,
      fontSize: '.95rem',
      color: 'var(--text-strong)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, title)), children && /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      justifyContent: 'center',
      minWidth: 0
    }
  }, children), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, right));
}
Object.assign(__ds_scope, { TopBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/TopBar.jsx", error: String((e && e.message) || e) }); }

// components/progress/ProgressBar.jsx
try { (() => {
function ProgressBar({
  value = 0,
  max = 100,
  label,
  valueLabel,
  tone = 'primary',
  height = 7
}) {
  const pct = Math.max(0, Math.min(100, value / max * 100));
  const fill = {
    primary: 'var(--action-primary)',
    warn: 'var(--marigold-500)',
    muted: 'var(--sage-400)'
  }[tone];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, (label || valueLabel) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 12,
      fontSize: '.79rem',
      marginBottom: 8,
      color: 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement("span", null, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 650
    }
  }, valueLabel)), /*#__PURE__*/React.createElement("div", {
    role: "progressbar",
    "aria-valuenow": value,
    "aria-valuemin": 0,
    "aria-valuemax": max,
    style: {
      height,
      background: 'var(--sage-150)',
      borderRadius: height,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("i", {
    style: {
      display: 'block',
      height: '100%',
      width: pct + '%',
      background: fill,
      borderRadius: height,
      transition: 'width var(--dur-slow) var(--ease-out)'
    }
  })));
}
Object.assign(__ds_scope, { ProgressBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/progress/ProgressBar.jsx", error: String((e && e.message) || e) }); }

// components/progress/ScoreRing.jsx
try { (() => {
function ScoreRing({
  value,
  size = 120,
  label,
  caption,
  previous,
  untested
}) {
  const stroke = size >= 100 ? 10 : 7,
    r = (size - stroke) / 2,
    c = 2 * Math.PI * r;
  const pct = untested || value == null ? 0 : Math.max(0, Math.min(100, value));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-grid',
      justifyItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: size,
      height: size
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    style: {
      transform: 'rotate(-90deg)'
    },
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: size / 2,
    cy: size / 2,
    r: r,
    fill: "none",
    stroke: untested ? 'var(--sage-200)' : 'var(--score-track)',
    strokeWidth: stroke,
    strokeDasharray: untested ? '4 6' : undefined
  }), !untested && /*#__PURE__*/React.createElement("circle", {
    cx: size / 2,
    cy: size / 2,
    r: r,
    fill: "none",
    stroke: "var(--score-fill)",
    strokeWidth: stroke,
    strokeLinecap: "round",
    strokeDasharray: c,
    strokeDashoffset: c * (1 - pct / 100),
    style: {
      transition: 'stroke-dashoffset var(--dur-celebrate) var(--ease-out)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'grid',
      placeContent: 'center',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: untested ? size * .13 : size * .28,
      letterSpacing: 'var(--tracking-stat)',
      color: untested ? 'var(--text-muted)' : 'var(--text-strong)',
      lineHeight: 1,
      fontWeight: 700
    }
  }, untested ? 'Not tested' : Math.round(value)), previous != null && !untested && /*#__PURE__*/React.createElement("small", {
    style: {
      fontSize: '.68rem',
      color: 'var(--text-muted)',
      marginTop: 3
    }
  }, "was ", previous))), label && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.8rem',
      fontWeight: 650,
      color: 'var(--text-strong)',
      textAlign: 'center'
    }
  }, label), caption && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.74rem',
      color: 'var(--text-muted)',
      textAlign: 'center',
      maxWidth: size + 40,
      lineHeight: 1.4
    }
  }, caption));
}
Object.assign(__ds_scope, { ScoreRing });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/progress/ScoreRing.jsx", error: String((e && e.message) || e) }); }

// components/match/MatchVerdict.jsx
try { (() => {
function MatchVerdict({
  headline,
  summary,
  score,
  previous,
  scoreLabel = 'This CV vs the job',
  counts,
  actions
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '20px 28px',
      alignItems: 'center',
      background: 'var(--surface-hero)',
      border: '1px solid #d6e4d9',
      borderRadius: 'var(--radius-hero)',
      padding: 'clamp(20px,4cqi,28px) clamp(20px,4cqi,32px)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.ScoreRing, {
    value: score,
    previous: previous,
    label: scoreLabel,
    size: 128
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0,
      flex: '1 1 260px'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: '1.7rem',
      lineHeight: 1.15,
      letterSpacing: '-0.03em',
      color: 'var(--text-strong)',
      textWrap: 'balance'
    }
  }, headline), summary && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '10px 0 0',
      color: 'var(--text-muted)',
      fontSize: '.92rem',
      lineHeight: 1.6,
      maxWidth: 560,
      textWrap: 'pretty'
    }
  }, summary), counts && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 22,
      marginTop: 18,
      flexWrap: 'wrap'
    }
  }, counts.map((c, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'grid',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: '1.5rem',
      fontWeight: 700,
      color: c.color || 'var(--text-strong)',
      lineHeight: 1
    }
  }, c.value), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '.76rem',
      color: 'var(--text-muted)'
    }
  }, c.label)))), actions && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginTop: 20,
      flexWrap: 'wrap'
    }
  }, actions)));
}
Object.assign(__ds_scope, { MatchVerdict });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/match/MatchVerdict.jsx", error: String((e && e.message) || e) }); }

// components/progress/Stepper.jsx
try { (() => {
function Stepper({
  steps = [],
  current = 0,
  onStepClick
}) {
  return /*#__PURE__*/React.createElement("ol", {
    style: {
      display: 'flex',
      gap: 6,
      listStyle: 'none',
      margin: 0,
      padding: 0,
      flexWrap: 'wrap',
      alignItems: 'center'
    }
  }, steps.map((s, i) => {
    const done = i < current,
      on = i === current;
    return /*#__PURE__*/React.createElement("li", {
      key: i,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 6
      }
    }, /*#__PURE__*/React.createElement("button", {
      disabled: !onStepClick || i > current,
      onClick: () => onStepClick && onStepClick(i),
      "aria-current": on ? 'step' : undefined,
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        border: 0,
        borderRadius: 'var(--radius-pill)',
        padding: '6px 12px 6px 6px',
        background: on ? 'var(--action-primary)' : done ? 'var(--surface-hero)' : 'var(--sage-150)',
        color: on ? 'var(--text-on-primary)' : done ? 'var(--text-accent)' : 'var(--text-muted)',
        font: '600 .78rem/1 var(--font-sans)',
        cursor: onStepClick && i <= current ? 'pointer' : 'default'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 20,
        height: 20,
        borderRadius: '50%',
        display: 'grid',
        placeItems: 'center',
        background: on ? 'rgba(255,255,255,.2)' : done ? 'var(--surface-card)' : 'var(--surface-card)',
        fontSize: '.7rem'
      }
    }, done ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: "check",
      size: 12
    }) : i + 1), s), i < steps.length - 1 && /*#__PURE__*/React.createElement("span", {
      "aria-hidden": "true",
      style: {
        width: 14,
        height: 2,
        background: done ? 'var(--pine-300)' : 'var(--sage-200)',
        borderRadius: 2
      }
    }));
  }));
}
Object.assign(__ds_scope, { Stepper });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/progress/Stepper.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/AddJob.jsx
try { (() => {
function AddJobScreen({
  onDone
}) {
  const {
    Card,
    Button,
    Field,
    Segmented,
    Spinner,
    Dropzone
  } = window.CVizatDesignSystem_0f8e2e;
  const D = window.CVZ_DATA;
  const [mode, setMode] = React.useState('paste');
  const [text, setText] = React.useState(D.job.ad);
  const [url, setUrl] = React.useState('');
  const [file, setFile] = React.useState(null);
  const [busy, setBusy] = React.useState(false);
  const ready = mode === 'paste' ? text.length >= 30 : mode === 'link' ? /^https?:\/\/.+\..+/.test(url) : !!file;
  const go = () => {
    setBusy(true);
    setTimeout(onDone, 1400);
  };
  if (busy) return /*#__PURE__*/React.createElement(Card, {
    style: {
      maxWidth: 640,
      margin: '40px auto',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '40px 0'
    }
  }, /*#__PURE__*/React.createElement(Spinner, {
    label: "Reading the job ad and comparing it with your CV\u2026"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 18
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    onClick: () => setBusy(false)
  }, "Cancel"))));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 680,
      margin: '0 auto',
      display: 'grid',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      font: '700 2rem/1.15 var(--font-display)',
      letterSpacing: '-0.04em',
      color: 'var(--text-strong)'
    }
  }, "Which job are you applying for?"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '10px 0 0',
      color: 'var(--text-muted)',
      lineHeight: 1.6
    }
  }, "We only read what you give us. Nothing is sent to the employer.")), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(Segmented, {
    fullWidth: true,
    value: mode,
    onChange: setMode,
    options: [{
      value: 'paste',
      label: 'Paste the ad',
      icon: 'clipboard-paste'
    }, {
      value: 'link',
      label: 'From a link',
      icon: 'link'
    }, {
      value: 'file',
      label: 'Upload a file',
      icon: 'file-up'
    }]
  }), mode === 'paste' && /*#__PURE__*/React.createElement(Field, {
    label: "Job ad",
    multiline: true,
    rows: 9,
    maxLength: 6000,
    value: text,
    onChange: setText,
    hint: "Copy the whole ad, including the requirements.",
    error: text.length > 0 && text.length < 30 ? 'Paste a bit more — at least a few sentences.' : undefined
  }), mode === 'link' && /*#__PURE__*/React.createElement(Field, {
    label: "Link to the job ad",
    icon: "link",
    type: "url",
    value: url,
    onChange: setUrl,
    placeholder: "https://www.ejobs.ro/\u2026",
    hint: "If the page needs a login, we\u2019ll ask you to paste the text instead.",
    success: /^https?:\/\/.+\..+/.test(url) ? 'Looks like a valid link' : undefined
  }), mode === 'file' && /*#__PURE__*/React.createElement(Dropzone, {
    title: "Drop the job ad here",
    acceptLabel: "PDF, DOCX or screenshot",
    accept: ".pdf,.docx,image/*",
    file: file,
    onFile: setFile,
    onRemove: () => setFile(null)
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Job title",
    icon: "briefcase",
    defaultValue: D.job.title,
    optional: true
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Company",
    icon: "building-2",
    defaultValue: D.job.company,
    optional: true
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconRight: "arrow-right",
    disabled: !ready,
    onClick: go
  }, "Check my match")));
}
window.AddJobScreen = AddJobScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/AddJob.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/App.jsx
try { (() => {
function App() {
  const {
    SideNav,
    TopBar,
    Stepper,
    IconButton,
    Button,
    Toast,
    Pill,
    Logo
  } = window.CVizatDesignSystem_0f8e2e;
  const saved = JSON.parse(localStorage.getItem('rz-kit') || '{}');
  const [view, setView] = React.useState(saved.view || 'home');
  const [step, setStep] = React.useState(saved.step || 0);
  const [accepted, setAccepted] = React.useState(['sum', 'api', 'out']);
  const [rtw, setRtw] = React.useState(false);
  const [applied, setApplied] = React.useState(false);
  const [toast, setToast] = React.useState(null);
  React.useEffect(() => {
    localStorage.setItem('rz-kit', JSON.stringify({
      view,
      step
    }));
  }, [view, step]);
  const flash = m => {
    setToast(m);
    setTimeout(() => setToast(null), 2600);
  };
  const steps = ['Add job', 'See your match', 'Improve CV', 'Download'];
  if (view === 'flow') return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement(TopBar, {
    back: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(IconButton, {
      icon: "x",
      label: "Exit to Home",
      onClick: () => setView('home')
    }), /*#__PURE__*/React.createElement(Logo, {
      variant: "mark",
      size: 28
    })),
    title: "Northstar People",
    right: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      onClick: () => setView('home')
    }, "Save & exit")
  }, /*#__PURE__*/React.createElement(Stepper, {
    steps: steps,
    current: step,
    onStepClick: setStep
  })), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      padding: '36px 44px 60px'
    }
  }, step === 0 && /*#__PURE__*/React.createElement(AddJobScreen, {
    onDone: () => setStep(1)
  }), step === 1 && /*#__PURE__*/React.createElement(MatchReportScreen, {
    rtw: rtw,
    setRtw: setRtw,
    onNext: () => setStep(2)
  }), step === 2 && /*#__PURE__*/React.createElement(ImproveScreen, {
    accepted: accepted,
    setAccepted: setAccepted,
    onNext: base => {
      setStep(3);
      flash(base ? 'Saved — Base CV is now v4' : 'Saved — Base CV unchanged');
    }
  }), step === 3 && /*#__PURE__*/React.createElement(DownloadScreen, {
    accepted: accepted,
    rtw: rtw,
    onSent: () => {
      setApplied(true);
      setView('home');
      setStep(0);
      flash('Marked as sent. Good luck, Mara!');
    }
  })), toast && /*#__PURE__*/React.createElement(Toast, {
    action: "Undo",
    onAction: () => setToast(null)
  }, toast));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      minHeight: '100vh'
    }
  }, /*#__PURE__*/React.createElement(SideNav, {
    value: "home",
    items: [{
      value: 'home',
      label: 'Home',
      icon: 'house'
    }, {
      value: 'cv',
      label: 'My CV',
      icon: 'file-user'
    }, {
      value: 'jobs',
      label: 'Jobs',
      icon: 'briefcase',
      badge: '2'
    }, {
      value: 'account',
      label: 'Account',
      icon: 'circle-user'
    }],
    footer: /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '0 12px',
        fontSize: '.72rem',
        color: 'var(--text-muted)'
      }
    }, "resumora.ro \xB7 demo data")
  }), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      padding: '36px 44px 60px',
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(HomeScreen, {
    applied: applied,
    onStart: () => {
      setView('flow');
      setStep(applied ? 3 : 0);
    }
  })), toast && /*#__PURE__*/React.createElement(Toast, {
    icon: "party-popper"
  }, toast));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/AppShell.jsx
try { (() => {
function rzParse(str) {
  const raw = str != null ? str : location.hash.replace(/^#\/?/, '');
  const [r, s] = raw.split('/').map(x => decodeURIComponent(x || ''));
  const route = RZ_ROUTES[r] ? r : r ? 'notfound' : 'home';
  const st = RZ_ROUTES[route].states.includes(s) ? s : RZ_ROUTES[route].states[0];
  return {
    route,
    state: st
  };
}
function RzGuideBar({
  route,
  state,
  go,
  notes,
  setNotes,
  compact
}) {
  const R = RZ_ROUTES[route],
    px = compact ? 16 : 44;
  const chip = on => ({
    padding: '5px 10px',
    borderRadius: 999,
    border: '1px solid ' + (on ? 'var(--pine-600)' : 'var(--border-subtle)'),
    background: on ? 'var(--pine-600)' : '#fff',
    color: on ? '#fff' : 'var(--text-body)',
    font: '600 .74rem var(--font-sans)',
    cursor: 'pointer',
    whiteSpace: 'nowrap',
    flex: 'none'
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--sage-50)',
      borderBottom: '1px dashed var(--sage-300)',
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px 16px',
      flexWrap: 'wrap',
      padding: '10px ' + px + 'px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '600 .72rem var(--font-mono, monospace)',
      color: 'var(--pine-700)',
      background: '#fff',
      border: '1px solid var(--border-subtle)',
      borderRadius: 6,
      padding: '3px 7px'
    }
  }, R.id), /*#__PURE__*/React.createElement("b", {
    style: {
      fontWeight: 650,
      fontSize: '.86rem',
      color: 'var(--text-strong)'
    }
  }, R.name), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: 4,
      alignItems: 'center',
      fontSize: '.76rem',
      color: 'var(--text-muted)'
    }
  }, "Journey ", R.journeys.map(j => /*#__PURE__*/React.createElement("a", {
    key: j,
    href: 'journeys.html#' + j,
    style: {
      fontWeight: 700
    }
  }, j))), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), R.states.length > 1 && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: 6,
      alignItems: 'center',
      overflowX: 'auto',
      maxWidth: '100%'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '.72rem',
      fontWeight: 700,
      letterSpacing: '.08em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
      flex: 'none'
    }
  }, "State"), R.states.map(s => /*#__PURE__*/React.createElement("button", {
    key: s,
    style: chip(s === state),
    onClick: () => go(route, s)
  }, s))), /*#__PURE__*/React.createElement("button", {
    style: chip(false),
    onClick: () => setNotes(!notes)
  }, notes ? 'Hide notes' : 'Notes')), notes && /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: 0,
      padding: '0 ' + px + 'px 12px ' + (px + 18) + 'px',
      display: 'grid',
      gap: 4,
      fontSize: '.8rem',
      color: 'var(--text-body)',
      lineHeight: 1.5
    }
  }, R.notes.map(n => /*#__PURE__*/React.createElement("li", {
    key: n
  }, n))));
}
function RzTabBar({
  value,
  go,
  bottom
}) {
  const {
    Icon
  } = ONB_DS;
  const items = [['home', 'Home', 'house'], ['base', 'Base CV', 'file-user'], ['enrich', 'Improve', 'sparkles'], ['applications', 'Applications', 'briefcase'], ['account', 'Account', 'circle-user']];
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(5,1fr)',
      borderTop: '1px solid var(--border-subtle)',
      background: '#fff',
      paddingBottom: bottom,
      flex: 'none'
    }
  }, items.map(([v, l, ic]) => {
    const on = value === v;
    return /*#__PURE__*/React.createElement("button", {
      key: v,
      onClick: () => go(v),
      "aria-current": on ? 'page' : undefined,
      style: {
        minHeight: 58,
        display: 'grid',
        justifyItems: 'center',
        alignContent: 'center',
        gap: 3,
        background: 'none',
        border: 0,
        cursor: 'pointer',
        color: on ? 'var(--pine-700)' : 'var(--text-muted)',
        font: '650 .66rem var(--font-sans)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'grid',
        placeItems: 'center',
        padding: '4px 14px',
        borderRadius: 999,
        background: on ? 'var(--pine-100)' : 'transparent'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: ic,
      size: 20
    })), l);
  }));
}
function RzFirstHome({
  go
}) {
  const {
    Button,
    EmptyState
  } = ONB_DS;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 24,
      maxWidth: 1040
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-hero)',
      border: '1px solid #d6e4d9',
      borderRadius: 'var(--radius-hero)',
      padding: 'clamp(22px,4cqi,38px)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: '750 .73rem var(--font-sans)',
      letterSpacing: '.14em',
      textTransform: 'uppercase',
      color: 'var(--text-accent)',
      marginBottom: 12
    }
  }, "Welcome, Mara"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      font: '700 clamp(2rem,6cqi,2.65rem)/1.1 var(--font-display)',
      letterSpacing: '-0.045em',
      color: 'var(--text-strong)',
      maxWidth: 620,
      textWrap: 'balance'
    }
  }, "Prepare your next application"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '16px 0 0',
      color: 'var(--text-muted)',
      lineHeight: 1.6,
      maxWidth: 520
    }
  }, "Start with the job you want, or bring your CV first. Either way, you confirm every fact before we use it."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginTop: 24,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconRight: "arrow-right",
    onClick: () => go('addjob')
  }, "Start with a job"), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    icon: "file-up",
    href: "onboarding.html#/import"
  }, "Create my Base CV"))), /*#__PURE__*/React.createElement(EmptyState, {
    icon: "briefcase",
    title: "No applications yet"
  }, "Each job you add gets its own CV, contact and next step \u2014 they\u2019ll appear here."));
}
function RzMatch({
  state,
  go,
  rtw,
  setRtw
}) {
  const {
    Alert,
    Button,
    Card,
    Spinner
  } = ONB_DS;
  const [st, setSt] = React.useState(state);
  React.useEffect(() => {
    if (st !== 'busy') return;
    const t = setTimeout(() => setSt('ok'), 1300);
    return () => clearTimeout(t);
  }, [st]);
  if (st === 'busy') return /*#__PURE__*/React.createElement(Card, {
    style: {
      maxWidth: 640,
      margin: '40px auto',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '40px 0'
    }
  }, /*#__PURE__*/React.createElement(Spinner, {
    label: "Comparing the job with Base CV v3\u2026"
  })));
  if (st === 'Failed') return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 640,
      margin: '40px auto'
    }
  }, /*#__PURE__*/React.createElement(Alert, {
    tone: "bad",
    title: "We couldn\u2019t calculate your match",
    action: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "primary",
      icon: "rotate-cw",
      onClick: () => setSt('busy')
    }, "Try again")
  }, "Your CV and the job are saved. This was on our side."));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr)',
      gap: 16
    }
  }, st === 'Outdated' && /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1120,
      margin: '0 auto',
      width: '100%'
    }
  }, /*#__PURE__*/React.createElement(Alert, {
    tone: "warn",
    title: "This match is out of date",
    action: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "primary",
      icon: "rotate-cw",
      onClick: () => setSt('busy')
    }, "Recalculate")
  }, "You saved Base CV v3 after it was calculated. The results below are from v2.")), /*#__PURE__*/React.createElement(MatchReportScreen, {
    rtw: rtw,
    setRtw: setRtw,
    onNext: () => go('compare')
  }));
}
function ResumoraApp({
  initial,
  embed
}) {
  const {
    SideNav,
    TopBar,
    Stepper,
    IconButton,
    Button,
    Toast,
    Logo
  } = ONB_DS;
  const mobile = rzUseMobile(embed);
  const [loc, setLoc] = React.useState(() => rzParse(initial));
  const [toast, setToast] = React.useState(null);
  const [accepted, setAccepted] = React.useState(['sum', 'api', 'out']);
  const [rtw, setRtw] = React.useState(false);
  const [notes, setNotesRaw] = React.useState(!embed && localStorage.getItem('rz-notes') !== '0');
  const mainRef = React.useRef(null);
  const tRef = React.useRef(null);
  const setNotes = v => {
    setNotesRaw(v);
    localStorage.setItem('rz-notes', v ? '1' : '0');
  };
  React.useEffect(() => {
    if (embed) return;
    const h = () => setLoc(rzParse());
    window.addEventListener('hashchange', h);
    return () => window.removeEventListener('hashchange', h);
  }, []);
  React.useEffect(() => {
    if (mainRef.current) mainRef.current.scrollTop = 0;
    if (!embed) window.scrollTo(0, 0);
  }, [loc.route, loc.state]);
  const go = (r, s) => {
    if (embed) setLoc(rzParse(r + (s ? '/' + encodeURIComponent(s) : '')));else location.hash = '#/' + r + (s ? '/' + encodeURIComponent(s) : '');
  };
  const flash = m => {
    setToast(m);
    clearTimeout(tRef.current);
    tRef.current = setTimeout(() => setToast(null), 2800);
  };
  const {
      route,
      state
    } = loc,
    R = RZ_ROUTES[route];
  const p = {
    state,
    go,
    flash,
    rtw
  };
  const body = {
    home: () => state === 'First visit' ? /*#__PURE__*/React.createElement(RzFirstHome, {
      go: go
    }) : /*#__PURE__*/React.createElement(HomeScreen, {
      applied: false,
      onJob: () => go('addjob'),
      onOpen: () => go('application'),
      onBase: () => go('base'),
      onImprove: () => go('base', 'Review')
    }),
    base: () => /*#__PURE__*/React.createElement(BaseScreen, p),
    history: () => /*#__PURE__*/React.createElement(HistoryScreen, p),
    enrich: () => /*#__PURE__*/React.createElement(EnrichScreen, p),
    addjob: () => /*#__PURE__*/React.createElement(JobCaptureScreen, p),
    requirements: () => /*#__PURE__*/React.createElement(RequirementsScreen, p),
    match: () => /*#__PURE__*/React.createElement(RzMatch, {
      state: state,
      go: go,
      rtw: rtw,
      setRtw: setRtw
    }),
    compare: () => /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'minmax(0,1fr)',
        gap: 14
      }
    }, /*#__PURE__*/React.createElement(ImproveScreen, {
      accepted: accepted,
      setAccepted: setAccepted,
      onNext: b => {
        flash(b ? 'Saved — Base CV is now v4' : 'Saved — Job CV v1 · Base CV unchanged');
        go('preview');
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: 1180,
        margin: '0 auto',
        width: '100%'
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      icon: "pencil",
      onClick: () => go('jobeditor')
    }, "Prefer to edit it yourself? Open the editor"))),
    jobeditor: () => /*#__PURE__*/React.createElement(JobEditorScreen, p),
    preview: () => /*#__PURE__*/React.createElement(PreviewScreen, p),
    applications: () => /*#__PURE__*/React.createElement(ApplicationsScreen, p),
    application: () => /*#__PURE__*/React.createElement(ApplicationScreen, p),
    linkedin: () => /*#__PURE__*/React.createElement(LinkedInScreen, p),
    plans: () => /*#__PURE__*/React.createElement(PlansScreen, p),
    checkout: () => /*#__PURE__*/React.createElement(CheckoutScreen, p),
    account: () => /*#__PURE__*/React.createElement(AccountScreen, p),
    login: () => /*#__PURE__*/React.createElement(LoginScreen, p),
    forgot: () => /*#__PURE__*/React.createElement(ForgotScreen, p),
    reset: () => /*#__PURE__*/React.createElement(ResetScreen, p),
    expired: () => /*#__PURE__*/React.createElement(ExpiredScreen, p),
    session: () => /*#__PURE__*/React.createElement(SessionScreen, p),
    notfound: () => /*#__PURE__*/React.createElement(NotFoundScreen, p),
    error: () => /*#__PURE__*/React.createElement(ServerErrorScreen, p),
    offline: () => /*#__PURE__*/React.createElement(OfflineScreen, p),
    maintenance: () => /*#__PURE__*/React.createElement(MaintenanceScreen, p)
  }[route];
  const top = embed ? 44 : 0;
  const guide = !embed && /*#__PURE__*/React.createElement(RzGuideBar, {
    route: route,
    state: state,
    go: go,
    notes: notes,
    setNotes: setNotes,
    compact: mobile
  });
  const tst = toast && /*#__PURE__*/React.createElement(Toast, {
    icon: "circle-check",
    action: "Undo",
    onAction: () => setToast(null)
  }, toast);
  const main = pad => /*#__PURE__*/React.createElement("main", {
    ref: mainRef,
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: mobile ? 'auto' : undefined,
      padding: pad,
      containerType: 'inline-size'
    }
  }, /*#__PURE__*/React.createElement("div", {
    key: route + state
  }, body()));
  const root = {
    display: 'flex',
    flexDirection: 'column',
    background: 'var(--surface-page)',
    fontFamily: 'var(--font-sans)',
    color: 'var(--text-body)',
    textAlign: 'left',
    height: mobile ? embed ? '100%' : '100dvh' : undefined,
    minHeight: mobile ? undefined : '100vh',
    overflow: mobile ? 'hidden' : undefined,
    transform: embed ? 'translateZ(0)' : undefined
  };
  const fr = ['addjob', 'requirements', 'match', 'compare', 'preview'],
    fsteps = ['Add job', 'Requirements', 'Match', 'Improve', 'Download'];
  if (R.bare) return /*#__PURE__*/React.createElement("div", {
    style: root
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      padding: top + (mobile ? 14 : 22) + 'px ' + (mobile ? 16 : 44) + 'px 0',
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#/home",
    onClick: e => {
      if (embed) {
        e.preventDefault();
        go('home');
      }
    },
    "aria-label": "Resumora home"
  }, /*#__PURE__*/React.createElement(Logo, {
    size: mobile ? 26 : 30
  }))), guide && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12
    }
  }, guide), main(mobile ? '20px 16px 48px' : '24px 44px 80px'), tst);
  if (R.flow !== undefined) return /*#__PURE__*/React.createElement("div", {
    style: root
  }, mobile ? /*#__PURE__*/React.createElement(RzMobileHead, {
    top: top,
    onClose: () => go('application'),
    eyebrow: `Northstar People · step ${R.flow + 1} of 5`,
    title: fsteps[R.flow],
    progress: [R.flow + 1, 5],
    right: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "ghost",
      onClick: () => go('applications')
    }, "Save & exit")
  }) : /*#__PURE__*/React.createElement(TopBar, {
    back: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(IconButton, {
      icon: "x",
      label: "Exit to application",
      onClick: () => go('application')
    }), /*#__PURE__*/React.createElement(Logo, {
      variant: "mark",
      size: 28
    })),
    title: "Northstar People",
    right: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      onClick: () => go('applications')
    }, "Save & exit")
  }, /*#__PURE__*/React.createElement(Stepper, {
    steps: fsteps,
    current: R.flow,
    onStepClick: i => go(fr[i])
  })), guide, main(mobile ? '20px 16px 40px' : '32px 44px 80px'), tst);
  if (mobile) return /*#__PURE__*/React.createElement("div", {
    style: root
  }, /*#__PURE__*/React.createElement(RzMobileHead, {
    top: top,
    logo: true,
    title: R.name,
    right: /*#__PURE__*/React.createElement(IconButton, {
      variant: "ghost",
      icon: "scan-search",
      label: "LinkedIn check",
      onClick: () => go('linkedin')
    })
  }), guide, main('20px 16px 32px'), /*#__PURE__*/React.createElement(RzTabBar, {
    value: R.nav,
    go: go,
    bottom: embed ? 18 : 'env(safe-area-inset-bottom)'
  }), tst);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      minHeight: '100vh'
    }
  }, /*#__PURE__*/React.createElement(SideNav, {
    value: R.nav,
    onChange: v => go(v),
    items: [{
      value: 'home',
      label: 'Home',
      icon: 'house'
    }, {
      value: 'base',
      label: 'Base CV',
      icon: 'file-user'
    }, {
      value: 'enrich',
      label: 'Improve profile',
      icon: 'sparkles',
      badge: '4'
    }, {
      value: 'applications',
      label: 'Applications',
      icon: 'briefcase',
      badge: '4'
    }, {
      value: 'linkedin',
      label: 'LinkedIn check',
      icon: 'scan-search'
    }, {
      value: 'account',
      label: 'Account',
      icon: 'circle-user'
    }],
    footer: /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '0 12px',
        display: 'grid',
        gap: 6,
        fontSize: '.74rem'
      }
    }, /*#__PURE__*/React.createElement("a", {
      href: "journeys.html"
    }, "Customer journeys"), /*#__PURE__*/React.createElement("a", {
      href: "mobile.html"
    }, "Mobile screens"), /*#__PURE__*/React.createElement("a", {
      href: "onboarding.html#/welcome"
    }, "Onboarding flow"), /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--text-muted)'
      }
    }, "resumora.ro \xB7 demo data"))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex',
      flexDirection: 'column'
    }
  }, guide, main('32px 44px 80px')), tst);
}
window.ResumoraApp = ResumoraApp;
if (!window.RZ_EMBED_PAGE) ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(ResumoraApp, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/AppShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/Download.jsx
try { (() => {
function DownloadScreen({
  accepted,
  rtw,
  onSent
}) {
  const {
    CVDocument,
    Button,
    Segmented,
    ScoreRing,
    Alert,
    Card,
    Select,
    Spinner
  } = window.CVizatDesignSystem_0f8e2e;
  const [tpl, setTpl] = React.useState('Clar');
  const [state, setState] = React.useState('idle');
  const dl = () => {
    setState('busy');
    setTimeout(() => setState('done'), 1300);
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '320px minmax(0,1fr)',
      gap: 24,
      alignItems: 'start',
      maxWidth: 1120,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Card, {
    style: {
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement(ScoreRing, {
    value: 90,
    previous: 62,
    label: "This CV vs the job",
    size: 132
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '14px 0 0',
      fontSize: '.88rem',
      lineHeight: 1.55
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: '1.15rem',
      color: 'var(--text-strong)',
      display: 'block'
    }
  }, "Your CV now shows your fit."), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, "Same facts, better chosen."))), !rtw && /*#__PURE__*/React.createElement(Alert, {
    tone: "warn",
    title: "Still to check"
  }, "Right to work in Romania \u2014 the job requires it."), /*#__PURE__*/React.createElement(Card, {
    padding: "sm"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-label)',
      marginBottom: 7
    }
  }, "Template"), /*#__PURE__*/React.createElement(Segmented, {
    fullWidth: true,
    options: ['Clar', 'Contur'],
    value: tpl,
    onChange: setTpl
  })), /*#__PURE__*/React.createElement(Select, {
    label: "CV language",
    icon: "languages",
    options: ['English', 'Română'],
    hint: "Separate from the app language"
  }), state === 'busy' ? /*#__PURE__*/React.createElement(Spinner, {
    size: 28,
    label: "Preparing PDF and checking it reads correctly\u2026"
  }) : /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    icon: "download",
    onClick: dl
  }, state === 'done' ? 'Download again' : 'Download PDF'), state === 'done' && /*#__PURE__*/React.createElement(Button, {
    fullWidth: true,
    icon: "send",
    onClick: onSent
  }, "I\u2019ve sent this application")))), /*#__PURE__*/React.createElement(CVDocument, {
    template: tpl.toLowerCase(),
    scale: .9,
    name: "Mara Ionescu",
    titles: ['Business Systems Analyst'],
    contact: "Cluj-Napoca \xB7 mara.ionescu@example.com \xB7 +40 7xx xxx xxx",
    sections: window.CVZ_cv(accepted)
  }));
}
window.DownloadScreen = DownloadScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/Download.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/Home.jsx
try { (() => {
function HomeScreen({
  onStart,
  applied,
  onJob,
  onOpen,
  onBase,
  onImprove
}) {
  const {
    Card,
    Button,
    TaskCard,
    Pill,
    ProgressBar,
    Icon
  } = window.CVizatDesignSystem_0f8e2e;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 24,
      maxWidth: 1040
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,320px),1fr))',
      gap: 30,
      background: 'var(--surface-hero)',
      border: '1px solid #d6e4d9',
      borderRadius: 'var(--radius-hero)',
      padding: 'clamp(22px,4cqi,38px)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: '750 .73rem var(--font-sans)',
      letterSpacing: '.14em',
      textTransform: 'uppercase',
      color: 'var(--text-accent)',
      marginBottom: 12
    }
  }, "Good afternoon, Mara"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      font: '700 2.65rem/1.1 var(--font-display)',
      letterSpacing: '-0.045em',
      color: 'var(--text-strong)',
      textWrap: 'balance'
    }
  }, "Prepare your next application"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '16px 0 0',
      color: 'var(--text-muted)',
      fontSize: '1rem',
      lineHeight: 1.6,
      maxWidth: 460
    }
  }, "Paste a job ad. We\u2019ll show how well you fit, what your CV is missing, and make you a version for that job \u2014 your Base CV stays as it is."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginTop: 24,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconRight: "arrow-right",
    onClick: onJob || onStart
  }, "Start with a job"), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    icon: "file-user",
    onClick: onBase
  }, "Edit my Base CV"))), /*#__PURE__*/React.createElement("div", {
    style: {
      alignSelf: 'center',
      background: '#fff',
      padding: 24,
      boxShadow: 'var(--shadow-paper)',
      transform: 'rotate(2deg)',
      borderRadius: 3
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: '700 1.1rem var(--font-document)',
      color: 'var(--text-document)'
    }
  }, "Mara Ionescu"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.75rem',
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, "Business Systems Analyst"), [100, 86, 64, 92, 70].map((w, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      height: 6,
      width: w + '%',
      background: 'var(--pine-200)',
      borderRadius: 3,
      margin: '13px 0'
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,320px),1fr))',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12,
      alignContent: 'start'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      font: 'var(--type-section-title)',
      color: 'var(--text-strong)'
    }
  }, "Your applications"), /*#__PURE__*/React.createElement(TaskCard, {
    emphasis: !applied,
    icon: "briefcase",
    title: "Northstar People \xB7 Business Systems Analyst",
    onClick: onOpen || onStart,
    meta: applied ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Pill, {
      size: "sm",
      tone: "good",
      icon: "send"
    }, "Sent today"), /*#__PURE__*/React.createElement(Pill, {
      size: "sm"
    }, "Tailored CV v1")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Pill, {
      size: "sm",
      tone: "info"
    }, "Not tailored yet"), /*#__PURE__*/React.createElement(Pill, {
      size: "sm",
      tone: "warn",
      icon: "circle-help"
    }, "1 thing to check"))
  }, applied ? 'Next: follow up with Ana Pop · 30 Oct' : 'Next: see your match and improve your CV'), /*#__PURE__*/React.createElement(TaskCard, {
    icon: "briefcase",
    title: "Lumen Bank \xB7 Process Analyst",
    onClick: onOpen,
    meta: /*#__PURE__*/React.createElement(Pill, {
      size: "sm"
    }, "Interview \xB7 28 Oct")
  }, "Tailored CV v2 \xB7 sent 14 Oct")), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      font: 'var(--type-section-title)',
      color: 'var(--text-strong)'
    }
  }, "Base CV"), /*#__PURE__*/React.createElement(Pill, {
    size: "sm",
    tone: "good",
    icon: "shield-check"
  }, "Confirmed by you")), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '6px 0 16px',
      fontSize: '.82rem',
      color: 'var(--text-muted)'
    }
  }, "v3 \xB7 saved 23 Oct. Every job version starts here."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 10
    }
  }, [['Content', 'circle-check', 'good', 'Looks good'], ['Structure', 'circle-check', 'good', 'Looks good'], ['Writing', 'circle-alert', 'warn', '2 bullets could be clearer']].map(([k, ic, t, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      fontSize: '.85rem'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: ic,
    size: 18,
    color: 'var(--status-' + t + '-fg)'
  }), /*#__PURE__*/React.createElement("b", {
    style: {
      fontWeight: 600,
      width: 80
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, v)))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 18
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "ghost",
    iconRight: "arrow-right",
    onClick: onImprove
  }, "Improve these")))));
}
window.HomeScreen = HomeScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/Home.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/Improve.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ImproveScreen({
  accepted,
  setAccepted,
  onNext
}) {
  const {
    ChangeCard,
    CVDocument,
    Button,
    Dialog
  } = window.CVizatDesignSystem_0f8e2e;
  const C = window.CVZ_DATA.changes;
  const [ask, setAsk] = React.useState(false);
  const toggle = id => setAccepted(a => a.includes(id) ? a.filter(x => x !== id) : [...a, id]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,420px),1fr))',
      gap: 24,
      alignItems: 'start',
      maxWidth: 1180,
      width: '100%',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      font: '700 2rem/1.15 var(--font-display)',
      letterSpacing: '-0.04em',
      color: 'var(--text-strong)'
    }
  }, "Keep what feels right"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '10px 0 0',
      color: 'var(--text-muted)',
      lineHeight: 1.6
    }
  }, "Every change uses facts you\u2019ve already confirmed. Untick anything you don\u2019t want \u2014 this only changes the CV for Northstar People.")), C.map(c => /*#__PURE__*/React.createElement(ChangeCard, _extends({
    key: c.id
  }, c, {
    checked: accepted.includes(c.id),
    onChange: () => toggle(c.id)
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 10,
      flexWrap: 'wrap',
      marginTop: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '.82rem',
      color: 'var(--text-muted)'
    }
  }, accepted.length, " of ", C.length, " changes kept"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconRight: "arrow-right",
    onClick: () => setAsk(true)
  }, "Save this job\u2019s CV"))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'sticky',
      top: 20
    }
  }, /*#__PURE__*/React.createElement(CVDocument, {
    template: "clar",
    scale: .82,
    name: "Mara Ionescu",
    titles: ['Business Systems Analyst'],
    contact: "Cluj-Napoca \xB7 mara.ionescu@example.com \xB7 +40 7xx xxx xxx",
    sections: window.CVZ_cv(accepted),
    highlight: C.filter(c => accepted.includes(c.id)).map(c => c.after)
  })), ask && /*#__PURE__*/React.createElement(Dialog, {
    title: "Also improve your Base CV?",
    onClose: () => setAsk(false),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      onClick: () => {
        setAsk(false);
        onNext(false);
      }
    }, "Only this job"), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      onClick: () => {
        setAsk(false);
        onNext(true);
      }
    }, "Update Base too"))
  }, "The new summary and the outcome bullet could help future applications. Your Base CV is where every new job starts \u2014 we\u2019ll save it as a new version you can undo."));
}
window.ImproveScreen = ImproveScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/Improve.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/Journeys.jsx
try { (() => {
function JourneysGuide() {
  const {
    Logo,
    Pill,
    Icon,
    Button
  } = ONB_DS;
  const J = RZ_JOURNEYS;
  const h2 = {
    margin: 0,
    font: '700 1.7rem/1.15 var(--font-display)',
    letterSpacing: '-0.035em',
    color: 'var(--text-strong)'
  };
  const label = {
    font: '700 .7rem var(--font-sans)',
    letterSpacing: '.12em',
    textTransform: 'uppercase',
    color: 'var(--text-muted)'
  };
  const idx = Object.entries(RZ_ROUTES).map(([r, x]) => ({
    id: x.id,
    name: x.name,
    j: x.journeys.join(' · '),
    states: x.states,
    href: RZ_HREF(r)
  })).concat(RZ_ONB.map(o => ({
    id: o.id,
    name: o.name,
    j: 'A',
    states: ['—'],
    href: RZ_HREF('onb:' + o.r),
    onb: true
  }))).sort((a, b) => a.id.localeCompare(b.id));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1240,
      margin: '0 auto',
      padding: '28px 44px 80px',
      display: 'grid',
      gap: 40
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 12,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    size: 28
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    href: "onboarding.html#/welcome",
    icon: "door-open"
  }, "Onboarding flow"), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    href: "mobile.html",
    icon: "smartphone"
  }, "Mobile screens"), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "primary",
    href: "app.html",
    iconRight: "arrow-right"
  }, "Open the app"))), /*#__PURE__*/React.createElement("section", {
    style: {
      display: 'grid',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: '750 .73rem var(--font-sans)',
      letterSpacing: '.14em',
      textTransform: 'uppercase',
      color: 'var(--text-accent)'
    }
  }, "Design guide \xB7 from research/ux"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      font: '700 3rem/1.05 var(--font-display)',
      letterSpacing: '-0.045em',
      color: 'var(--text-strong)',
      maxWidth: 760,
      textWrap: 'balance'
    }
  }, "Customer journeys"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: 'var(--text-muted)',
      fontSize: '1.02rem',
      lineHeight: 1.6,
      maxWidth: 680,
      textWrap: 'pretty'
    }
  }, "Nine journeys cover the whole product \u2014 from the first visit to a sent application, plus signing back in and what happens when something breaks. Every stage links to the screen in the prototype. In the app, the bar above each screen shows its ID, its journeys, the states you can switch between and the rules it must follow."), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,150px),1fr))',
      gap: 8,
      marginTop: 6
    }
  }, J.map((j, i) => /*#__PURE__*/React.createElement("a", {
    key: j.k,
    href: '#' + j.k,
    style: {
      display: 'grid',
      gap: 6,
      padding: '14px 16px',
      borderRadius: 14,
      border: '1px solid var(--border-subtle)',
      background: i === 0 ? 'var(--surface-hero)' : '#fff',
      textDecoration: 'none'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '700 1.4rem/1 var(--font-display)',
      color: 'var(--pine-600)'
    }
  }, j.k), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '.84rem',
      color: 'var(--text-strong)',
      fontWeight: 600,
      lineHeight: 1.35
    }
  }, j.name)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      flexWrap: 'wrap',
      fontSize: '.82rem',
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "repeat",
    size: 16,
    color: "var(--pine-600)"
  }), "The core loop: ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-strong)'
    }
  }, "A"), " once \u2192 ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-strong)'
    }
  }, "C \u2192 D \u2192 E \u2192 G"), " for every job, with ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-strong)'
    }
  }, "B"), " between jobs and ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-strong)'
    }
  }, "F"), " at the first download.")), J.map(j => /*#__PURE__*/React.createElement("section", {
    key: j.k,
    id: j.k,
    "data-screen-label": 'Journey ' + j.k,
    style: {
      display: 'grid',
      gap: 20,
      paddingTop: 32,
      borderTop: '1px solid var(--border-subtle)',
      scrollMarginTop: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,340px),1fr))',
      gap: '16px 40px',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 18,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      borderRadius: 16,
      background: 'var(--pine-600)',
      color: '#fff',
      display: 'grid',
      placeItems: 'center',
      font: '700 1.6rem var(--font-display)',
      flex: 'none'
    }
  }, j.k), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: h2
  }, j.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.84rem',
      color: 'var(--text-muted)'
    }
  }, "Starts: ", j.when), /*#__PURE__*/React.createElement("div", {
    style: {
      font: '500 1.05rem/1.5 var(--font-document)',
      color: 'var(--text-body)',
      fontStyle: 'italic'
    }
  }, j.goal))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 6,
      padding: '14px 16px',
      borderRadius: 12,
      background: 'var(--status-good-bg)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      ...label,
      color: 'var(--status-good-fg)'
    }
  }, "Done when"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '.9rem',
      color: 'var(--text-strong)',
      lineHeight: 1.5
    }
  }, j.done))), /*#__PURE__*/React.createElement("ol", {
    style: {
      listStyle: 'none',
      margin: 0,
      padding: 0,
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,210px),1fr))',
      gap: 10
    }
  }, j.stages.map((s, i) => /*#__PURE__*/React.createElement("li", {
    key: i,
    style: {
      display: 'grid',
      gridTemplateRows: 'auto 1fr auto',
      gap: 10,
      padding: '14px 16px',
      borderRadius: 14,
      border: '1px solid var(--border-subtle)',
      background: '#fff'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: 8,
      alignItems: 'baseline'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '700 .95rem var(--font-display)',
      color: 'var(--pine-300)'
    }
  }, i + 1), /*#__PURE__*/React.createElement("b", {
    style: {
      fontWeight: 650,
      color: 'var(--text-strong)',
      fontSize: '.92rem'
    }
  }, s.t)), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '600 .68rem var(--font-mono, monospace)',
      color: 'var(--pine-700)'
    }
  }, s.ux)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 8,
      fontSize: '.82rem',
      lineHeight: 1.5
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: label
  }, "User"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-body)',
      marginTop: 2
    }
  }, s.does)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: label
  }, "We show"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-body)',
      marginTop: 2
    }
  }, s.we))), /*#__PURE__*/React.createElement("a", {
    href: RZ_HREF(s.r, s.s),
    style: {
      fontSize: '.8rem',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4
    }
  }, "Open screen", s.s ? ' · ' + s.s : '', " ", /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-up-right",
    size: 14
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,340px),1fr))',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: label
  }, "When something goes wrong"), j.recover.map(r => /*#__PURE__*/React.createElement("div", {
    key: r,
    style: {
      display: 'flex',
      gap: 8,
      fontSize: '.86rem',
      color: 'var(--text-body)',
      lineHeight: 1.5
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "corner-down-right",
    size: 16,
    color: "var(--status-warn-fg)"
  }), r))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: label
  }, "Rules that must hold"), j.rules.map(r => /*#__PURE__*/React.createElement("div", {
    key: r,
    style: {
      display: 'flex',
      gap: 8,
      fontSize: '.86rem',
      color: 'var(--text-body)',
      lineHeight: 1.5
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "shield-check",
    size: 16,
    color: "var(--pine-600)"
  }), r)))))), /*#__PURE__*/React.createElement("section", {
    id: "index",
    style: {
      display: 'grid',
      gap: 16,
      paddingTop: 32,
      borderTop: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: h2
  }, "Screen index"), /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1px solid var(--border-subtle)',
      borderRadius: 14,
      overflow: 'hidden',
      background: '#fff'
    }
  }, idx.map((x, i) => /*#__PURE__*/React.createElement("a", {
    key: x.href,
    href: x.href,
    style: {
      display: 'grid',
      gridTemplateColumns: '110px minmax(0,1.2fr) 80px minmax(0,2fr)',
      gap: 12,
      alignItems: 'center',
      padding: '11px 16px',
      borderTop: i ? '1px solid var(--border-subtle)' : 0,
      textDecoration: 'none',
      fontWeight: 400,
      color: 'var(--text-body)',
      fontSize: '.84rem'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '600 .74rem var(--font-mono, monospace)',
      color: 'var(--pine-700)'
    }
  }, x.id), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 650,
      color: 'var(--text-strong)'
    }
  }, x.name, x.onb && /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 400,
      color: 'var(--text-muted)'
    }
  }, " \xB7 onboarding")), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, x.j), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: 4,
      flexWrap: 'wrap'
    }
  }, x.states.map(s => s === '—' ? null : /*#__PURE__*/React.createElement(Pill, {
    key: s,
    size: "sm",
    shape: "round"
  }, s)))))), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: '.8rem',
      color: 'var(--text-muted)',
      lineHeight: 1.55,
      maxWidth: 760
    }
  }, "Source: research/ux/journeys.md, screen-specifications.md and docs/product/prd.md \xA715\u201316. Synthetic data (Mara Ionescu \xB7 Northstar People). Scores are illustrative and uncalibrated; prices are placeholders.")));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(JourneysGuide, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/Journeys.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/MatchReport.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function MatchReportScreen({
  onNext,
  rtw,
  setRtw
}) {
  const {
    Button,
    Alert,
    FindingGroup,
    KeywordRow,
    MatchVerdict,
    Card,
    ProgressBar,
    ScoreRing,
    Dialog,
    Pill,
    RadioGroup
  } = window.CVizatDesignSystem_0f8e2e;
  const [ans, setAns] = React.useState('yes');
  const F = window.CVZ_DATA.findings;
  const [how, setHow] = React.useState(false);
  const [ask, setAsk] = React.useState(false);
  const rows = list => list.map((k, i) => /*#__PURE__*/React.createElement(KeywordRow, _extends({
    key: k.term
  }, k, {
    last: i === list.length - 1
  })));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 24,
      alignItems: 'flex-start',
      maxWidth: 1120,
      width: '100%',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 16,
      minWidth: 0,
      flex: '999 1 480px'
    }
  }, /*#__PURE__*/React.createElement(MatchVerdict, {
    score: 62,
    headline: "Good fit \u2014 your CV just doesn\u2019t show it yet.",
    summary: "You have the experience for 9 of 10 requirements. 3 of them aren\u2019t in this CV. Adding them takes about two minutes.",
    counts: [{
      value: 4,
      label: 'Already in your CV'
    }, {
      value: 3,
      label: 'Ready to add',
      color: 'var(--status-info-fg)'
    }, {
      value: rtw ? 0 : 1,
      label: 'To check',
      color: 'var(--status-warn-fg)'
    }],
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "lg",
      iconRight: "arrow-right",
      onClick: onNext
    }, "Add the 3 missing things")
  }), !rtw && /*#__PURE__*/React.createElement(Alert, {
    tone: "warn",
    title: "Can you work in Romania?",
    action: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      onClick: () => setAsk(true)
    }, "Answer")
  }, "The job requires it. We don\u2019t know yet, so we\u2019ll keep reminding you \u2014 your score doesn\u2019t change."), rtw && /*#__PURE__*/React.createElement(Alert, {
    tone: "good",
    title: "Right to work in Romania: yes"
  }, "Based on what you told us. Employers may ask for proof."), /*#__PURE__*/React.createElement(FindingGroup, {
    tone: "info",
    icon: "sparkles",
    title: "Ready to add",
    count: "3",
    subtitle: "You have these \u2014 they\u2019re just not in this CV."
  }, rows(F.add)), /*#__PURE__*/React.createElement(FindingGroup, {
    tone: "good",
    icon: "circle-check",
    title: "Already strong",
    count: "4",
    subtitle: "Requirements your CV already shows.",
    defaultOpen: false
  }, rows(F.strong)), /*#__PURE__*/React.createElement(FindingGroup, {
    tone: "neutral",
    icon: "minus",
    title: "Not in your experience",
    count: "1",
    subtitle: "Nothing to fix \u2014 we won\u2019t add things you haven\u2019t done.",
    defaultOpen: false
  }, rows(F.gap))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 16,
      position: 'sticky',
      top: 20,
      flex: '1 1 280px'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "sm"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-around'
    }
  }, /*#__PURE__*/React.createElement(ScoreRing, {
    value: 90,
    size: 88,
    label: "You vs the job"
  }), /*#__PURE__*/React.createElement(ScoreRing, {
    untested: true,
    size: 88,
    label: "PDF readability"
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '14px 0 0',
      fontSize: '.78rem',
      color: 'var(--text-muted)',
      lineHeight: 1.5
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-strong)'
    }
  }, "You vs the job"), " uses everything you\u2019ve confirmed. ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-strong)'
    }
  }, "This CV"), " (62) only counts what\u2019s on the page. Readability is tested on the real PDF."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    icon: how ? 'chevron-up' : 'chevron-down',
    onClick: () => setHow(!how)
  }, "How this is calculated")), how && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12,
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement(ProgressBar, {
    label: "Tools & technical",
    valueLabel: "2 of 3",
    value: 2,
    max: 3
  }), /*#__PURE__*/React.createElement(ProgressBar, {
    label: "Responsibilities",
    valueLabel: "2 of 3",
    value: 2,
    max: 3
  }), /*#__PURE__*/React.createElement(ProgressBar, {
    label: "Experience",
    valueLabel: "1 of 1",
    value: 1,
    max: 1
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: '.72rem',
      color: 'var(--text-muted)',
      lineHeight: 1.5
    }
  }, "Required items count 3\xD7, nice-to-haves 1\xD7. Rewording alone never raises the score. This is an estimate, not an employer\u2019s ATS or a hiring prediction."))), /*#__PURE__*/React.createElement(Card, {
    padding: "sm",
    tone: "sunken"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.8rem',
      color: 'var(--text-muted)',
      lineHeight: 1.5
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-strong)',
      display: 'block',
      marginBottom: 4
    }
  }, "Northstar People"), "Business Systems Analyst \u2014 Automation", /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8,
      display: 'flex',
      gap: 6,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Pill, {
    size: "sm"
  }, "6 required"), /*#__PURE__*/React.createElement(Pill, {
    size: "sm"
  }, "2 nice to have"))))), ask && /*#__PURE__*/React.createElement(Dialog, {
    title: "Can you legally work in Romania?",
    onClose: () => setAsk(false),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      onClick: () => setAsk(false)
    }, "Later"), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      onClick: () => {
        if (ans === 'yes') setRtw(true);
        setAsk(false);
      }
    }, "Save answer"))
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 16px',
      color: 'var(--text-muted)'
    }
  }, "We\u2019ll note this for this job only. It isn\u2019t added to your CV and doesn\u2019t change your score."), /*#__PURE__*/React.createElement(RadioGroup, {
    value: ans,
    onChange: setAns,
    options: [{
      value: 'yes',
      label: 'Yes',
      description: 'Citizen, EU national or valid permit'
    }, {
      value: 'no',
      label: 'No',
      description: 'We’ll flag it as a requirement gap'
    }, {
      value: 'unsure',
      label: 'Not sure',
      description: 'We’ll keep reminding you'
    }]
  })));
}
window.MatchReportScreen = MatchReportScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/MatchReport.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/Mobile.jsx
try { (() => {
const RZ_PHONES = [{
  group: 'Onboarding',
  note: 'Compact step header with progress; one column; actions at the bottom of the flow.',
  items: [['onb', 'welcome', 'Welcome', 'UX01'], ['onb', 'account', 'Create account', 'UX02'], ['onb', 'import', 'Import CV', 'UX03'], ['onb', 'review', 'Check details', 'UX05']]
}, {
  group: 'Everyday',
  note: 'Bottom tab bar (5 destinations, 58px targets). LinkedIn check sits in the header.',
  items: [['app', 'home', 'Home', 'UX01'], ['app', 'base', 'Base CV · edit', 'UX06'], ['app', 'base/Review', 'Base CV · review', 'UX06'], ['app', 'enrich', 'Improve profile', 'UX08'], ['app', 'applications', 'Applications', 'UX20'], ['app', 'application', 'Application', 'UX20']]
}, {
  group: 'Job flow',
  note: 'No tabs inside the flow. “Step n of 5” + progress replaces the stepper; preview stacks under the editor.',
  items: [['app', 'addjob', 'Add a job', 'UX09'], ['app', 'requirements', 'Requirements', 'UX10'], ['app', 'match', 'Match report', 'UX11'], ['app', 'compare', 'Review changes', 'UX13'], ['app', 'preview', 'Template & download', 'UX16']]
}, {
  group: 'Account, sign-in & system',
  note: 'System and sign-in pages keep only the logo — no tabs — and one clear next step.',
  items: [['app', 'account', 'Account', 'UX18'], ['app', 'checkout/Pending', 'Checkout · pending', 'UX17'], ['app', 'login/Wrong%20password', 'Log in · error', 'AUTH01'], ['app', 'notfound', 'Page not found', 'SYS01'], ['app', 'offline', 'Offline', 'SYS03']]
}];
function MobileBoard() {
  const {
    Logo
  } = ONB_DS;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      top: 0,
      padding: '80px 90px 120px',
      display: 'grid',
      gap: 90,
      fontFamily: 'var(--font-sans)',
      color: 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'grid',
      gap: 14,
      maxWidth: 900
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    size: 34
  }), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      font: '700 3.4rem/1.05 var(--font-display)',
      letterSpacing: '-0.045em',
      color: 'var(--text-strong)'
    }
  }, "Mobile screens"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: '1.15rem',
      lineHeight: 1.6,
      color: 'var(--text-muted)',
      maxWidth: 820
    }
  }, "Below 760px the app switches to bottom tabs, a compact step header, stacked content and 44px+ touch targets. Every phone here is the live app \u2014 tap through it. The same layout appears when the real app is opened on a narrow screen.")), RZ_PHONES.map(g => /*#__PURE__*/React.createElement("section", {
    key: g.group,
    "data-screen-label": g.group,
    style: {
      display: 'grid',
      gap: 28
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      font: '700 2rem/1.1 var(--font-display)',
      letterSpacing: '-0.035em',
      color: 'var(--text-strong)'
    }
  }, g.group), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '1rem',
      color: 'var(--text-muted)'
    }
  }, g.note)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 56,
      alignItems: 'flex-start'
    }
  }, g.items.map(([kind, init, name, id]) => /*#__PURE__*/React.createElement("div", {
    key: init,
    style: {
      display: 'grid',
      gap: 16,
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      alignItems: 'baseline'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '600 .9rem var(--font-mono, monospace)',
      color: 'var(--pine-700)'
    }
  }, id), /*#__PURE__*/React.createElement("b", {
    style: {
      fontSize: '1.15rem',
      fontWeight: 650,
      color: 'var(--text-strong)'
    }
  }, name)), /*#__PURE__*/React.createElement(IOSDevice, null, kind === 'onb' ? /*#__PURE__*/React.createElement(OnboardingApp, {
    embed: true,
    initial: init
  }) : /*#__PURE__*/React.createElement(ResumoraApp, {
    embed: true,
    initial: init
  }))))))));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(MobileBoard, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/Mobile.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/OnbApp.jsx
try { (() => {
function OnboardingApp({
  initial,
  embed
}) {
  const {
    TopBar,
    Stepper,
    IconButton,
    Button,
    Logo,
    Toast
  } = ONB_DS;
  const mobile = rzUseMobile(embed);
  const saved = embed ? {} : JSON.parse(localStorage.getItem('rz-onb') || '{}');
  const ONB_ALL = ['welcome', 'account', 'verify', 'goals', 'import', 'reading', 'review', 'ready'];
  const fromHash = () => {
    const h = location.hash.replace(/^#\/?/, '');
    return ONB_ALL.includes(h) ? h : null;
  };
  const [screen, setScreenRaw] = React.useState(initial || fromHash() || saved.screen || 'welcome');
  const mainRef = React.useRef(null);
  React.useEffect(() => {
    if (embed) return;
    const f = () => {
      const h = fromHash();
      if (h) {
        setScreenRaw(h);
        window.scrollTo(0, 0);
      }
    };
    window.addEventListener('hashchange', f);
    return () => window.removeEventListener('hashchange', f);
  }, []);
  const [acct, setAcct] = React.useState(saved.acct || {
    name: '',
    email: '',
    pw: '',
    terms: false
  });
  const [goals, setGoals] = React.useState(saved.goals || {
    where: 'ro',
    target: ''
  });
  const [file, setFile] = React.useState(null);
  const [manual, setManual] = React.useState(false);
  const [flags, setFlags] = React.useState({
    scanned: false,
    fail: false
  });
  const [notice, setNotice] = React.useState(null);
  const [toast, setToast] = React.useState(null);
  const setScreen = s => {
    setScreenRaw(s);
    if (mainRef.current) mainRef.current.scrollTop = 0;
    if (!embed) window.scrollTo(0, 0);
  };
  React.useEffect(() => {
    if (!embed) localStorage.setItem('rz-onb', JSON.stringify({
      screen,
      acct: {
        ...acct,
        pw: ''
      },
      goals
    }));
  }, [screen, acct, goals]);
  const stepOf = {
    account: 0,
    verify: 0,
    goals: 1,
    import: 2,
    reading: 2,
    review: 3
  };
  const steps = ['Account', 'Your search', 'Your CV', 'Check details'];
  const top = embed ? 44 : 0,
    px = mobile ? 16 : 44;
  const login = () => {
    if (!embed) location.href = 'app.html#/login';
  };
  const demo = !embed && /*#__PURE__*/React.createElement(OnbDemoBar, {
    screen: screen,
    setScreen: setScreen,
    flags: flags,
    setFlags: setFlags
  });
  const root = {
    height: mobile ? embed ? '100%' : '100dvh' : undefined,
    minHeight: mobile ? undefined : '100vh',
    display: 'flex',
    flexDirection: 'column',
    background: 'var(--surface-page)',
    fontFamily: 'var(--font-sans)',
    color: 'var(--text-body)',
    textAlign: 'left',
    transform: embed ? 'translateZ(0)' : undefined,
    overflow: mobile ? 'hidden' : undefined
  };
  const mainStyle = pad => ({
    flex: 1,
    padding: pad,
    overflowY: mobile ? 'auto' : undefined,
    minHeight: 0
  });
  if (screen === 'welcome') return /*#__PURE__*/React.createElement("div", {
    style: root
  }, /*#__PURE__*/React.createElement("div", {
    ref: mainRef,
    style: {
      ...mainStyle(0),
      paddingTop: top
    }
  }, /*#__PURE__*/React.createElement(OnbWelcome, {
    mobile: mobile,
    onStart: () => setScreen('account'),
    onLogin: login
  })), demo);
  if (screen === 'ready') return /*#__PURE__*/React.createElement("div", {
    style: root
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      padding: top + 20 + 'px ' + px + 'px 0'
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    size: 30
  })), /*#__PURE__*/React.createElement("main", {
    ref: mainRef,
    style: mainStyle('12px ' + px + 'px 60px')
  }, /*#__PURE__*/React.createElement(OnbReady, {
    name: acct.name,
    onFirstJob: () => {
      if (!embed) location.href = 'app.html#/addjob';
    }
  })), toast && /*#__PURE__*/React.createElement(Toast, {
    icon: "shield-check"
  }, toast), demo);
  const signedIn = stepOf[screen] >= 1;
  return /*#__PURE__*/React.createElement("div", {
    style: root
  }, mobile ? /*#__PURE__*/React.createElement(RzMobileHead, {
    top: top,
    onClose: () => setScreen('welcome'),
    eyebrow: `Set up Resumora · step ${stepOf[screen] + 1} of 4`,
    title: steps[stepOf[screen]],
    progress: [stepOf[screen] + 1, 4],
    right: signedIn ? /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "ghost",
      onClick: () => setScreen('welcome')
    }, "Later") : null
  }) : /*#__PURE__*/React.createElement(TopBar, {
    back: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(IconButton, {
      icon: "x",
      label: "Exit",
      onClick: () => setScreen('welcome')
    }), /*#__PURE__*/React.createElement(Logo, {
      variant: "mark",
      size: 28
    })),
    title: "Set up Resumora",
    right: signedIn ? /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      onClick: () => setScreen('welcome')
    }, "Finish later") : null
  }, /*#__PURE__*/React.createElement(Stepper, {
    steps: steps,
    current: stepOf[screen],
    onStepClick: i => setScreen(['account', 'goals', 'import', 'review'][i])
  })), /*#__PURE__*/React.createElement("main", {
    ref: mainRef,
    style: mainStyle(mobile ? '24px 16px 48px' : '40px 44px 80px')
  }, screen === 'account' && /*#__PURE__*/React.createElement(OnbAccount, {
    data: acct,
    set: p => setAcct(a => ({
      ...a,
      ...p
    })),
    onNext: () => setScreen('verify'),
    onLogin: login
  }), screen === 'verify' && /*#__PURE__*/React.createElement(OnbVerify, {
    email: acct.email,
    onNext: () => setScreen('goals'),
    onChange: () => setScreen('account')
  }), screen === 'goals' && /*#__PURE__*/React.createElement(OnbGoals, {
    data: {
      ...goals,
      name: acct.name
    },
    set: p => setGoals(g => ({
      ...g,
      ...p
    })),
    onNext: () => setScreen('import'),
    onBack: () => setScreen('verify')
  }), screen === 'import' && /*#__PURE__*/React.createElement(OnbImport, {
    flags: flags,
    file: file,
    setFile: f => {
      setFile(f);
      setNotice(null);
    },
    notice: notice,
    onRead: () => {
      setManual(false);
      setScreen('reading');
    },
    onManual: () => {
      setManual(true);
      setScreen('review');
    },
    onBack: () => setScreen('goals')
  }), screen === 'reading' && /*#__PURE__*/React.createElement(OnbReading, {
    flags: flags,
    fileName: file && file.name,
    onDone: () => setScreen('review'),
    onCancel: () => {
      setNotice('Stopped. Nothing was saved — choose a file when you’re ready.');
      setScreen('import');
    }
  }), screen === 'review' && /*#__PURE__*/React.createElement(OnbReview, {
    acct: acct,
    goals: goals,
    manual: manual,
    onBack: () => setScreen('import'),
    onSave: f => {
      setAcct(a => ({
        ...a,
        name: f.name
      }));
      setScreen('ready');
      setToast('Saved — Base CV v1');
      setTimeout(() => setToast(null), 2800);
    }
  })), demo);
}
window.OnboardingApp = OnboardingApp;
if (!window.RZ_EMBED_PAGE) ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(OnboardingApp, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/OnbApp.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/OnbImport.jsx
try { (() => {
function OnbImport({
  flags,
  file,
  setFile,
  onRead,
  onManual,
  onBack,
  notice
}) {
  const {
    Card,
    Dropzone,
    Button,
    Alert,
    RadioGroup
  } = ONB_DS;
  const [mode, setMode] = React.useState('upload');
  const scanned = flags.scanned && !!file;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 980,
      margin: '0 auto',
      display: 'grid',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement(OnbTitle, {
    title: "Bring your CV once"
  }, "We read it, you check every detail, and it becomes your Base CV \u2014 the starting point for every job."), notice && /*#__PURE__*/React.createElement(Alert, {
    tone: "neutral",
    icon: "circle-stop"
  }, notice), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 24,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 20,
      flex: '2 1 480px',
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(RadioGroup, {
    name: "src",
    direction: "row",
    value: mode,
    onChange: setMode,
    options: [{
      value: 'upload',
      label: 'Upload my CV',
      description: 'Fastest. PDF or Word.'
    }, {
      value: 'manual',
      label: 'Start from scratch',
      description: 'We guide you, about 10 minutes.'
    }]
  }), mode === 'upload' ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Dropzone, {
    title: "Drop your CV here, or choose a file",
    acceptLabel: "PDF or DOCX \xB7 up to 10 MB",
    accept: ".pdf,.docx",
    file: file,
    onFile: f => setFile({
      name: f.name,
      size: f.size
    }),
    onRemove: () => setFile(null)
  }), !file && /*#__PURE__*/React.createElement("button", {
    onClick: () => setFile({
      name: 'Mara_Ionescu_CV_2026.pdf',
      size: '184 KB'
    }),
    style: {
      justifySelf: 'start',
      background: 'none',
      border: 0,
      padding: 0,
      font: '600 .82rem var(--font-sans)',
      color: 'var(--pine-600)',
      cursor: 'pointer'
    }
  }, "Use the example CV instead"), scanned && /*#__PURE__*/React.createElement(Alert, {
    tone: "warn",
    title: "This looks like a scanned image",
    action: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      onClick: onManual
    }, "Type it in")
  }, "We can\u2019t read text from photos or scans yet. Try a PDF with selectable text \u2014 or type it in, we\u2019ll guide you.")) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12,
      padding: '4px 0'
    }
  }, /*#__PURE__*/React.createElement(OnbPromise, {
    items: [['list-checks', 'One section at a time', 'Contact, roles, skills, education. Skip what you don’t have.'], ['calendar', 'Dates as precise as you know them', 'Only the year? That’s fine — we won’t invent a month.']]
  })))), /*#__PURE__*/React.createElement(OnbActions, {
    back: /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      icon: "arrow-left",
      onClick: onBack
    }, "Back")
  }, mode === 'upload' ? /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconRight: "arrow-right",
    disabled: !file || scanned,
    onClick: onRead
  }, "Read my CV") : /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconRight: "arrow-right",
    onClick: onManual
  }, "Start writing"))), /*#__PURE__*/React.createElement(Card, {
    tone: "sunken",
    style: {
      flex: '1 1 260px',
      width: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-section-title)',
      color: 'var(--text-strong)'
    }
  }, "What happens to your file"), /*#__PURE__*/React.createElement(OnbPromise, {
    items: [['scan-text', 'We read it to build your Base CV', 'Nothing is saved until you confirm it.'], ['lock', 'It stays private', 'Never shared with employers or other users.'], ['trash-2', 'You stay in control', 'Delete the file or your whole account from Account.']]
  })))));
}
function OnbReading({
  flags,
  fileName,
  onDone,
  onCancel
}) {
  const {
    Card,
    Button,
    Alert,
    ProgressBar,
    Icon,
    Spinner
  } = ONB_DS;
  const stages = ['Reading the text', 'Finding your roles and dates', 'Grouping your skills', 'Preparing it for you to check'];
  const [i, setI] = React.useState(0);
  const [failed, setFailed] = React.useState(false);
  const [run, setRun] = React.useState(0);
  React.useEffect(() => {
    setI(0);
    setFailed(false);
    const t = setInterval(() => setI(n => {
      if (flags.fail && run === 0 && n === 1) {
        clearInterval(t);
        setFailed(true);
        return n;
      }
      if (n >= stages.length - 1) {
        clearInterval(t);
        setTimeout(onDone, 700);
        return stages.length;
      }
      return n + 1;
    }), 950);
    return () => clearInterval(t);
  }, [run]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 560,
      margin: '24px auto 0',
      display: 'grid',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "lg"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 22
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 16,
      alignItems: 'center'
    }
  }, failed ? /*#__PURE__*/React.createElement(OnbIconTile, {
    icon: "file-x",
    tone: "bad",
    size: 48
  }) : /*#__PURE__*/React.createElement(Spinner, {
    size: 44
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: '700 1.35rem/1.2 var(--font-display)',
      letterSpacing: '-0.03em',
      color: 'var(--text-strong)'
    }
  }, failed ? 'We couldn’t finish reading it' : 'Reading your CV…'), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.84rem',
      color: 'var(--text-muted)',
      marginTop: 4,
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, fileName || 'Mara_Ionescu_CV_2026.pdf'))), !failed && /*#__PURE__*/React.createElement(ProgressBar, {
    value: Math.min(i, stages.length),
    max: stages.length,
    tone: "primary"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12
    }
  }, stages.map((s, n) => {
    const done = n < i,
      now = n === i && !failed,
      stop = failed && n === i;
    return /*#__PURE__*/React.createElement("div", {
      key: s,
      style: {
        display: 'flex',
        gap: 12,
        alignItems: 'center',
        fontSize: '.9rem',
        color: done || now ? 'var(--text-strong)' : 'var(--text-muted)',
        fontWeight: now ? 650 : 400
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: done ? 'circle-check' : stop ? 'circle-x' : now ? 'loader-circle' : 'circle',
      size: 18,
      color: done ? 'var(--status-good-fg)' : stop ? 'var(--status-bad-fg)' : now ? 'var(--pine-600)' : 'var(--sage-300)'
    }), s);
  })), failed ? /*#__PURE__*/React.createElement(Alert, {
    tone: "bad",
    action: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "primary",
      icon: "rotate-cw",
      onClick: () => setRun(r => r + 1)
    }, "Try again")
  }, "Your file is fine \u2014 this was on our side. Nothing was saved.") : /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.82rem',
      color: 'var(--text-muted)'
    }
  }, "Usually under a minute. You\u2019ll check everything before it\u2019s saved."))), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    onClick: onCancel
  }, failed ? 'Choose another file' : 'Stop reading')));
}
Object.assign(window, {
  OnbImport,
  OnbReading
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/OnbImport.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/OnbReview.jsx
try { (() => {
const ONB_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
function OnbSection({
  title,
  count,
  confirmed,
  onConfirm,
  onEdit,
  summary,
  children
}) {
  const {
    Card,
    Pill,
    Button
  } = ONB_DS;
  return /*#__PURE__*/React.createElement(Card, {
    selected: false,
    style: confirmed ? {
      background: 'var(--surface-card)'
    } : undefined
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 12,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      font: 'var(--type-section-title)',
      color: 'var(--text-strong)'
    }
  }, title), confirmed ? /*#__PURE__*/React.createElement(Pill, {
    size: "sm",
    tone: "good",
    icon: "shield-check"
  }, "Confirmed by you") : /*#__PURE__*/React.createElement(Pill, {
    size: "sm"
  }, "Extracted \xB7 not confirmed"), !confirmed && count > 0 && /*#__PURE__*/React.createElement(Pill, {
    size: "sm",
    tone: "warn",
    icon: "circle-help"
  }, count, " to check")), confirmed ? /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "ghost",
    icon: "pencil",
    onClick: onEdit
  }, "Edit") : null), confirmed ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8,
      fontSize: '.86rem',
      color: 'var(--text-muted)'
    }
  }, summary) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 16,
      marginTop: 18
    }
  }, children, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      paddingTop: 4
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    icon: "check",
    disabled: count > 0,
    onClick: onConfirm
  }, count > 0 ? 'Check the highlighted items first' : 'This is right'))));
}
function OnbCheck({
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12,
      padding: 14,
      borderRadius: 10,
      background: 'var(--status-warn-bg)',
      border: '1px solid var(--status-warn-border)'
    }
  }, children);
}
function OnbReview({
  acct,
  goals,
  manual,
  onSave,
  onBack
}) {
  const {
    Field,
    Select,
    Checkbox,
    Button,
    Pill,
    CVDocument,
    ProgressBar,
    Alert,
    EmptyState,
    Icon
  } = ONB_DS;
  const [f, setF] = React.useState({
    name: acct.name || 'Mara Ionescu',
    email: acct.email || 'mara.ionescu@example.ro',
    phone: '',
    city: 'Cluj-Napoca',
    t1: 'Business Systems Analyst',
    t2: goals.target || '',
    month: '',
    monthDone: false,
    workday: null,
    ack: false
  });
  const set = p => setF(s => ({
    ...s,
    ...p
  }));
  const [ok, setOk] = React.useState({
    about: false,
    exp: false,
    skills: false,
    edu: false
  });
  const conf = (k, v = true) => setOk(s => ({
    ...s,
    [k]: v
  }));
  const nOk = Object.values(ok).filter(Boolean).length;
  const expCheck = f.monthDone ? 0 : 1,
    skillCheck = f.workday === null ? 1 : 0;
  const tech = ['SQL', 'Excel', 'REST APIs'].concat(f.workday ? ['Workday'] : []);
  const start = (f.month ? ONB_MONTHS[+f.month - 1] + ' ' : '') + '2021';
  const bw = ['Mapped approval workflows with stakeholders across finance and HR.', 'Wrote SQL reports used in monthly payroll reconciliation.', 'Automated payroll exports via REST APIs for 3 HR teams.'];
  const sections = manual ? [] : [{
    title: 'Summary',
    text: 'Analyst with 6 years in HR operations and process improvement.'
  }, {
    title: 'Experience',
    items: [{
      heading: 'Systems Analyst — BridgeWorks',
      dates: start + ' — Present',
      sub: 'Cluj-Napoca',
      bullets: bw
    }, {
      heading: 'HR Operations Specialist — Carpatia Retail',
      dates: 'Mar 2019 — 2021',
      sub: 'Cluj-Napoca',
      bullets: ['Coordinated onboarding for 40+ hires per quarter.']
    }]
  }, {
    title: 'Skills',
    text: 'Process automation · Requirements analysis · Stakeholder management — ' + tech.join(' · ')
  }, {
    title: 'Education',
    items: [{
      heading: 'BSc Economic Informatics — Babeș-Bolyai University',
      dates: '2013 — 2016'
    }]
  }];
  const total = manual ? 1 : 4,
    done = manual ? ok.about ? 1 : 0 : nOk;
  const canSave = done === total && f.ack;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: '0 auto',
      display: 'grid',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement(OnbTitle, {
    title: manual ? 'Start your Base CV' : 'Check what we found'
  }, manual ? 'Begin with the basics. You’ll add roles and skills in the editor — at your own pace.' : 'Nothing is saved until you confirm. Fix anything that’s wrong — we only keep what you approve.'), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,440px),1fr))',
      gap: 28,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 16,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(ProgressBar, {
    value: done,
    max: total,
    label: "Sections confirmed",
    valueLabel: `${done} of ${total}`
  }), /*#__PURE__*/React.createElement(OnbSection, {
    title: "About you",
    count: 0,
    confirmed: ok.about,
    onConfirm: () => conf('about'),
    onEdit: () => conf('about', false),
    summary: [f.name, f.email, f.city, f.t1].filter(Boolean).join(' · ')
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,220px),1fr))',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Full name",
    icon: "user",
    value: f.name,
    onChange: v => set({
      name: v
    })
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Email",
    icon: "mail",
    type: "email",
    value: f.email,
    onChange: v => set({
      email: v
    })
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Phone",
    icon: "phone",
    type: "tel",
    optional: true,
    value: f.phone,
    onChange: v => set({
      phone: v
    }),
    hint: "We didn\u2019t find one in your CV."
  }), /*#__PURE__*/React.createElement(Field, {
    label: "City",
    icon: "map-pin",
    optional: true,
    value: f.city,
    onChange: v => set({
      city: v
    })
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Title",
    value: f.t1,
    onChange: v => set({
      t1: v
    }),
    hint: "Under your name. Not a past job title."
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Second title",
    optional: true,
    value: f.t2,
    onChange: v => set({
      t2: v
    }),
    hint: goals.target ? 'From your answer earlier.' : 'Useful if you apply for two kinds of role.'
  }))), manual ? /*#__PURE__*/React.createElement(EmptyState, {
    icon: "briefcase",
    title: "Your roles come next",
    actions: /*#__PURE__*/React.createElement(Pill, {
      tone: "info",
      icon: "info"
    }, "You\u2019ll add them in the editor")
  }, "After you save, we\u2019ll walk you through your most recent role first.") : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(OnbSection, {
    title: "Experience",
    count: expCheck,
    confirmed: ok.exp,
    onConfirm: () => conf('exp'),
    onEdit: () => conf('exp', false),
    summary: "2 roles \xB7 2019 \u2014 Present \xB7 about 6 years (overlaps counted once)"
  }, [['Systems Analyst', 'BridgeWorks', start + ' — Present', bw.length], ['HR Operations Specialist', 'Carpatia Retail', 'Mar 2019 — 2021', 1]].map(([t, c, d, n], i) => /*#__PURE__*/React.createElement("div", {
    key: c,
    style: {
      display: 'grid',
      gap: 12,
      paddingBottom: i ? 0 : 16,
      borderBottom: i ? 0 : '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 12,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 650,
      color: 'var(--text-strong)'
    }
  }, t, " \xB7 ", c), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.82rem',
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, d, " \xB7 Cluj-Napoca \xB7 ", n, " ", n === 1 ? 'bullet' : 'bullets')), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "ghost",
    icon: "pencil"
  }, "Edit role")), i === 0 && !f.monthDone && /*#__PURE__*/React.createElement(OnbCheck, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      fontSize: '.86rem',
      color: 'var(--text-strong)',
      lineHeight: 1.5
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "circle-help",
    size: 18,
    color: "var(--status-warn-fg)"
  }), /*#__PURE__*/React.createElement("span", null, "We found only the year you started: ", /*#__PURE__*/React.createElement("b", {
    style: {
      fontWeight: 650
    }
  }, "2021"), ". Add the month if you know it \u2014 or keep just the year. We won\u2019t guess.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      alignItems: 'end',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 200
    }
  }, /*#__PURE__*/React.createElement(Select, {
    label: "Start month",
    size: "sm",
    value: f.month,
    onChange: v => set({
      month: v
    }),
    placeholder: "Not sure",
    options: ONB_MONTHS.map((m, k) => ({
      value: String(k + 1),
      label: m
    }))
  })), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "primary",
    onClick: () => set({
      monthDone: true
    })
  }, f.month ? 'Use ' + start : 'Keep “2021”')))))), /*#__PURE__*/React.createElement(OnbSection, {
    title: "Skills",
    count: skillCheck,
    confirmed: ok.skills,
    onConfirm: () => conf('skills'),
    onEdit: () => conf('skills', false),
    summary: `3 professional · ${tech.length} technical`
  }, [['Professional', ['Process automation', 'Requirements analysis', 'Stakeholder management']], ['Technical', tech]].map(([g, list]) => /*#__PURE__*/React.createElement("div", {
    key: g,
    style: {
      display: 'grid',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-label)',
      color: 'var(--text-strong)'
    }
  }, g), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 6
    }
  }, list.map(s => /*#__PURE__*/React.createElement(Pill, {
    key: s,
    shape: "round"
  }, s))))), f.workday === null && /*#__PURE__*/React.createElement(OnbCheck, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      fontSize: '.86rem',
      color: 'var(--text-strong)',
      lineHeight: 1.5
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "circle-help",
    size: 18,
    color: "var(--status-warn-fg)"
  }), /*#__PURE__*/React.createElement("span", null, "Your CV says \u201Cfamiliar with Workday\u201D. Should we list ", /*#__PURE__*/React.createElement("b", {
    style: {
      fontWeight: 650
    }
  }, "Workday"), " as a technical skill?")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "primary",
    onClick: () => set({
      workday: true
    })
  }, "Yes, I use it"), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    onClick: () => set({
      workday: false
    })
  }, "No, leave it out")))), /*#__PURE__*/React.createElement(OnbSection, {
    title: "Education",
    count: 0,
    confirmed: ok.edu,
    onConfirm: () => conf('edu'),
    onEdit: () => conf('edu', false),
    summary: "BSc Economic Informatics \xB7 Babe\u0219-Bolyai University \xB7 2013 \u2014 2016"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 650,
      color: 'var(--text-strong)'
    }
  }, "BSc Economic Informatics \xB7 Babe\u0219-Bolyai University"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.82rem',
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, "2013 \u2014 2016 \xB7 Cluj-Napoca")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 16,
      padding: '20px 0 0',
      borderTop: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    variant: "card",
    checked: f.ack,
    onChange: v => set({
      ack: v
    }),
    label: "Everything here is true and about me",
    description: "We\u2019ll only ever use these facts. Wording can change per job \u2014 facts can\u2019t."
  }), /*#__PURE__*/React.createElement(OnbActions, {
    back: /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      icon: "arrow-left",
      onClick: onBack
    }, "Back")
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    icon: "shield-check",
    disabled: !canSave,
    onClick: () => onSave(f)
  }, "Save as my Base CV")), !canSave && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.8rem',
      color: 'var(--text-muted)',
      textAlign: 'right'
    }
  }, done < total ? `Confirm ${total - done} more ${total - done === 1 ? 'section' : 'sections'} to save.` : 'Tick the box above to save.'))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'sticky',
      top: 20,
      display: 'grid',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-label)',
      color: 'var(--text-strong)'
    }
  }, "Preview"), /*#__PURE__*/React.createElement(Pill, {
    size: "sm",
    icon: "languages"
  }, goals.where === 'ro' ? 'Română' : 'English')), /*#__PURE__*/React.createElement(CVDocument, {
    template: "clar",
    name: f.name,
    titles: [f.t1, f.t2].filter(Boolean),
    contact: [f.email, f.phone, f.city].filter(Boolean).join(' · '),
    sections: sections
  }))));
}
function OnbReady({
  name,
  onFirstJob
}) {
  const {
    Card,
    Button,
    TaskCard,
    Pill,
    Icon
  } = ONB_DS;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 880,
      margin: '0 auto',
      display: 'grid',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("section", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'auto minmax(0,1fr)',
      gap: 24,
      alignItems: 'center',
      background: 'var(--surface-hero)',
      border: '1px solid #d6e4d9',
      borderRadius: 'var(--radius-hero)',
      padding: '38px'
    }
  }, /*#__PURE__*/React.createElement(OnbIconTile, {
    icon: "shield-check",
    tone: "inverse",
    size: 64
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      font: '700 2.3rem/1.1 var(--font-display)',
      letterSpacing: '-0.045em',
      color: 'var(--text-strong)',
      textWrap: 'balance'
    }
  }, "Your Base CV is ready, ", (name || 'Mara').split(' ')[0]), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '12px 0 0',
      color: 'var(--text-muted)',
      lineHeight: 1.6,
      maxWidth: 520
    }
  }, "v1 \xB7 saved just now. Every job version starts from here \u2014 and it only changes when you say so."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginTop: 22,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconRight: "arrow-right",
    onClick: onFirstJob
  }, "Add my first job"), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    icon: "file-user"
  }, "Open my Base CV")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      font: 'var(--type-section-title)',
      color: 'var(--text-strong)'
    }
  }, "When you have a few minutes"), /*#__PURE__*/React.createElement(TaskCard, {
    icon: "sparkles",
    title: "Make your CV stronger",
    meta: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Pill, {
      size: "sm"
    }, "About 3 min"), /*#__PURE__*/React.createElement(Pill, {
      size: "sm",
      tone: "info",
      icon: "shield-check"
    }, "Only facts you confirm"))
  }, "4 short questions about results you haven\u2019t written down yet."), /*#__PURE__*/React.createElement(TaskCard, {
    icon: "layout-template",
    title: "Choose how your CV looks",
    meta: /*#__PURE__*/React.createElement(Pill, {
      size: "sm"
    }, "2 templates")
  }, "Clar or Contur. Same facts, different presentation.")));
}
Object.assign(window, {
  OnbReview,
  OnbReady
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/OnbReview.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/OnbShared.jsx
try { (() => {
const ONB_DS = window.CVizatDesignSystem_0f8e2e;
function OnbTitle({
  eyebrow,
  title,
  children,
  center
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: center ? 'center' : 'left'
    }
  }, eyebrow && /*#__PURE__*/React.createElement("div", {
    style: {
      font: '750 .73rem var(--font-sans)',
      letterSpacing: '.14em',
      textTransform: 'uppercase',
      color: 'var(--text-accent)',
      marginBottom: 10
    }
  }, eyebrow), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      font: '700 2rem/1.15 var(--font-display)',
      letterSpacing: '-0.04em',
      color: 'var(--text-strong)',
      textWrap: 'balance'
    }
  }, title), children && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '10px 0 0',
      color: 'var(--text-muted)',
      lineHeight: 1.6,
      textWrap: 'pretty',
      maxWidth: center ? 520 : 600,
      marginInline: center ? 'auto' : 0
    }
  }, children));
}
function OnbIconTile({
  icon,
  tone = 'good',
  size = 56
}) {
  const {
    Icon
  } = ONB_DS;
  const inv = tone === 'inverse';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: size,
      height: size,
      borderRadius: 16,
      display: 'grid',
      placeItems: 'center',
      background: inv ? 'var(--pine-600)' : 'var(--status-' + tone + '-bg)',
      color: inv ? '#fff' : 'var(--status-' + tone + '-fg)',
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: Math.round(size * .46)
  }));
}
function OnbActions({
  back,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 12,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", null, back), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      flexWrap: 'wrap'
    }
  }, children));
}
function OnbPromise({
  items
}) {
  const {
    Icon
  } = ONB_DS;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12
    }
  }, items.map(([ic, t, d]) => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--pine-600)',
      marginTop: 1
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: ic,
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 650,
      fontSize: '.88rem',
      color: 'var(--text-strong)'
    }
  }, t), d && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.82rem',
      color: 'var(--text-muted)',
      lineHeight: 1.5,
      marginTop: 2
    }
  }, d)))));
}
function OnbDemoBar({
  screen,
  setScreen,
  flags,
  setFlags
}) {
  const [open, setOpen] = React.useState(false);
  const screens = [['welcome', 'Welcome'], ['account', 'Create account'], ['verify', 'Verify email'], ['goals', 'Your search'], ['import', 'Import CV'], ['reading', 'Reading'], ['review', 'Check details'], ['ready', 'Ready']];
  const chip = on => ({
    padding: '6px 10px',
    borderRadius: 999,
    border: '1px solid ' + (on ? 'var(--pine-600)' : 'var(--border-subtle)'),
    background: on ? 'var(--pine-50)' : '#fff',
    color: on ? 'var(--pine-700)' : 'var(--text-body)',
    font: '600 .74rem var(--font-sans)',
    cursor: 'pointer'
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      left: 16,
      bottom: 16,
      zIndex: 50,
      display: 'grid',
      gap: 8,
      justifyItems: 'start'
    }
  }, open && /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      border: '1px solid var(--border-subtle)',
      borderRadius: 14,
      boxShadow: 'var(--shadow-toast)',
      padding: 14,
      display: 'grid',
      gap: 10,
      width: 300
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: '700 .7rem var(--font-sans)',
      letterSpacing: '.12em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)'
    }
  }, "Jump to screen"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 6
    }
  }, screens.map(([v, l]) => /*#__PURE__*/React.createElement("button", {
    key: v,
    style: chip(screen === v),
    onClick: () => setScreen(v)
  }, l))), /*#__PURE__*/React.createElement("div", {
    style: {
      font: '700 .7rem var(--font-sans)',
      letterSpacing: '.12em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
      marginTop: 4
    }
  }, "Simulate"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("button", {
    style: chip(flags.scanned),
    onClick: () => setFlags(f => ({
      ...f,
      scanned: !f.scanned
    }))
  }, "Scanned file"), /*#__PURE__*/React.createElement("button", {
    style: chip(flags.fail),
    onClick: () => setFlags(f => ({
      ...f,
      fail: !f.fail
    }))
  }, "Reading fails"))), /*#__PURE__*/React.createElement("button", {
    onClick: () => setOpen(o => !o),
    style: {
      ...chip(open),
      boxShadow: 'var(--shadow-toast)',
      padding: '8px 14px'
    }
  }, open ? 'Close demo' : 'Demo controls'));
}
function rzUseMobile(force) {
  const q = '(max-width: 760px)';
  const [m, setM] = React.useState(() => window.matchMedia(q).matches);
  React.useEffect(() => {
    const mq = window.matchMedia(q);
    const f = () => setM(mq.matches);
    mq.addEventListener('change', f);
    return () => mq.removeEventListener('change', f);
  }, []);
  return !!force || m;
}
function RzMobileHead({
  top = 0,
  onClose,
  eyebrow,
  title,
  right,
  progress,
  logo
}) {
  const {
    IconButton,
    ProgressBar,
    Logo
  } = ONB_DS;
  return /*#__PURE__*/React.createElement("header", {
    style: {
      padding: top + 10 + 'px 12px 10px',
      background: '#fff',
      borderBottom: '1px solid var(--border-subtle)',
      display: 'grid',
      gap: 10,
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      minHeight: 44
    }
  }, onClose && /*#__PURE__*/React.createElement(IconButton, {
    variant: "ghost",
    icon: "x",
    label: "Exit",
    onClick: onClose
  }), logo && /*#__PURE__*/React.createElement("span", {
    style: {
      paddingLeft: 4,
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    variant: "mark",
    size: 28
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, eyebrow && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.72rem',
      color: 'var(--text-muted)'
    }
  }, eyebrow), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 650,
      color: 'var(--text-strong)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, title)), right), progress && /*#__PURE__*/React.createElement(ProgressBar, {
    value: progress[0],
    max: progress[1],
    height: 4
  }));
}
Object.assign(window, {
  ONB_DS,
  OnbTitle,
  OnbIconTile,
  OnbActions,
  OnbPromise,
  OnbDemoBar,
  rzUseMobile,
  RzMobileHead
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/OnbShared.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/OnbStart.jsx
try { (() => {
function OnbWelcome({
  onStart,
  onLogin,
  mobile
}) {
  const px = mobile ? '16px' : '44px';
  const {
    Button,
    Logo,
    Pill
  } = ONB_DS;
  const steps = [['Bring your CV once', 'We read it, you check every detail. It becomes your Base CV.'], ['Paste a job ad', 'See how well you fit and what your CV is missing — in plain words.'], ['Download a CV for that job', 'Same facts, better chosen. Your Base CV stays as it is.']];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: mobile ? undefined : '100vh',
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '16px ' + px
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    size: 30
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    onClick: onLogin
  }, "Log in")), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      padding: '12px ' + px + ' 60px',
      display: 'grid',
      gap: 28,
      maxWidth: 1120,
      width: '100%',
      margin: '0 auto',
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("section", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,380px),1fr))',
      gap: 40,
      alignItems: 'center',
      background: 'var(--surface-hero)',
      border: '1px solid #d6e4d9',
      borderRadius: 'var(--radius-hero)',
      padding: mobile ? '28px 20px' : '48px 44px'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: '750 .73rem var(--font-sans)',
      letterSpacing: '.14em',
      textTransform: 'uppercase',
      color: 'var(--text-accent)',
      marginBottom: 14
    }
  }, "For job seekers in Romania"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      font: (mobile ? '700 2.1rem/1.08' : '700 3rem/1.05') + ' var(--font-display)',
      letterSpacing: '-0.045em',
      color: 'var(--text-strong)',
      textWrap: 'balance'
    }
  }, "One honest CV. The right version for every job."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '18px 0 0',
      color: 'var(--text-muted)',
      fontSize: '1.05rem',
      lineHeight: 1.6,
      maxWidth: 480,
      textWrap: 'pretty'
    }
  }, "Resumora shows how well you match a job and helps you say it better \u2014 without adding anything you haven\u2019t done."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginTop: 28,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconRight: "arrow-right",
    onClick: onStart
  }, "Create my free account"), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    icon: "play"
  }, "See an example first")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16,
      fontSize: '.8rem',
      color: 'var(--text-muted)'
    }
  }, "About 5 minutes to set up \xB7 no card needed")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      justifySelf: 'center',
      width: 'min(100%,340px)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      padding: '26px 28px',
      boxShadow: 'var(--shadow-paper)',
      transform: 'rotate(2deg)',
      borderRadius: 3
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: '700 1.15rem var(--font-document)',
      color: 'var(--text-document)'
    }
  }, "Mara Ionescu"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.75rem',
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, "Business Systems Analyst"), [100, 84, 62, 94, 70, 88].map((w, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      height: 6,
      width: w + '%',
      background: i === 2 ? 'var(--marigold-200)' : 'var(--pine-200)',
      borderRadius: 3,
      margin: '13px 0'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: -18,
      bottom: -14
    }
  }, /*#__PURE__*/React.createElement(Pill, {
    tone: "good",
    icon: "shield-check"
  }, "Confirmed by you")))), /*#__PURE__*/React.createElement("section", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,260px),1fr))',
      gap: 24
    }
  }, steps.map(([t, d], i) => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      display: 'grid',
      gap: 8,
      alignContent: 'start',
      padding: '4px 2px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: '700 1.6rem/1 var(--font-display)',
      color: 'var(--pine-300)',
      letterSpacing: '-0.04em'
    }
  }, i + 1), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-section-title)',
      color: 'var(--text-strong)'
    }
  }, t), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.9rem',
      color: 'var(--text-muted)',
      lineHeight: 1.55
    }
  }, d)))), /*#__PURE__*/React.createElement("section", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '10px 28px',
      paddingTop: 20,
      borderTop: '1px solid var(--border-subtle)',
      fontSize: '.84rem',
      color: 'var(--text-body)'
    }
  }, [['shield-check', 'We never invent experience or numbers'], ['lock', 'Your CV is never sent to employers'], ['info', 'Scores are estimates, not hiring predictions']].map(([ic, t]) => /*#__PURE__*/React.createElement("span", {
    key: t,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(ONB_DS.Icon, {
    name: ic,
    size: 16,
    color: "var(--pine-600)"
  }), t)))));
}
function OnbAccount({
  data,
  set,
  onNext,
  onLogin
}) {
  const {
    Card,
    Field,
    Checkbox,
    Button
  } = ONB_DS;
  const [tried, setTried] = React.useState(false);
  const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(data.email);
  const errs = {
    name: !data.name.trim() ? 'Add your name — it goes at the top of your CV.' : null,
    email: !emailOk ? 'Check the email — it should look like name@example.ro.' : null,
    pw: data.pw.length < 8 ? 'Use at least 8 characters.' : null,
    terms: !data.terms
  };
  const ok = !errs.name && !errs.email && !errs.pw && !errs.terms;
  const submit = () => {
    setTried(true);
    if (ok) onNext();
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 480,
      margin: '0 auto',
      display: 'grid',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement(OnbTitle, {
    title: "Create your account"
  }, "Your Base CV and every job version are saved here, so you can come back anytime."), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Full name",
    icon: "user",
    value: data.name,
    onChange: v => set({
      name: v
    }),
    hint: "As it should appear on your CV.",
    error: tried ? errs.name : undefined
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Email",
    icon: "mail",
    type: "email",
    value: data.email,
    onChange: v => set({
      email: v
    }),
    placeholder: "name@example.ro",
    error: tried ? errs.email : undefined,
    success: !tried && emailOk ? 'Looks right' : undefined
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Password",
    icon: "lock",
    type: "password",
    value: data.pw,
    onChange: v => set({
      pw: v
    }),
    hint: "At least 8 characters.",
    error: tried ? errs.pw : undefined,
    success: data.pw.length >= 8 ? 'Strong enough' : undefined
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    checked: data.terms,
    onChange: v => set({
      terms: v
    }),
    label: /*#__PURE__*/React.createElement("span", null, "I agree to the ", /*#__PURE__*/React.createElement("a", {
      href: "#",
      onClick: e => e.preventDefault()
    }, "Terms"), " and ", /*#__PURE__*/React.createElement("a", {
      href: "#",
      onClick: e => e.preventDefault()
    }, "Privacy policy")),
    description: "We use your CV only to tailor it for you. Export or delete everything anytime."
  }), tried && errs.terms && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.8rem',
      color: 'var(--status-bad-fg)',
      paddingLeft: 34
    }
  }, "Tick this to continue.")), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    iconRight: "arrow-right",
    onClick: submit
  }, "Create account"))), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      fontSize: '.86rem',
      color: 'var(--text-muted)'
    }
  }, "Already have an account? ", /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onLogin();
    }
  }, "Log in")));
}
function OnbVerify({
  email,
  onNext,
  onChange
}) {
  const {
    Card,
    Button,
    Alert
  } = ONB_DS;
  const [wait, setWait] = React.useState(0);
  React.useEffect(() => {
    if (!wait) return;
    const t = setTimeout(() => setWait(w => w - 1), 1000);
    return () => clearTimeout(t);
  }, [wait]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 520,
      margin: '0 auto',
      display: 'grid',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "lg"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 22,
      justifyItems: 'center',
      textAlign: 'center',
      padding: '8px 0'
    }
  }, /*#__PURE__*/React.createElement(OnbIconTile, {
    icon: "mail-check"
  }), /*#__PURE__*/React.createElement(OnbTitle, {
    center: true,
    title: "Check your inbox"
  }, "We sent a link to ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-strong)',
      fontWeight: 650
    }
  }, email || 'your email'), ". Open it to confirm it\u2019s you \u2014 then we\u2019ll continue right here."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      flexWrap: 'wrap',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    icon: "rotate-cw",
    disabled: wait > 0,
    onClick: () => setWait(30)
  }, wait ? `Resend in ${wait}s` : 'Resend email'), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    icon: "pencil",
    onClick: onChange
  }, "Change email")))), /*#__PURE__*/React.createElement(Alert, {
    tone: "info",
    title: "Can\u2019t find it?"
  }, "Look in Spam or Promotions. The link works for 24 hours."), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    iconRight: "arrow-right",
    onClick: onNext
  }, "Demo: open the link")));
}
function OnbGoals({
  data,
  set,
  onNext,
  onBack
}) {
  const {
    Card,
    RadioGroup,
    Field,
    Button
  } = ONB_DS;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 640,
      margin: '0 auto',
      display: 'grid',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement(OnbTitle, {
    eyebrow: data.name.trim() ? `Welcome, ${data.name.trim().split(' ')[0]}` : 'Welcome',
    title: "Tell us about your search"
  }, "Two quick answers so your first CV starts in the right language. You can change both later."), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement(RadioGroup, {
    label: "Where are you applying?",
    name: "where",
    value: data.where,
    onChange: v => set({
      where: v
    }),
    options: [{
      value: 'ro',
      label: 'In Romania',
      description: 'Your CVs start in Romanian.'
    }, {
      value: 'abroad',
      label: 'Abroad or at international companies',
      description: 'Your CVs start in English.'
    }, {
      value: 'both',
      label: 'Both',
      description: 'We’ll ask the language for each job.'
    }]
  }), /*#__PURE__*/React.createElement(Field, {
    label: "What role are you aiming for?",
    icon: "target",
    optional: true,
    value: data.target,
    onChange: v => set({
      target: v
    }),
    placeholder: "e.g. Business Systems Analyst",
    hint: "Shown under your name as a positioning title. It doesn\u2019t change your past job titles."
  }))), /*#__PURE__*/React.createElement(OnbActions, {
    back: /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      icon: "arrow-left",
      onClick: onBack
    }, "Back")
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    onClick: onNext
  }, "Skip for now"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconRight: "arrow-right",
    disabled: !data.where,
    onClick: onNext
  }, "Continue")));
}
Object.assign(window, {
  OnbWelcome,
  OnbAccount,
  OnbVerify,
  OnbGoals
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/OnbStart.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/ScrAccount.jsx
try { (() => {
function PlansScreen({
  go
}) {
  const {
    PlanCard,
    Button
  } = ONB_DS;
  const [sel, setSel] = React.useState('3');
  const plans = [['1', '1 month', 'Renews every month'], ['3', '3 months', 'Renews every 3 months'], ['6', '6 months', 'Renews every 6 months']];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 980,
      margin: '0 auto',
      display: 'grid',
      gap: 26
    }
  }, /*#__PURE__*/React.createElement(OnbTitle, {
    center: true,
    title: "Choose a plan"
  }, "Editing, your match and previews stay free. A plan lets you download your CVs as PDF."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,260px),1fr))',
      gap: 16
    }
  }, plans.map(([v, t, n]) => /*#__PURE__*/React.createElement(PlanCard, {
    key: v,
    term: t,
    price: "\u2014 RON",
    note: n,
    selected: sel === v,
    onSelect: () => setSel(v),
    features: ['PDF downloads, checked for readability', 'Match report for every job', 'Monthly allowance resets each month', 'Cancel anytime']
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      justifyItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconRight: "arrow-right",
    onClick: () => go('checkout')
  }, "Continue with ", plans.find(p => p[0] === sel)[1]), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.8rem',
      color: 'var(--text-muted)'
    }
  }, "Prices and allowances aren\u2019t final yet. VAT included.")));
}
function CheckoutScreen({
  state,
  go,
  flash
}) {
  const {
    Card,
    Button,
    Checkbox,
    Alert,
    Spinner,
    Icon
  } = ONB_DS;
  const [st, setSt] = React.useState({
    Form: 'form',
    Pending: 'pending',
    Declined: 'declined',
    Active: 'active'
  }[state]);
  const [ack, setAck] = React.useState(false);
  const pay = () => {
    setSt('busy');
    setTimeout(() => setSt('active'), 1500);
  };
  const row = (k, v, b) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 12,
      fontSize: '.88rem',
      color: b ? 'var(--text-strong)' : 'var(--text-body)',
      fontWeight: b ? 650 : 400
    }
  }, /*#__PURE__*/React.createElement("span", null, k), /*#__PURE__*/React.createElement("span", null, v));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 980,
      margin: '0 auto',
      display: 'flex',
      flexWrap: 'wrap',
      gap: 24,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '2 1 480px',
      display: 'grid',
      gap: 16,
      minWidth: 0
    }
  }, st === 'form' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(OnbTitle, {
    title: "Checkout"
  }, "You\u2019ll enter your card on our payment provider\u2019s secure page."), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(OnbPromise, {
    items: [['lock', 'Resumora never sees your card number', 'Payments are handled by our provider.'], ['calendar-clock', 'Renews every 3 months', 'Until you cancel. Cancel anytime from Account — you keep access to the end of the period.']]
  }), /*#__PURE__*/React.createElement(Checkbox, {
    variant: "card",
    checked: ack,
    onChange: setAck,
    label: "I understand this plan renews every 3 months until I cancel"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconRight: "external-link",
    disabled: !ack,
    onClick: pay
  }, "Continue to payment"))))), st === 'busy' && /*#__PURE__*/React.createElement(Card, {
    padding: "lg"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '30px 0',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement(Spinner, {
    label: "Waiting for the payment provider to confirm\u2026"
  }))), st === 'pending' && /*#__PURE__*/React.createElement(Card, {
    padding: "lg"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 16,
      justifyItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(OnbIconTile, {
    icon: "hourglass",
    tone: "warn"
  }), /*#__PURE__*/React.createElement(OnbTitle, {
    title: "Waiting for your bank"
  }, "This can take a few minutes. You\u2019ll get access as soon as the payment is confirmed \u2014 not before."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: "rotate-cw",
    onClick: pay
  }, "Check again"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    onClick: () => go('home')
  }, "Back to my CVs")))), st === 'declined' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(OnbTitle, {
    title: "Checkout"
  }), /*#__PURE__*/React.createElement(Alert, {
    tone: "bad",
    title: "Your bank declined the payment",
    action: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "primary",
      onClick: () => setSt('form')
    }, "Try again")
  }, "Nothing was charged. Try again, or use another card on the next page."), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    icon: "arrow-left",
    onClick: () => go('plans')
  }, "Back to plans"))), st === 'active' && /*#__PURE__*/React.createElement(Card, {
    padding: "lg"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 16,
      justifyItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(OnbIconTile, {
    icon: "circle-check",
    tone: "inverse"
  }), /*#__PURE__*/React.createElement(OnbTitle, {
    title: "Your plan is active"
  }, "3 months \xB7 renews 25 Jan 2027. You can cancel anytime from Account."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: "download",
    onClick: () => go('preview')
  }, "Download my CV"), /*#__PURE__*/React.createElement(Button, {
    onClick: () => go('account')
  }, "Go to account"))))), /*#__PURE__*/React.createElement(Card, {
    tone: "sunken",
    style: {
      flex: '1 1 260px',
      width: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-section-title)',
      color: 'var(--text-strong)'
    }
  }, "Order summary"), row('Plan', '3 months'), row('Price', '— RON'), row('VAT', 'Included'), row('Renews', 'Every 3 months'), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--border-subtle)',
      paddingTop: 12
    }
  }, row('Total today', '— RON', true)), st === 'form' && /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    icon: "pencil",
    onClick: () => go('plans')
  }, "Change plan"))));
}
function AccountScreen({
  state,
  go,
  flash
}) {
  const {
    Card,
    Button,
    Field,
    Select,
    Pill,
    Alert,
    ProgressBar,
    Dialog,
    Checkbox
  } = ONB_DS;
  const [st, setSt] = React.useState(state);
  const [ask, setAsk] = React.useState(null);
  const [sure, setSure] = React.useState(false);
  const status = {
    'Active': ['good', 'Active'],
    'Cancel scheduled': ['warn', 'Ends 25 Jan 2027'],
    'Payment failed': ['bad', 'Payment failed'],
    'Free': ['neutral', 'Free']
  }[st];
  const H = ({
    children,
    right
  }) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 10,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-section-title)',
      color: 'var(--text-strong)'
    }
  }, children), right);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 820,
      margin: '0 auto',
      display: 'grid',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(OnbTitle, {
    title: "Account"
  }), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(H, {
    right: /*#__PURE__*/React.createElement(Pill, {
      size: "sm",
      tone: "good",
      icon: "mail-check"
    }, "Email verified")
  }, "Profile"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,220px),1fr))',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Name",
    defaultValue: "Mara Ionescu"
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Email",
    type: "email",
    defaultValue: "mara.ionescu@example.ro"
  }), /*#__PURE__*/React.createElement(Select, {
    label: "App language",
    icon: "languages",
    defaultValue: "ro",
    options: [{
      value: 'ro',
      label: 'Română'
    }, {
      value: 'en',
      label: 'English'
    }],
    hint: "Your CVs keep their own language."
  })))), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(H, {
    right: /*#__PURE__*/React.createElement(Pill, {
      size: "sm",
      tone: status[0]
    }, status[1])
  }, "Plan"), st === 'Free' ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.9rem',
      color: 'var(--text-muted)',
      lineHeight: 1.55
    }
  }, "You can edit, check matches and preview for free. Choose a plan when you want to download."), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    iconRight: "arrow-right",
    onClick: () => go('plans')
  }, "See plans"))) : /*#__PURE__*/React.createElement(React.Fragment, null, st === 'Cancel scheduled' && /*#__PURE__*/React.createElement(Alert, {
    tone: "neutral",
    icon: "calendar-x",
    action: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "primary",
      onClick: () => {
        setSt('Active');
        flash('Plan resumed — renews 25 Jan 2027');
      }
    }, "Resume plan")
  }, "Your plan ends on 25 Jan 2027. You keep full access until then, and your CVs stay here after."), st === 'Payment failed' && /*#__PURE__*/React.createElement(Alert, {
    tone: "bad",
    title: "We couldn\u2019t renew your plan",
    action: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "primary",
      onClick: () => go('checkout')
    }, "Update payment")
  }, "Downloads are paused. Your CVs, versions and applications are safe."), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.9rem',
      color: 'var(--text-body)'
    }
  }, "3 months \xB7 ", st === 'Cancel scheduled' ? 'doesn’t renew' : 'renews 25 Jan 2027'), /*#__PURE__*/React.createElement(ProgressBar, {
    label: "PDF downloads this month",
    valueLabel: "2 of 10",
    value: 2,
    max: 10
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.78rem',
      color: 'var(--text-muted)'
    }
  }, "Proposed allowance \xB7 resets 1 Nov"), st === 'Active' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    onClick: () => go('plans')
  }, "Change term"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    onClick: () => setAsk('cancel')
  }, "Cancel plan"))))), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(H, null, "Your data"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 12,
      alignItems: 'center',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.88rem',
      color: 'var(--text-muted)',
      lineHeight: 1.5,
      flex: '1 1 300px'
    }
  }, "Download everything: Base CV and its history, job CVs, applications with sent copies, and your answers."), /*#__PURE__*/React.createElement(Button, {
    icon: "download",
    onClick: () => flash('Export ready — resumora-data.json')
  }, "Export (JSON)")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 12,
      alignItems: 'center',
      flexWrap: 'wrap',
      paddingTop: 16,
      borderTop: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.88rem',
      color: 'var(--text-muted)',
      flex: '1 1 300px'
    }
  }, "Delete your account and everything in it."), /*#__PURE__*/React.createElement(Button, {
    variant: "danger",
    icon: "trash-2",
    onClick: () => {
      setSure(false);
      setAsk('delete');
    }
  }, "Delete account")))), ask === 'cancel' && /*#__PURE__*/React.createElement(Dialog, {
    title: "Cancel at the end of this period?",
    onClose: () => setAsk(null),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      onClick: () => setAsk(null)
    }, "Keep plan"), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      onClick: () => {
        setSt('Cancel scheduled');
        setAsk(null);
        flash('Cancelled — ends 25 Jan 2027');
      }
    }, "Cancel at period end"))
  }, "You keep access until 25 Jan 2027. Nothing renews after that, and your CVs stay in your account."), ask === 'delete' && /*#__PURE__*/React.createElement(Dialog, {
    title: "Delete your account?",
    onClose: () => setAsk(null),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      onClick: () => setAsk(null)
    }, "Keep my account"), /*#__PURE__*/React.createElement(Button, {
      variant: "danger",
      disabled: !sure,
      onClick: () => {
        setAsk(null);
        flash('Account scheduled for deletion');
      }
    }, "Delete everything"))
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 14px',
      color: 'var(--text-muted)',
      lineHeight: 1.55
    }
  }, "This removes your Base CV, every version, job CVs, applications and answers. It can\u2019t be undone. Export your data first if you want a copy."), /*#__PURE__*/React.createElement(Checkbox, {
    checked: sure,
    onChange: setSure,
    label: "I understand this can\u2019t be undone"
  })));
}
Object.assign(window, {
  PlansScreen,
  CheckoutScreen,
  AccountScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/ScrAccount.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/ScrApps.jsx
try { (() => {
const RZ_STAGE_TONE = {
  'To send': 'info',
  'Sent': 'neutral',
  'Interview': 'good',
  'Offer': 'good',
  'Closed': 'neutral'
};
function ApplicationsScreen({
  state,
  go
}) {
  const {
    Card,
    Button,
    Field,
    Segmented,
    Pill,
    EmptyState,
    Icon
  } = ONB_DS;
  const [q, setQ] = React.useState(state === 'No results' ? 'Siemens' : '');
  const [f, setF] = React.useState('All');
  const apps = state === 'Empty' ? [] : RZ_APP.apps;
  const list = apps.filter(a => (f === 'All' || a.stage === f) && (a.role + ' ' + a.company).toLowerCase().includes(q.trim().toLowerCase()));
  const sent = apps.filter(a => a.stage !== 'To send').length;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1040,
      margin: '0 auto',
      display: 'grid',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      gap: 12,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(OnbTitle, {
    title: "Applications"
  }, apps.length ? `${sent} sent so far — counted when you mark an application as sent.` : 'Each job you add gets a record here.'), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    icon: "scan-search",
    onClick: () => go('linkedin')
  }, "LinkedIn check"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: "plus",
    onClick: () => go('addjob')
  }, "Add a job"))), !apps.length ? /*#__PURE__*/React.createElement(EmptyState, {
    icon: "briefcase",
    title: "No applications yet",
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      iconRight: "arrow-right",
      onClick: () => go('addjob')
    }, "Add a job")
  }, "Add a job you\u2019re applying for. We\u2019ll keep its CV, contact and next step together.") : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      flexWrap: 'wrap',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1 1 260px'
    }
  }, /*#__PURE__*/React.createElement(Field, {
    icon: "search",
    value: q,
    onChange: setQ,
    placeholder: "Search role or company"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      overflowX: 'auto',
      maxWidth: '100%'
    }
  }, /*#__PURE__*/React.createElement(Segmented, {
    size: "sm",
    value: f,
    onChange: setF,
    options: ['All', 'To send', 'Sent', 'Interview', 'Closed']
  }))), !list.length ? /*#__PURE__*/React.createElement(EmptyState, {
    icon: "search-x",
    title: `No applications match “${q}”`,
    actions: /*#__PURE__*/React.createElement(Button, {
      onClick: () => {
        setQ('');
        setF('All');
      }
    }, "Clear search")
  }, "Try a company name or part of the role.") : /*#__PURE__*/React.createElement(Card, {
    padding: "none"
  }, list.map((a, i) => /*#__PURE__*/React.createElement("button", {
    key: a.id,
    onClick: () => go('application', a.id === 'a1' ? 'To send' : 'Sent'),
    style: {
      width: '100%',
      display: 'flex',
      gap: 16,
      alignItems: 'center',
      flexWrap: 'wrap',
      padding: '16px 20px',
      border: 0,
      borderTop: i ? '1px solid var(--border-subtle)' : 0,
      background: 'transparent',
      textAlign: 'left',
      cursor: 'pointer',
      font: 'inherit'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1 1 240px',
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 650,
      color: 'var(--text-strong)'
    }
  }, a.role), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.84rem',
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, a.company)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      flexWrap: 'wrap',
      flex: '0 1 auto'
    }
  }, /*#__PURE__*/React.createElement(Pill, {
    size: "sm",
    tone: RZ_STAGE_TONE[a.stage]
  }, a.stage), /*#__PURE__*/React.createElement(Pill, {
    size: "sm",
    icon: a.tailored ? 'git-branch' : 'file'
  }, a.cv)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1 1 200px',
      fontSize: '.84rem',
      color: 'var(--text-body)'
    }
  }, a.next, a.date && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, " \xB7 ", a.date)), /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-right",
    size: 18,
    color: "var(--text-muted)"
  }))))));
}
function ApplicationScreen({
  state,
  go,
  flash,
  rtw
}) {
  const {
    Card,
    Button,
    Field,
    Select,
    Pill,
    Alert,
    Dialog,
    Checkbox,
    Icon
  } = ONB_DS;
  const sentInit = state === 'Sent';
  const [stage, setStage] = React.useState(sentInit ? 'Sent' : 'To send');
  const [cv, setCv] = React.useState(sentInit ? 'tailored' : null);
  const [snap, setSnap] = React.useState(sentInit ? '25 Oct 2026' : null);
  const [ask, setAsk] = React.useState(false);
  const [att, setAtt] = React.useState(false);
  const cvLabel = cv === 'tailored' ? 'Tailored CV v1 · Clar · English' : 'Base CV v3 · Clar · English';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1040,
      margin: '0 auto',
      display: 'grid',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    icon: "arrow-left",
    onClick: () => go('applications')
  }, "Applications")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      gap: 16,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(OnbTitle, {
    eyebrow: "Northstar People \xB7 Bucharest \xB7 hybrid",
    title: "Business Systems Analyst \u2014 Automation"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 200
    }
  }, /*#__PURE__*/React.createElement(Select, {
    label: "Stage",
    value: stage,
    onChange: setStage,
    options: ['To send', 'Sent', 'Interview', 'Offer', 'Closed']
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,320px),1fr))',
      gap: 20,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 16,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-section-title)',
      color: 'var(--text-strong)'
    }
  }, "CV for this job"), cv ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'center',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(OnbIconTile, {
    icon: "file-text",
    size: 44
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 180
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 650,
      color: 'var(--text-strong)'
    }
  }, cvLabel), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 6
    }
  }, /*#__PURE__*/React.createElement(Pill, {
    size: "sm",
    tone: cv === 'tailored' ? 'good' : 'neutral',
    icon: cv === 'tailored' ? 'git-branch' : 'file'
  }, cv === 'tailored' ? 'Tailored for this job' : 'Not tailored'))), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    icon: "eye",
    onClick: () => go('preview')
  }, "Preview")) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.88rem',
      color: 'var(--text-muted)',
      lineHeight: 1.5
    }
  }, "Not tailored yet. See how you match and get a version for this job \u2014 about 2 minutes."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    iconRight: "arrow-right",
    onClick: () => go('requirements')
  }, "Tailor my CV"), /*#__PURE__*/React.createElement(Button, {
    onClick: () => setCv('base')
  }, "Attach Base CV v3 as is"))))), !rtw && /*#__PURE__*/React.createElement(Alert, {
    tone: "warn",
    title: "Right to work in Romania still needs an answer",
    action: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      onClick: () => go('match')
    }, "Answer")
  }, "The job requires it. It doesn\u2019t change your score."), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-section-title)',
      color: 'var(--text-strong)'
    }
  }, "Sent"), snap ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'center',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "send",
    size: 18,
    color: "var(--pine-600)"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 180
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 650,
      color: 'var(--text-strong)'
    }
  }, "Sent ", snap), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.82rem',
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, cvLabel, " \u2014 copy kept exactly as sent")), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "ghost",
    icon: "eye"
  }, "View sent copy")) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 8,
      justifyItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: cv ? 'primary' : 'secondary',
    icon: "send",
    disabled: !cv,
    onClick: () => setAsk(true)
  }, "I\u2019ve sent this application"), !cv && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.8rem',
      color: 'var(--text-muted)'
    }
  }, "Attach a CV first, so we can keep a copy of what you sent."))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-section-title)',
      color: 'var(--text-strong)'
    }
  }, "Contact"), /*#__PURE__*/React.createElement(Field, {
    size: "sm",
    label: "Name",
    icon: "user",
    defaultValue: "Ana Pop",
    optional: true
  }), /*#__PURE__*/React.createElement(Field, {
    size: "sm",
    label: "Email",
    icon: "mail",
    type: "email",
    defaultValue: "ana.pop@northstar.example",
    optional: true
  }))), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-section-title)',
      color: 'var(--text-strong)'
    }
  }, "Next step"), /*#__PURE__*/React.createElement(Field, {
    size: "sm",
    label: "What\u2019s next",
    defaultValue: snap ? 'Follow up with Ana' : 'Tailor CV and send'
  }), /*#__PURE__*/React.createElement(Field, {
    size: "sm",
    label: "By",
    icon: "calendar",
    defaultValue: snap ? '30.10.2026' : '27.10.2026',
    hint: "dd.mm.yyyy"
  }), /*#__PURE__*/React.createElement(Field, {
    size: "sm",
    label: "Notes",
    multiline: true,
    rows: 3,
    optional: true,
    placeholder: "Anything to remember"
  }))))), ask && /*#__PURE__*/React.createElement(Dialog, {
    title: "Mark as sent?",
    onClose: () => setAsk(false),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      onClick: () => setAsk(false)
    }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: "send",
      disabled: !att,
      onClick: () => {
        setSnap('25 Oct 2026');
        setStage('Sent');
        setAsk(false);
        flash('Marked as sent · copy kept');
      }
    }, "Mark as sent"))
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 14px',
      color: 'var(--text-muted)',
      lineHeight: 1.55
    }
  }, "We\u2019ll keep a copy of ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-strong)',
      fontWeight: 650
    }
  }, cvLabel), " exactly as it is now, so you can always see what Northstar People received."), /*#__PURE__*/React.createElement(Checkbox, {
    checked: att,
    onChange: setAtt,
    label: "I sent this CV to Northstar People"
  })));
}
function LinkedInScreen({
  state,
  go
}) {
  const {
    Card,
    Button,
    Field,
    Alert,
    Pill
  } = ONB_DS;
  const [txt, setTxt] = React.useState(state === 'Compared' ? RZ_APP.linkedin : '');
  const [done, setDone] = React.useState(state === 'Compared');
  const L = RZ_APP.li;
  const ok = txt.trim().length >= 20;
  const Group = ({
    title,
    tone,
    list,
    note,
    action
  }) => /*#__PURE__*/React.createElement(Card, {
    padding: "sm"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      fontWeight: 650,
      color: 'var(--text-strong)'
    }
  }, title), /*#__PURE__*/React.createElement(Pill, {
    size: "sm",
    shape: "round"
  }, list.length)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 6
    }
  }, list.map(s => /*#__PURE__*/React.createElement(Pill, {
    key: s,
    tone: tone,
    shape: "round"
  }, s))), note && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.82rem',
      color: 'var(--text-muted)',
      lineHeight: 1.5
    }
  }, note), action));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1040,
      margin: '0 auto',
      display: 'grid',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(OnbTitle, {
    title: "Check your LinkedIn against your CV"
  }, "Paste the text from your profile. We\u2019ll show what matches and what differs \u2014 nothing changes on either side."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,360px),1fr))',
      gap: 24,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Text from your LinkedIn profile",
    multiline: true,
    rows: 8,
    value: txt,
    onChange: v => {
      setTxt(v);
      setDone(false);
    },
    hint: "Headline, About and Skills. At least 20 characters.",
    error: txt && !ok ? 'Paste a bit more — at least 20 characters.' : undefined
  }), !txt && /*#__PURE__*/React.createElement("button", {
    onClick: () => setTxt(RZ_APP.linkedin),
    style: {
      justifySelf: 'start',
      background: 'none',
      border: 0,
      padding: 0,
      font: '600 .82rem var(--font-sans)',
      color: 'var(--pine-600)',
      cursor: 'pointer'
    }
  }, "Use example text"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: "git-compare",
    disabled: !ok,
    onClick: () => setDone(true)
  }, "Compare with my Base CV")))), /*#__PURE__*/React.createElement(Alert, {
    tone: "neutral",
    icon: "lock"
  }, "We only read what you paste. We don\u2019t connect to LinkedIn or change anything there.")), done ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Group, {
    title: "In both",
    tone: "good",
    list: L.both
  }), /*#__PURE__*/React.createElement(Group, {
    title: "Only on LinkedIn",
    tone: "info",
    list: L.onlyLi,
    note: "Not added to your Base CV. If they\u2019re true, add them yourself \u2014 or answer a question about them.",
    action: /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      iconRight: "arrow-right",
      onClick: () => go('base')
    }, "Open Base CV"))
  }), /*#__PURE__*/React.createElement(Group, {
    title: "Only in your Base CV",
    tone: "neutral",
    list: L.onlyCv,
    note: "Consider adding these to your LinkedIn profile."
  })) : /*#__PURE__*/React.createElement(Card, {
    tone: "sunken"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.88rem',
      color: 'var(--text-muted)',
      lineHeight: 1.6,
      padding: '8px 4px'
    }
  }, "Results appear here: skills in both, only on LinkedIn, and only in your CV."))));
}
Object.assign(window, {
  ApplicationsScreen,
  ApplicationScreen,
  LinkedInScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/ScrApps.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/ScrBase.jsx
try { (() => {
const RZ_M = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const rzDate = d => d.y ? d.m ? RZ_M[+d.m - 1] + ' ' + d.y : d.y : '—';
function rzDur(r) {
  const asOf = 2026 * 12 + 10,
    s = r.start,
    e = r.end;
  if (!s.y || !r.current && !e.y) return null;
  const sE = +s.y * 12 + (s.m ? +s.m : 1),
    sL = +s.y * 12 + (s.m ? +s.m : 12);
  const eE = r.current ? asOf : +e.y * 12 + (e.m ? +e.m : 1),
    eL = r.current ? asOf : +e.y * 12 + (e.m ? +e.m : 12);
  const lo = Math.max(0, eE - sL),
    hi = Math.max(0, eL - sE);
  const f = m => [Math.floor(m / 12) ? Math.floor(m / 12) + ' yr' : '', m % 12 ? m % 12 + ' mo' : ''].filter(Boolean).join(' ') || '0 mo';
  return lo === hi ? f(lo) : f(lo) + ' – ' + f(hi);
}
function rzSections(d) {
  return d.sections.filter(s => s.on).map(s => {
    if (s.k === 'summary') return {
      title: s.label,
      text: d.summary
    };
    if (s.k === 'experience') return {
      title: s.label,
      items: d.roles.map(r => ({
        heading: r.title + ' — ' + r.company,
        dates: rzDate(r.start) + ' — ' + (r.current ? 'Present' : rzDate(r.end)),
        sub: r.city,
        bullets: r.bullets.filter(b => b.trim())
      }))
    };
    if (s.k === 'skills') return {
      title: s.label,
      text: d.pro.join(' · ') + ' — ' + d.tech.join(' · ')
    };
    if (s.k === 'education') return {
      title: s.label,
      text: d.edu
    };
    return {
      title: s.label,
      text: d.langs
    };
  });
}
function RzAcc({
  title,
  meta,
  open,
  onToggle,
  children
}) {
  const {
    Card,
    Icon
  } = ONB_DS;
  return /*#__PURE__*/React.createElement(Card, {
    padding: "none"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onToggle,
    style: {
      width: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 12,
      padding: '16px 20px',
      background: 'none',
      border: 0,
      cursor: 'pointer',
      textAlign: 'left',
      font: 'inherit'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-section-title)',
      color: 'var(--text-strong)',
      whiteSpace: 'nowrap'
    }
  }, title), meta || null), /*#__PURE__*/React.createElement(Icon, {
    name: open ? 'chevron-up' : 'chevron-down',
    size: 18,
    color: "var(--text-muted)"
  })), open && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 20px 20px',
      display: 'grid',
      gap: 16
    }
  }, children));
}
function RzSkillGroup({
  label,
  list,
  onAdd,
  onRemove
}) {
  const {
    Pill,
    Field,
    Button
  } = ONB_DS;
  const [v, setV] = React.useState('');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-label)',
      color: 'var(--text-strong)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 6
    }
  }, list.map((s, i) => /*#__PURE__*/React.createElement("button", {
    key: s,
    onClick: () => onRemove(i),
    title: "Remove",
    style: {
      background: 'none',
      border: 0,
      padding: 0,
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(Pill, {
    shape: "round",
    icon: "x"
  }, s)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      alignItems: 'end'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement(Field, {
    size: "sm",
    value: v,
    onChange: setV,
    placeholder: 'Add a ' + label.toLowerCase().replace(' skills', '') + ' skill'
  })), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    icon: "plus",
    disabled: !v.trim(),
    onClick: () => {
      onAdd(v.trim());
      setV('');
    }
  }, "Add")));
}
function BaseScreen({
  state,
  go,
  flash
}) {
  const {
    Button,
    Field,
    Select,
    Checkbox,
    Pill,
    CVDocument,
    Segmented,
    Alert,
    Icon,
    IconButton,
    Card
  } = ONB_DS;
  const clone = x => JSON.parse(JSON.stringify(x));
  const [d, setD] = React.useState(() => {
    const x = clone(RZ_APP.base);
    if (state === 'Unsaved draft' || state === 'Save conflict') x.summary = 'Business systems analyst with 6 years in HR operations and process automation.';
    return x;
  });
  const [past, setPast] = React.useState(state === 'Unsaved draft' || state === 'Save conflict' ? [clone(RZ_APP.base)] : []);
  const [tab, setTab] = React.useState(state === 'Review' ? 'review' : 'edit');
  const [open, setOpen] = React.useState(state === 'Unsaved draft' ? 'summary' : 'exp');
  const [ver, setVer] = React.useState(3);
  const [err, setErr] = React.useState(false);
  const [conflict, setConflict] = React.useState(state === 'Save conflict');
  const dirty = past.length > 0;
  const up = fn => {
    setPast(p => [...p, d]);
    setD(x => {
      const n = clone(x);
      fn(n);
      return n;
    });
    setErr(false);
  };
  const undo = () => {
    setD(past[past.length - 1]);
    setPast(p => p.slice(0, -1));
  };
  const save = () => {
    if (d.roles.some(r => r.bullets.some(b => !b.trim()))) {
      setErr(true);
      return;
    }
    setVer(v => v + 1);
    setPast([]);
    flash('Saved — Base CV v' + (ver + 1));
  };
  const tog = k => setOpen(o => o === k ? null : k);
  const monthOpts = [{
    value: 'u',
    label: 'Month unknown'
  }].concat(RZ_M.map((m, i) => ({
    value: String(i + 1),
    label: m
  })));
  const checks = [['Content', 'circle-check', 'good', 'Every role has context and 2–3 bullets.', null], ['Structure & format', 'circle-check', 'good', 'Standard headings, one column, readable dates.', null], ['Job optimization', 'info', 'info', 'Add a job to see which facts to bring forward for it.', ['Add a job', () => go('addjob')]], ['Writing quality', 'circle-alert', 'warn', '2 bullets start with “Responsible for”. Lead with what you did and what changed.', ['Answer 2 questions', () => go('enrich')]], ['Application readiness', 'circle-alert', 'warn', 'No phone number. Most recruiters in Romania call first.', ['Add a phone number', () => {
    setTab('edit');
    setOpen('about');
  }]]];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1240,
      margin: '0 auto',
      display: 'grid',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      gap: 16,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      font: '700 2rem/1.15 var(--font-display)',
      letterSpacing: '-0.04em',
      color: 'var(--text-strong)'
    }
  }, "Base CV"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginTop: 10,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Pill, {
    tone: "good",
    icon: "shield-check"
  }, "Confirmed by you"), /*#__PURE__*/React.createElement(Pill, null, "v", ver, " \xB7 saved 23 Oct"), dirty && /*#__PURE__*/React.createElement(Pill, {
    tone: "warn",
    icon: "pencil"
  }, "Unsaved changes"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    icon: "history",
    onClick: () => go('history')
  }, "History"), /*#__PURE__*/React.createElement(Button, {
    icon: "sparkles",
    onClick: () => go('enrich')
  }, "Improve with questions"))), /*#__PURE__*/React.createElement(Segmented, {
    value: tab,
    onChange: setTab,
    options: [{
      value: 'edit',
      label: 'Edit',
      icon: 'pencil'
    }, {
      value: 'review',
      label: 'Review',
      icon: 'list-checks'
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,440px),1fr))',
      gap: 28,
      alignItems: 'start'
    }
  }, tab === 'review' ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: 'var(--text-muted)',
      lineHeight: 1.6
    }
  }, "Five checks on your Base CV. They\u2019re not a score \u2014 each one is a next step."), checks.map(([t, ic, tone, txt, act]) => /*#__PURE__*/React.createElement(Card, {
    key: t,
    padding: "sm"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(OnbIconTile, {
    icon: ic,
    tone: tone,
    size: 40
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 650,
      color: 'var(--text-strong)'
    }
  }, t), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.86rem',
      color: 'var(--text-muted)',
      marginTop: 3,
      lineHeight: 1.5
    }
  }, txt), act && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    iconRight: "arrow-right",
    onClick: act[1]
  }, act[0]))))))) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12,
      minWidth: 0
    }
  }, conflict && /*#__PURE__*/React.createElement(Alert, {
    tone: "bad",
    title: "Your Base CV changed somewhere else",
    action: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "primary",
      onClick: () => {
        setConflict(false);
        setVer(4);
      }
    }, "Keep mine as a new version")
  }, "Another tab saved v4 while you were editing. Your changes are still here \u2014 nothing was overwritten."), /*#__PURE__*/React.createElement(RzAcc, {
    title: "About you",
    open: open === 'about',
    onToggle: () => tog('about'),
    meta: !d.phone && /*#__PURE__*/React.createElement(Pill, {
      size: "sm",
      tone: "warn"
    }, "No phone")
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,200px),1fr))',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Full name",
    value: d.name,
    onChange: v => up(n => {
      n.name = v;
    }),
    error: !d.name.trim() ? 'Add your name.' : undefined
  }), /*#__PURE__*/React.createElement(Field, {
    label: "City",
    optional: true,
    value: d.city,
    onChange: v => up(n => {
      n.city = v;
    })
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Title",
    value: d.t1,
    onChange: v => up(n => {
      n.t1 = v;
    }),
    hint: "Under your name. Not a past job title."
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Second title",
    optional: true,
    value: d.t2,
    onChange: v => up(n => {
      n.t2 = v;
    }),
    hint: "Leave empty if you don\u2019t need one."
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Email",
    type: "email",
    value: d.email,
    onChange: v => up(n => {
      n.email = v;
    })
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Phone",
    type: "tel",
    optional: true,
    value: d.phone,
    onChange: v => up(n => {
      n.phone = v;
    }),
    placeholder: "+40 7xx xxx xxx"
  }))), /*#__PURE__*/React.createElement(RzAcc, {
    title: "Summary",
    open: open === 'summary',
    onToggle: () => tog('summary')
  }, /*#__PURE__*/React.createElement(Field, {
    multiline: true,
    rows: 3,
    maxLength: 400,
    value: d.summary,
    onChange: v => up(n => {
      n.summary = v;
    }),
    hint: "2\u20133 sentences: years of experience, what you\u2019re best at, a result."
  })), /*#__PURE__*/React.createElement(RzAcc, {
    title: "Skills",
    open: open === 'skills',
    onToggle: () => tog('skills'),
    meta: /*#__PURE__*/React.createElement(Pill, {
      size: "sm"
    }, d.pro.length + d.tech.length)
  }, /*#__PURE__*/React.createElement(RzSkillGroup, {
    label: "Professional skills",
    list: d.pro,
    onAdd: s => up(n => {
      n.pro.push(s);
    }),
    onRemove: i => up(n => {
      n.pro.splice(i, 1);
    })
  }), /*#__PURE__*/React.createElement(RzSkillGroup, {
    label: "Technical skills",
    list: d.tech,
    onAdd: s => up(n => {
      n.tech.push(s);
    }),
    onRemove: i => up(n => {
      n.tech.splice(i, 1);
    })
  })), /*#__PURE__*/React.createElement(RzAcc, {
    title: "Experience",
    open: open === 'exp',
    onToggle: () => tog('exp'),
    meta: /*#__PURE__*/React.createElement(Pill, {
      size: "sm"
    }, d.roles.length, " roles")
  }, d.roles.map((r, i) => {
    const endErr = !r.current && r.end.y && r.start.y && +r.end.y < +r.start.y;
    return /*#__PURE__*/React.createElement("div", {
      key: r.id,
      style: {
        display: 'grid',
        gap: 14,
        padding: 16,
        border: '1px solid var(--border-subtle)',
        borderRadius: 12
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        gap: 8,
        flexWrap: 'wrap',
        alignItems: 'baseline'
      }
    }, /*#__PURE__*/React.createElement("b", {
      style: {
        fontWeight: 650,
        color: 'var(--text-strong)'
      }
    }, r.title, " \xB7 ", r.company), rzDur(r) && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: '.78rem',
        color: 'var(--text-muted)'
      }
    }, rzDur(r), " \xB7 as of Oct 2026")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,160px),1fr))',
        gap: 12
      }
    }, /*#__PURE__*/React.createElement(Field, {
      size: "sm",
      label: "Job title",
      value: r.title,
      onChange: v => up(n => {
        n.roles[i].title = v;
      })
    }), /*#__PURE__*/React.createElement(Field, {
      size: "sm",
      label: "Company",
      value: r.company,
      onChange: v => up(n => {
        n.roles[i].company = v;
      })
    }), /*#__PURE__*/React.createElement(Field, {
      size: "sm",
      label: "City",
      optional: true,
      value: r.city,
      onChange: v => up(n => {
        n.roles[i].city = v;
      })
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,130px),1fr))',
        gap: 12,
        alignItems: 'end'
      }
    }, /*#__PURE__*/React.createElement(Select, {
      size: "sm",
      label: "Start month",
      value: r.start.m || 'u',
      onChange: v => up(n => {
        n.roles[i].start.m = v === 'u' ? '' : v;
      }),
      options: monthOpts
    }), /*#__PURE__*/React.createElement(Field, {
      size: "sm",
      label: "Start year",
      type: "number",
      value: r.start.y,
      onChange: v => up(n => {
        n.roles[i].start.y = v;
      })
    }), !r.current && /*#__PURE__*/React.createElement(Select, {
      size: "sm",
      label: "End month",
      value: r.end.m || 'u',
      onChange: v => up(n => {
        n.roles[i].end.m = v === 'u' ? '' : v;
      }),
      options: monthOpts
    }), !r.current && /*#__PURE__*/React.createElement(Field, {
      size: "sm",
      label: "End year",
      type: "number",
      value: r.end.y,
      onChange: v => up(n => {
        n.roles[i].end.y = v;
      }),
      error: endErr ? 'Ends before it starts.' : undefined
    })), /*#__PURE__*/React.createElement(Checkbox, {
      checked: r.current,
      onChange: v => up(n => {
        n.roles[i].current = v;
      }),
      label: "I still work here"
    }), /*#__PURE__*/React.createElement(Field, {
      size: "sm",
      label: "Context",
      multiline: true,
      rows: 2,
      value: r.context,
      onChange: v => up(n => {
        n.roles[i].context = v;
      }),
      hint: "One sentence: team, scope or product."
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--type-label)',
        color: 'var(--text-strong)'
      }
    }, "Bullets"), r.bullets.map((b, k) => /*#__PURE__*/React.createElement("div", {
      key: k,
      style: {
        display: 'flex',
        gap: 6,
        alignItems: 'flex-start'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement(Field, {
      size: "sm",
      value: b,
      onChange: v => up(n => {
        n.roles[i].bullets[k] = v;
      }),
      placeholder: "What you did, and what changed",
      error: err && !b.trim() ? 'Write something or remove this bullet.' : undefined
    })), /*#__PURE__*/React.createElement(IconButton, {
      size: "sm",
      variant: "ghost",
      icon: "trash-2",
      label: "Remove bullet",
      onClick: () => up(n => {
        n.roles[i].bullets.splice(k, 1);
      })
    }))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "ghost",
      icon: "plus",
      onClick: () => up(n => {
        n.roles[i].bullets.push('');
      })
    }, "Add bullet"))));
  })), /*#__PURE__*/React.createElement(RzAcc, {
    title: "Education",
    open: open === 'edu',
    onToggle: () => tog('edu')
  }, /*#__PURE__*/React.createElement(Field, {
    multiline: true,
    rows: 2,
    value: d.edu,
    onChange: v => up(n => {
      n.edu = v;
    })
  })), /*#__PURE__*/React.createElement(RzAcc, {
    title: "Languages",
    open: open === 'lang',
    onToggle: () => tog('lang')
  }, /*#__PURE__*/React.createElement(Field, {
    value: d.langs,
    onChange: v => up(n => {
      n.langs = v;
    }),
    hint: "Add how you know the level \u2014 a certificate or daily use."
  })), /*#__PURE__*/React.createElement(RzAcc, {
    title: "Sections & order",
    open: open === 'order',
    onToggle: () => tog('order')
  }, d.sections.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: s.k,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    checked: s.on,
    onChange: v => up(n => {
      n.sections[i].on = v;
    }),
    label: s.label
  })), /*#__PURE__*/React.createElement(IconButton, {
    size: "sm",
    variant: "ghost",
    icon: "arrow-up",
    label: "Move up",
    disabled: i === 0,
    onClick: () => up(n => {
      const [x] = n.sections.splice(i, 1);
      n.sections.splice(i - 1, 0, x);
    })
  }), /*#__PURE__*/React.createElement(IconButton, {
    size: "sm",
    variant: "ghost",
    icon: "arrow-down",
    label: "Move down",
    disabled: i === d.sections.length - 1,
    onClick: () => up(n => {
      const [x] = n.sections.splice(i, 1);
      n.sections.splice(i + 1, 0, x);
    })
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.8rem',
      color: 'var(--text-muted)'
    }
  }, "Hiding a section only changes the document. Its content stays in your history.")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'sticky',
      bottom: 16,
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 12,
      flexWrap: 'wrap',
      background: '#fff',
      border: '1px solid var(--border-subtle)',
      borderRadius: 14,
      padding: '12px 16px',
      boxShadow: 'var(--shadow-toast)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '.84rem',
      color: 'var(--text-muted)',
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: dirty ? 'pencil' : 'circle-check',
    size: 16,
    color: dirty ? 'var(--status-warn-fg)' : 'var(--status-good-fg)'
  }), dirty ? 'Draft · saved on this device' : 'All changes saved'), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    icon: "undo-2",
    disabled: !dirty,
    onClick: undo
  }, "Undo"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: "save",
    disabled: !dirty || conflict,
    onClick: save
  }, "Save as v", ver + 1)))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'sticky',
      top: 20,
      display: 'grid',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-label)',
      color: 'var(--text-strong)'
    }
  }, "Preview"), /*#__PURE__*/React.createElement(CVDocument, {
    template: "clar",
    scale: .8,
    name: d.name,
    titles: [d.t1, d.t2].filter(Boolean),
    contact: [d.city, d.email, d.phone].filter(Boolean).join(' · '),
    sections: rzSections(d)
  }))));
}
function HistoryScreen({
  state,
  go,
  flash
}) {
  const {
    Button,
    Card,
    Pill,
    CVDocument,
    Dialog,
    EmptyState
  } = ONB_DS;
  const [list, setList] = React.useState(RZ_APP.versions);
  const [sel, setSel] = React.useState(list[0].v);
  const [ask, setAsk] = React.useState(null);
  if (state === 'No versions') return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 640,
      margin: '40px auto'
    }
  }, /*#__PURE__*/React.createElement(EmptyState, {
    icon: "history",
    title: "No saved versions yet",
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: "file-up",
      href: "onboarding.html#/import"
    }, "Bring your CV")
  }, "Each time you save your Base CV, we keep a copy here. You can look back at any of them, or restore one."));
  const cur = list.find(x => x.v === sel),
    head = list[0].v;
  const doc = Object.assign(JSON.parse(JSON.stringify(RZ_APP.base)), {
    summary: cur.summary
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: '0 auto',
      display: 'grid',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      gap: 12,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(OnbTitle, {
    title: "Version history"
  }, "Every save is kept. Restoring an old version adds it as a new one \u2014 nothing is lost."), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    icon: "arrow-left",
    onClick: () => go('base')
  }, "Back to Base CV")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,380px),1fr))',
      gap: 28,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "none"
  }, list.map((x, i) => /*#__PURE__*/React.createElement("div", {
    key: x.v,
    onClick: () => setSel(x.v),
    style: {
      display: 'flex',
      gap: 14,
      padding: '16px 20px',
      cursor: 'pointer',
      borderTop: i ? '1px solid var(--border-subtle)' : 0,
      background: sel === x.v ? 'var(--pine-50)' : 'transparent'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: '700 1rem var(--font-display)',
      color: 'var(--pine-700)',
      width: 34
    }
  }, "v", x.v), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      alignItems: 'center',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      fontWeight: 650,
      color: 'var(--text-strong)'
    }
  }, x.why), x.v === head && /*#__PURE__*/React.createElement(Pill, {
    size: "sm",
    tone: "good"
  }, "Current")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.84rem',
      color: 'var(--text-muted)',
      marginTop: 3,
      lineHeight: 1.5
    }
  }, x.detail), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.76rem',
      color: 'var(--text-muted)',
      marginTop: 6
    }
  }, x.date)), x.v !== head && /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    icon: "rotate-ccw",
    onClick: e => {
      e.stopPropagation();
      setAsk(x);
    }
  }, "Restore")))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'sticky',
      top: 20,
      display: 'grid',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-label)',
      color: 'var(--text-strong)'
    }
  }, "v", cur.v, " \xB7 ", cur.date), /*#__PURE__*/React.createElement(CVDocument, {
    template: "clar",
    scale: .78,
    name: doc.name,
    titles: [doc.t1],
    contact: [doc.city, doc.email].join(' · '),
    sections: rzSections(doc)
  }))), ask && /*#__PURE__*/React.createElement(Dialog, {
    title: 'Restore v' + ask.v + '?',
    onClose: () => setAsk(null),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      onClick: () => setAsk(null)
    }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      onClick: () => {
        const nv = head + 1;
        setList(l => [{
          v: nv,
          date: '25 Oct 2026, now',
          why: 'Restored v' + ask.v,
          detail: 'Copy of v' + ask.v + '. v' + head + ' is still in history.',
          summary: ask.summary
        }, ...l]);
        setSel(nv);
        setAsk(null);
        flash('Restored — saved as v' + nv);
      }
    }, "Restore as v", head + 1))
  }, "We\u2019ll save a copy of v", ask.v, " as v", head + 1, ". Your current v", head, " stays in history, so you can switch back anytime."));
}
Object.assign(window, {
  RZ_M,
  rzDate,
  rzDur,
  rzSections,
  RzAcc,
  BaseScreen,
  HistoryScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/ScrBase.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/ScrEditor.jsx
try { (() => {
function JobEditorScreen({
  go,
  flash
}) {
  const {
    Card,
    Button,
    Field,
    Checkbox,
    Alert,
    Pill,
    IconButton,
    CVDocument,
    Dialog
  } = ONB_DS;
  const C = window.CVZ_DATA.changes;
  const [sum, setSum] = React.useState(C[0].after);
  const [bw, setBw] = React.useState([{
    t: C[1].after,
    on: true
  }, {
    t: 'Mapped approval workflows with stakeholders across finance and HR.',
    on: true
  }, {
    t: 'Wrote SQL reports used in monthly payroll reconciliation.',
    on: true
  }, {
    t: C[2].after,
    on: true
  }]);
  const [cr, setCr] = React.useState([{
    t: 'Coordinated onboarding for 40+ hires per quarter.',
    on: true
  }, {
    t: 'Built monthly headcount and turnover reports for store managers.',
    on: false
  }]);
  const [sk, setSk] = React.useState([['Process automation', true], ['SQL', true], ['REST APIs', true], ['Requirements analysis', true], ['Gestionarea părților interesate', true], ['Excel', false]]);
  const [dirty, setDirty] = React.useState(false);
  const [ver, setVer] = React.useState(1);
  const [promo, setPromo] = React.useState(false);
  const [pick, setPick] = React.useState({
    sum: true,
    out: true
  });
  const ch = f => (...a) => {
    f(...a);
    setDirty(true);
  };
  const move = (set, i, d) => set(x => {
    const n = [...x];
    const [y] = n.splice(i, 1);
    n.splice(i + d, 0, y);
    return n;
  });
  const Bullets = ({
    list,
    set
  }) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 8
    }
  }, list.map((b, i) => /*#__PURE__*/React.createElement("div", {
    key: b.t,
    style: {
      display: 'flex',
      gap: 6,
      alignItems: 'flex-start',
      padding: '10px 12px',
      borderRadius: 10,
      border: '1px solid var(--border-subtle)',
      background: b.on ? '#fff' : 'var(--sage-50)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      opacity: b.on ? 1 : .6
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    checked: b.on,
    onChange: ch(v => set(x => x.map((y, k) => k === i ? {
      ...y,
      on: v
    } : y))),
    label: b.t
  })), /*#__PURE__*/React.createElement(IconButton, {
    size: "sm",
    variant: "ghost",
    icon: "arrow-up",
    label: "Move up",
    disabled: i === 0,
    onClick: ch(() => move(set, i, -1))
  }), /*#__PURE__*/React.createElement(IconButton, {
    size: "sm",
    variant: "ghost",
    icon: "arrow-down",
    label: "Move down",
    disabled: i === list.length - 1,
    onClick: ch(() => move(set, i, 1))
  }))));
  const sections = [{
    title: 'Summary',
    text: sum
  }, {
    title: 'Experience',
    items: [{
      heading: 'Systems Analyst — BridgeWorks',
      dates: '2021 — Present',
      sub: 'Cluj-Napoca',
      bullets: bw.filter(b => b.on).map(b => b.t)
    }, {
      heading: 'HR Operations Specialist — Carpatia Retail',
      dates: 'Mar 2019 — 2021',
      sub: 'Cluj-Napoca',
      bullets: cr.filter(b => b.on).map(b => b.t)
    }]
  }, {
    title: 'Skills',
    text: sk.filter(s => s[1]).map(s => s[0]).join(' · ')
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1240,
      margin: '0 auto',
      display: 'grid',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      gap: 16,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      font: '700 2rem/1.15 var(--font-display)',
      letterSpacing: '-0.04em',
      color: 'var(--text-strong)'
    }
  }, "Edit the Northstar People CV"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginTop: 10,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Pill, {
    icon: "git-branch"
  }, "From Base CV v3"), /*#__PURE__*/React.createElement(Pill, null, "Job CV v", ver), dirty && /*#__PURE__*/React.createElement(Pill, {
    tone: "warn",
    icon: "pencil"
  }, "Unsaved changes"))), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    icon: "arrow-left",
    onClick: () => go('compare')
  }, "Back to suggestions")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,440px),1fr))',
      gap: 28,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 14,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(Alert, {
    tone: "info",
    icon: "git-branch"
  }, "Changes here stay in this job\u2019s CV. Your Base CV doesn\u2019t change."), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-section-title)',
      color: 'var(--text-strong)'
    }
  }, "Summary"), /*#__PURE__*/React.createElement(Field, {
    multiline: true,
    rows: 3,
    maxLength: 400,
    value: sum,
    onChange: ch(setSum)
  }))), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-section-title)',
      color: 'var(--text-strong)'
    }
  }, "BridgeWorks \xB7 Systems Analyst"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.8rem',
      color: 'var(--text-muted)'
    }
  }, "Untick to hide a bullet from this CV. Order it so the most relevant comes first."), /*#__PURE__*/React.createElement(Bullets, {
    list: bw,
    set: setBw
  }))), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-section-title)',
      color: 'var(--text-strong)'
    }
  }, "Carpatia Retail \xB7 HR Operations"), /*#__PURE__*/React.createElement(Bullets, {
    list: cr,
    set: setCr
  }))), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-section-title)',
      color: 'var(--text-strong)'
    }
  }, "Skills in this CV"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 6
    }
  }, sk.map(([t, on], i) => /*#__PURE__*/React.createElement("button", {
    key: t,
    onClick: ch(() => setSk(x => x.map((y, k) => k === i ? [y[0], !y[1]] : y))),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: '6px 12px',
      borderRadius: 999,
      cursor: 'pointer',
      font: '600 .8rem var(--font-sans)',
      border: '1px solid ' + (on ? 'var(--pine-600)' : 'var(--border-subtle)'),
      background: on ? 'var(--pine-50)' : '#fff',
      color: on ? 'var(--pine-700)' : 'var(--text-muted)'
    }
  }, on ? '✓' : '+', " ", t))))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'sticky',
      bottom: 16,
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 10,
      flexWrap: 'wrap',
      background: '#fff',
      border: '1px solid var(--border-subtle)',
      borderRadius: 14,
      padding: '12px 16px',
      boxShadow: 'var(--shadow-toast)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    icon: "upload",
    onClick: () => setPromo(true)
  }, "Also add to Base CV\u2026"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Button, {
    icon: "save",
    disabled: !dirty,
    onClick: () => {
      setVer(v => v + 1);
      setDirty(false);
      flash('Saved — Job CV v' + (ver + 1) + ' · Base CV unchanged');
    }
  }, "Save as job CV v", ver + 1), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    iconRight: "arrow-right",
    disabled: dirty,
    onClick: () => go('preview')
  }, "Preview")))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'sticky',
      top: 20
    }
  }, /*#__PURE__*/React.createElement(CVDocument, {
    template: "clar",
    scale: .8,
    name: "Mara Ionescu",
    titles: ['Business Systems Analyst'],
    contact: "Cluj-Napoca \xB7 mara.ionescu@example.ro",
    sections: sections
  }))), promo && /*#__PURE__*/React.createElement(Dialog, {
    title: "Add to your Base CV?",
    onClose: () => setPromo(false),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      onClick: () => setPromo(false)
    }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      disabled: !pick.sum && !pick.out,
      onClick: () => {
        setPromo(false);
        flash('Saved — Base CV v4');
      }
    }, "Save to Base as v4"))
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 14px',
      color: 'var(--text-muted)',
      lineHeight: 1.55
    }
  }, "Choose what every future job should start with. We\u2019ll save Base CV v4 \u2014 v3 stays in history."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    variant: "card",
    checked: pick.sum,
    onChange: v => setPick(p => ({
      ...p,
      sum: v
    })),
    label: "New summary",
    description: sum
  }), /*#__PURE__*/React.createElement(Checkbox, {
    variant: "card",
    checked: pick.out,
    onChange: v => setPick(p => ({
      ...p,
      out: v
    })),
    label: "Outcome bullet at BridgeWorks",
    description: C[2].after
  }))));
}
function PreviewScreen({
  state,
  go,
  flash,
  rtw
}) {
  const {
    Card,
    Button,
    Select,
    Checkbox,
    Alert,
    Spinner,
    Pill,
    CVDocument,
    Icon
  } = ONB_DS;
  const [tpl, setTpl] = React.useState('clar');
  const [lang, setLang] = React.useState('en');
  const [show, setShow] = React.useState({
    city: true,
    email: true,
    phone: true
  });
  const [ack, setAck] = React.useState(false);
  const [st, setSt] = React.useState('idle');
  const [tries, setTries] = React.useState(0);
  const dl = () => {
    if (state === 'No plan') {
      setSt('plan');
      return;
    }
    setSt('busy');
    const t = tries;
    setTries(t + 1);
    setTimeout(() => setSt(state === 'Export failed' && t === 0 ? 'failed' : 'done'), 1300);
  };
  const contact = [show.city && 'Cluj-Napoca', show.email && 'mara.ionescu@example.ro', show.phone && '+40 7xx xxx xxx'].filter(Boolean).join(' · ');
  const T = ({
    v,
    name,
    desc
  }) => /*#__PURE__*/React.createElement(Card, {
    padding: "sm",
    interactive: true,
    selected: tpl === v,
    onClick: () => setTpl(v)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 38,
      height: 50,
      borderRadius: 3,
      background: '#fff',
      border: '1px solid var(--border-subtle)',
      boxShadow: 'var(--shadow-paper)',
      display: 'grid',
      alignContent: 'start',
      gap: 3,
      padding: 5,
      boxSizing: 'border-box',
      flex: 'none'
    }
  }, v === 'contur' && /*#__PURE__*/React.createElement("div", {
    style: {
      height: 7,
      background: 'var(--pine-600)',
      margin: '-5px -5px 2px'
    }
  }), [90, 60, 100, 80, 95].map((w, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      height: 2,
      width: w + '%',
      background: 'var(--sage-300)'
    }
  }))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 650,
      color: 'var(--text-strong)',
      fontFamily: v === 'clar' ? 'var(--font-document)' : 'var(--font-sans)'
    }
  }, name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.78rem',
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, desc))));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,340px),1fr))',
      gap: 24,
      alignItems: 'start',
      maxWidth: 1180,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 16,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(OnbTitle, {
    title: "Choose how it looks"
  }, "Same facts in every template. Check it, then download."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(T, {
    v: "clar",
    name: "Clar",
    desc: "Serif, editorial, generous spacing"
  }), /*#__PURE__*/React.createElement(T, {
    v: "contur",
    name: "Contur",
    desc: "Sans, pine accent band, compact"
  })), /*#__PURE__*/React.createElement(Select, {
    label: "CV language",
    icon: "languages",
    value: lang,
    onChange: setLang,
    options: [{
      value: 'en',
      label: 'English'
    }, {
      value: 'ro',
      label: 'Română'
    }],
    hint: lang === 'ro' ? 'We translate text we know. Check anything you wrote yourself.' : 'Separate from the app language.'
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-label)',
      color: 'var(--text-strong)'
    }
  }, "Contact details on this CV"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 16,
      flexWrap: 'wrap'
    }
  }, [['city', 'City'], ['email', 'Email'], ['phone', 'Phone']].map(([k, l]) => /*#__PURE__*/React.createElement(Checkbox, {
    key: k,
    checked: show[k],
    onChange: v => setShow(s => ({
      ...s,
      [k]: v
    })),
    label: l
  })))), !rtw && /*#__PURE__*/React.createElement(Alert, {
    tone: "warn",
    title: "Still to check"
  }, "Right to work in Romania \u2014 the job requires it. ", /*#__PURE__*/React.createElement("a", {
    href: "#/match",
    onClick: () => {}
  }, "Answer")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      fontSize: '.82rem',
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "scan-text",
    size: 16
  }), "PDF readability is checked on the real file when you download."), /*#__PURE__*/React.createElement(Card, {
    padding: "sm"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 14
    }
  }, st === 'plan' ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 650,
      color: 'var(--text-strong)'
    }
  }, "Downloading needs a plan"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.86rem',
      color: 'var(--text-muted)',
      lineHeight: 1.5
    }
  }, "Editing, your match and this preview stay free. Your CV is saved and waits here."), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    fullWidth: true,
    iconRight: "arrow-right",
    onClick: () => go('plans')
  }, "See plans")) : st === 'busy' ? /*#__PURE__*/React.createElement(Spinner, {
    size: 28,
    label: "Preparing your PDF and checking it reads correctly\u2026"
  }) : /*#__PURE__*/React.createElement(React.Fragment, null, st === 'failed' && /*#__PURE__*/React.createElement(Alert, {
    tone: "bad",
    title: "We couldn\u2019t prepare the PDF"
  }, "Your CV is saved \u2014 nothing was lost. Try again in a moment."), st === 'done' && /*#__PURE__*/React.createElement(Alert, {
    tone: "good",
    title: "Downloaded"
  }, "Job CV v1 \xB7 ", tpl === 'clar' ? 'Clar' : 'Contur', " \xB7 ", lang === 'en' ? 'English' : 'Română', ". Text, headings and dates read in the right order."), st !== 'done' && /*#__PURE__*/React.createElement(Checkbox, {
    checked: ack,
    onChange: setAck,
    label: "I\u2019ve read this CV and everything in it is true"
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    icon: st === 'failed' ? 'rotate-cw' : 'download',
    disabled: !ack,
    onClick: dl
  }, st === 'failed' ? 'Try again' : st === 'done' ? 'Download again' : 'Download PDF'), st === 'done' && /*#__PURE__*/React.createElement(Button, {
    fullWidth: true,
    icon: "send",
    onClick: () => go('application')
  }, "Record this application")))), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    icon: "file-json",
    onClick: () => flash('Exported — northstar-cv.json')
  }, "Export CV data (JSON)")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'sticky',
      top: 20,
      display: 'grid',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Pill, {
    size: "sm",
    icon: "git-branch"
  }, "Job CV v1 \xB7 from Base v3"), /*#__PURE__*/React.createElement(Pill, {
    size: "sm",
    icon: "languages"
  }, lang === 'en' ? 'English' : 'Română')), /*#__PURE__*/React.createElement(CVDocument, {
    template: tpl,
    scale: .9,
    name: "Mara Ionescu",
    titles: ['Business Systems Analyst'],
    contact: contact,
    sections: window.CVZ_cv(['sum', 'api', 'out'])
  })));
}
Object.assign(window, {
  JobEditorScreen,
  PreviewScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/ScrEditor.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/ScrEnrich.jsx
try { (() => {
function EnrichScreen({
  state,
  go,
  flash
}) {
  const {
    Card,
    Button,
    Field,
    Checkbox,
    RadioGroup,
    Pill,
    ProgressBar,
    EmptyState,
    Icon
  } = ONB_DS;
  const Q = RZ_APP.questions;
  const [cur, setCur] = React.useState(0);
  const [st, setSt] = React.useState({});
  const [ans, setAns] = React.useState({});
  const [step, setStep] = React.useState('ask');
  const [ok, setOk] = React.useState(false);
  const [dest, setDest] = React.useState('base');
  const [ver, setVer] = React.useState(3);
  if (state === 'Nothing to ask') return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 640,
      margin: '40px auto'
    }
  }, /*#__PURE__*/React.createElement(EmptyState, {
    icon: "circle-check",
    title: "Nothing to ask right now",
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      iconRight: "arrow-right",
      onClick: () => go('addjob')
    }, "Add a job")
  }, "Your Base CV covers every section. When a job needs something your CV doesn\u2019t say, we\u2019ll ask about it then."));
  const q = Q[cur],
    a = ans[q.id] || '';
  const answered = Object.values(st).filter(x => x === 'done').length,
    handled = Object.keys(st).length;
  const advance = (id, v) => {
    const nst = {
      ...st,
      [id]: v
    };
    setSt(nst);
    const n = Q.findIndex(x => !nst[x.id]);
    if (n >= 0) setCur(n);
    setStep('ask');
    setOk(false);
    setDest('base');
  };
  const after = q.after || a.trim();
  const allDone = handled === Q.length;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1080,
      margin: '0 auto',
      display: 'grid',
      gap: 22
    }
  }, /*#__PURE__*/React.createElement(OnbTitle, {
    title: "Improve your profile"
  }, "A few questions about things your CV doesn\u2019t say yet. Answer what you know \u2014 skip the rest. Nothing is added until you confirm it."), /*#__PURE__*/React.createElement(ProgressBar, {
    value: handled,
    max: Q.length,
    label: "Questions",
    valueLabel: `${answered} answered · ${handled - answered} skipped · ${Q.length - handled} left`
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 24,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "none",
    style: {
      flex: '1 1 260px',
      width: 'auto'
    }
  }, Q.map((x, i) => {
    const s = st[x.id];
    return /*#__PURE__*/React.createElement("button", {
      key: x.id,
      onClick: () => {
        setCur(i);
        setStep('ask');
        setOk(false);
      },
      style: {
        width: '100%',
        display: 'flex',
        gap: 12,
        alignItems: 'flex-start',
        padding: '14px 18px',
        border: 0,
        borderTop: i ? '1px solid var(--border-subtle)' : 0,
        background: i === cur && !allDone ? 'var(--pine-50)' : 'transparent',
        textAlign: 'left',
        cursor: 'pointer',
        font: 'inherit'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: s === 'done' ? 'circle-check' : s === 'skip' ? 'circle-minus' : 'circle',
      size: 18,
      color: s === 'done' ? 'var(--status-good-fg)' : 'var(--sage-400)'
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'block',
        fontSize: '.72rem',
        fontWeight: 700,
        letterSpacing: '.06em',
        textTransform: 'uppercase',
        color: 'var(--text-muted)'
      }
    }, x.section), /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'block',
        fontSize: '.88rem',
        color: 'var(--text-strong)',
        marginTop: 3,
        lineHeight: 1.45
      }
    }, x.q)));
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '2 1 480px',
      minWidth: 0
    }
  }, allDone ? /*#__PURE__*/React.createElement(Card, {
    padding: "lg"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 16,
      justifyItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(OnbIconTile, {
    icon: "circle-check"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      font: '700 1.5rem/1.2 var(--font-display)',
      letterSpacing: '-0.03em',
      color: 'var(--text-strong)'
    }
  }, "That\u2019s everything for now"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      lineHeight: 1.6
    }
  }, answered, " answers confirmed. ", handled - answered ? `${handled - answered} skipped — they added nothing to your CV.` : ''), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    iconRight: "arrow-right",
    onClick: () => go('base')
  }, "See my Base CV"), /*#__PURE__*/React.createElement(Button, {
    icon: "history",
    onClick: () => go('history')
  }, "Version history")))) : /*#__PURE__*/React.createElement(Card, {
    padding: "lg"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 10,
      flexWrap: 'wrap',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '750 .73rem var(--font-sans)',
      letterSpacing: '.14em',
      textTransform: 'uppercase',
      color: 'var(--text-accent)'
    }
  }, q.section), /*#__PURE__*/React.createElement(Pill, {
    size: "sm"
  }, step === 'ask' ? 'Step 1 of 2 · Answer' : 'Step 2 of 2 · Confirm')), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      font: '700 1.45rem/1.25 var(--font-display)',
      letterSpacing: '-0.03em',
      color: 'var(--text-strong)',
      textWrap: 'balance'
    }
  }, q.q), step === 'ask' ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Field, {
    multiline: true,
    rows: 4,
    value: a,
    onChange: v => setAns(s => ({
      ...s,
      [q.id]: v
    })),
    hint: q.help,
    placeholder: "In your own words\u2026"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 6
    }
  }, q.chips.map(c => /*#__PURE__*/React.createElement("button", {
    key: c,
    onClick: () => setAns(s => ({
      ...s,
      [q.id]: (a ? a.replace(/\s*$/, '') + (/[.!?]$/.test(a.trim()) ? ' ' : '. ') : '') + c
    })),
    style: {
      border: '1px solid var(--border-subtle)',
      background: '#fff',
      borderRadius: 999,
      padding: '6px 12px',
      font: '600 .8rem var(--font-sans)',
      color: 'var(--text-body)',
      cursor: 'pointer'
    }
  }, "+ ", c))), /*#__PURE__*/React.createElement(OnbActions, {
    back: /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: () => advance(q.id, 'skip')
    }, "I don\u2019t know \xB7 skip")
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    iconRight: "arrow-right",
    disabled: a.trim().length < 3,
    onClick: () => setStep('review')
  }, "Review"))) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-label)',
      color: 'var(--text-strong)'
    }
  }, "What you told us"), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 14px',
      borderRadius: 10,
      background: 'var(--sage-50)',
      color: 'var(--text-body)',
      fontSize: '.9rem',
      lineHeight: 1.55
    }
  }, "\u201C", a.trim(), "\u201D", /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement(Pill, {
    size: "sm",
    icon: "message-square"
  }, "Your answer \xB7 25 Oct")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-label)',
      color: 'var(--text-strong)'
    }
  }, q.before ? 'Proposed wording' : q.after ? 'Proposed new bullet' : 'Second title'), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 8,
      padding: '12px 14px',
      borderRadius: 10,
      border: '1px solid var(--border-subtle)',
      fontSize: '.9rem',
      lineHeight: 1.55
    }
  }, q.before && /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      textDecoration: 'line-through'
    }
  }, q.before), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-strong)',
      background: 'var(--marigold-50)',
      padding: '2px 4px',
      borderRadius: 4
    }
  }, after)), /measured/i.test(a) && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.8rem',
      color: 'var(--text-muted)'
    }
  }, "No number added \u2014 you said it wasn\u2019t measured.")), /*#__PURE__*/React.createElement(Checkbox, {
    variant: "card",
    checked: ok,
    onChange: setOk,
    label: "This is true and about my own work",
    description: "We\u2019ll use it as a confirmed fact. You can edit or remove it later."
  }), /*#__PURE__*/React.createElement(RadioGroup, {
    label: "Where should it go?",
    name: "dest",
    direction: "row",
    value: dest,
    onChange: setDest,
    options: [{
      value: 'base',
      label: 'My Base CV',
      description: 'Every future job starts with it.'
    }, {
      value: 'job',
      label: 'Only the Northstar People CV',
      description: 'Your Base CV stays as it is.'
    }]
  }), /*#__PURE__*/React.createElement(OnbActions, {
    back: /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      icon: "arrow-left",
      onClick: () => setStep('ask')
    }, "Edit answer")
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: "check",
    disabled: !ok,
    onClick: () => {
      if (dest === 'base') {
        flash('Saved — Base CV v' + (ver + 1));
        setVer(v => v + 1);
      } else flash('Saved to the Northstar People CV');
      advance(q.id, 'done');
    }
  }, dest === 'base' ? `Save as Base CV v${ver + 1}` : 'Save to this job only'))))))));
}
window.EnrichScreen = EnrichScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/ScrEnrich.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/ScrJobs.jsx
try { (() => {
function JobCaptureScreen({
  state,
  go
}) {
  const {
    Card,
    Button,
    Field,
    Segmented,
    Spinner,
    Alert,
    Checkbox,
    Pill,
    IconButton
  } = ONB_DS;
  const D = window.CVZ_DATA;
  const [mode, setMode] = React.useState({
    'Paste': 'paste',
    'Link blocked': 'link',
    'Manual': 'manual',
    'Extension': 'ext',
    'Parse failed': 'paste'
  }[state]);
  const [text, setText] = React.useState(D.job.ad);
  const [url, setUrl] = React.useState(state === 'Link blocked' ? 'https://www.linkedin.com/jobs/view/3921057' : '');
  const [blocked, setBlocked] = React.useState(state === 'Link blocked');
  const [failed, setFailed] = React.useState(state === 'Parse failed');
  const [busy, setBusy] = React.useState(false);
  const [title, setTitle] = React.useState(D.job.title);
  const [company, setCompany] = React.useState(D.job.company);
  const [reqs, setReqs] = React.useState([{
    t: 'Process automation',
    p: 'req'
  }, {
    t: 'SQL',
    p: 'req'
  }, {
    t: 'Power BI',
    p: 'pref'
  }]);
  const [cap, setCap] = React.useState(false);
  const [consent, setConsent] = React.useState(false);
  const urlOk = /^https:\/\/.+\..+/.test(url);
  const ready = mode === 'paste' ? text.trim().length >= 30 : mode === 'link' ? urlOk : mode === 'manual' ? !!title.trim() && reqs.some(r => r.t.trim()) : false;
  const run = () => {
    if (mode === 'link' && /linkedin\.com/.test(url)) {
      setBlocked(true);
      return;
    }
    setBusy(true);
    setTimeout(() => go('requirements'), 1300);
  };
  if (busy) return /*#__PURE__*/React.createElement(Card, {
    style: {
      maxWidth: 640,
      margin: '40px auto',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '40px 0'
    }
  }, /*#__PURE__*/React.createElement(Spinner, {
    label: "Reading the job ad and finding its requirements\u2026"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 18
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    onClick: () => setBusy(false)
  }, "Cancel"))));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 720,
      margin: '0 auto',
      display: 'grid',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(OnbTitle, {
    title: "Which job are you applying for?"
  }, "We only read what you give us. Nothing is sent to the employer."), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      overflowX: 'auto',
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(Segmented, {
    fullWidth: true,
    value: mode,
    onChange: m => {
      setMode(m);
      setBlocked(false);
    },
    options: [{
      value: 'paste',
      label: 'Paste'
    }, {
      value: 'link',
      label: 'Link'
    }, {
      value: 'manual',
      label: 'Type it in'
    }, {
      value: 'ext',
      label: 'Browser'
    }]
  })), mode === 'paste' && /*#__PURE__*/React.createElement(React.Fragment, null, failed && /*#__PURE__*/React.createElement(Alert, {
    tone: "bad",
    title: "We couldn\u2019t find the requirements",
    action: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "primary",
      icon: "rotate-cw",
      onClick: () => {
        setFailed(false);
        run();
      }
    }, "Try again")
  }, "Your text is still here. Check it includes the requirements \u2014 or ", /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      setMode('manual');
    }
  }, "type them in"), "."), /*#__PURE__*/React.createElement(Field, {
    label: "Job ad",
    multiline: true,
    rows: 9,
    maxLength: 6000,
    value: text,
    onChange: setText,
    hint: "Copy the whole ad, including the requirements.",
    error: text.length > 0 && text.trim().length < 30 ? 'Paste a bit more — at least a few sentences.' : undefined
  })), mode === 'link' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Field, {
    label: "Link to the job ad",
    icon: "link",
    type: "url",
    value: url,
    onChange: v => {
      setUrl(v);
      setBlocked(false);
    },
    placeholder: "https://www.ejobs.ro/\u2026",
    hint: "Public pages only. We never sign in for you.",
    error: url && !/^https:\/\//.test(url) ? 'Use the full link, starting with https://' : undefined,
    success: urlOk && !blocked ? 'Looks like a valid link' : undefined
  }), blocked && /*#__PURE__*/React.createElement(Alert, {
    tone: "warn",
    title: "This page needs a login",
    action: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "primary",
      icon: "clipboard-paste",
      onClick: () => {
        setMode('paste');
        setBlocked(false);
      }
    }, "Paste instead")
  }, "We can\u2019t open pages behind a login. Copy the ad text from the page and paste it \u2014 it takes a few seconds.")), mode === 'manual' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-label)',
      color: 'var(--text-strong)'
    }
  }, "Requirements"), reqs.map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 8,
      alignItems: 'center',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1 1 220px'
    }
  }, /*#__PURE__*/React.createElement(Field, {
    size: "sm",
    value: r.t,
    onChange: v => setReqs(x => x.map((y, k) => k === i ? {
      ...y,
      t: v
    } : y)),
    placeholder: "e.g. SQL"
  })), /*#__PURE__*/React.createElement(Segmented, {
    size: "sm",
    value: r.p,
    onChange: v => setReqs(x => x.map((y, k) => k === i ? {
      ...y,
      p: v
    } : y)),
    options: [{
      value: 'req',
      label: 'Required'
    }, {
      value: 'pref',
      label: 'Nice to have'
    }]
  }), /*#__PURE__*/React.createElement(IconButton, {
    size: "sm",
    variant: "ghost",
    icon: "trash-2",
    label: "Remove",
    onClick: () => setReqs(x => x.filter((_, k) => k !== i))
  }))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "ghost",
    icon: "plus",
    onClick: () => setReqs(x => [...x, {
      t: '',
      p: 'req'
    }])
  }, "Add requirement"))), mode === 'ext' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      alignItems: 'center',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Pill, {
    size: "sm",
    tone: "info",
    icon: "flask-conical"
  }, "Concept \xB7 not available yet")), /*#__PURE__*/React.createElement(OnbPromise, {
    items: [['mouse-pointer-click', 'Open the ad and click the Resumora button', 'We capture only the page you’re on — never your history, cookies or other tabs.'], ['eye', 'You see exactly what we’d send', 'Edit it or cancel before anything leaves your browser.']]
  }), !cap ? /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
    icon: "scan-text",
    onClick: () => setCap(true)
  }, "Simulate capture")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 14px',
      borderRadius: 10,
      background: 'var(--sage-50)',
      border: '1px solid var(--border-subtle)',
      fontSize: '.82rem',
      lineHeight: 1.55,
      color: 'var(--text-body)',
      whiteSpace: 'pre-wrap',
      maxHeight: 150,
      overflow: 'auto'
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      display: 'block',
      marginBottom: 6,
      color: 'var(--text-strong)'
    }
  }, "From ejobs.ro \xB7 Northstar People"), D.job.ad), /*#__PURE__*/React.createElement(Checkbox, {
    checked: consent,
    onChange: setConsent,
    label: "Send only this text to Resumora"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: "check",
    disabled: !consent,
    onClick: () => {
      setMode('paste');
      setCap(false);
      setConsent(false);
    }
  }, "Use this text")))), mode !== 'ext' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,220px),1fr))',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Job title",
    icon: "briefcase",
    value: title,
    onChange: setTitle,
    optional: mode !== 'manual',
    error: mode === 'manual' && !title.trim() ? 'Add the job title.' : undefined
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Company",
    icon: "building-2",
    value: company,
    onChange: setCompany,
    optional: true
  })))), mode !== 'ext' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconRight: "arrow-right",
    disabled: !ready,
    onClick: run
  }, mode === 'manual' ? 'Continue' : 'Read the job ad')));
}
function RequirementsScreen({
  state,
  go
}) {
  const {
    Card,
    Button,
    Segmented,
    Pill,
    Alert,
    Select,
    EmptyState
  } = ONB_DS;
  const [rq, setRq] = React.useState(RZ_APP.reqs);
  const [changed, setChanged] = React.useState(false);
  if (state === 'No Base CV') return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 640,
      margin: '40px auto'
    }
  }, /*#__PURE__*/React.createElement(EmptyState, {
    icon: "file-user",
    title: "First, bring your CV",
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: "file-up",
      href: "onboarding.html#/import"
    }, "Bring my CV")
  }, "We compare the job with your confirmed Base CV. It takes about 5 minutes, and the job is saved for when you\u2019re back."));
  const nReq = rq.filter(r => r.pri === 'req' && !r.gate).length,
    nPref = rq.filter(r => r.pri === 'pref').length;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1120,
      margin: '0 auto',
      display: 'grid',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(OnbTitle, {
    title: "Check what the job asks for"
  }, "We sorted the ad into requirements. Fix anything we got wrong \u2014 it changes how your match is weighed."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 24,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '2 1 480px',
      display: 'grid',
      gap: 14,
      minWidth: 0
    }
  }, changed && /*#__PURE__*/React.createElement(Alert, {
    tone: "info",
    title: "Changed"
  }, "We\u2019ll use your version when we calculate the match."), /*#__PURE__*/React.createElement(Card, {
    padding: "none"
  }, rq.map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: r.id,
    style: {
      display: 'flex',
      gap: 16,
      alignItems: 'center',
      justifyContent: 'space-between',
      flexWrap: 'wrap',
      padding: '16px 20px',
      borderTop: i ? '1px solid var(--border-subtle)' : 0,
      background: r.gate ? 'var(--status-warn-bg)' : 'transparent'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0,
      flex: '1 1 260px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      alignItems: 'center',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      fontWeight: 650,
      color: 'var(--text-strong)'
    }
  }, r.text), /*#__PURE__*/React.createElement(Pill, {
    size: "sm"
  }, r.cat), r.or && /*#__PURE__*/React.createElement(Pill, {
    size: "sm",
    tone: "info"
  }, "Either one counts")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.8rem',
      color: 'var(--text-muted)',
      marginTop: 4,
      fontStyle: 'italic'
    }
  }, r.src)), r.gate ? /*#__PURE__*/React.createElement(Pill, {
    tone: "warn",
    icon: "shield-alert"
  }, "Must-have \xB7 checked separately") : /*#__PURE__*/React.createElement(Segmented, {
    size: "sm",
    value: r.pri,
    onChange: v => {
      setRq(x => x.map(y => y.id === r.id ? {
        ...y,
        pri: v
      } : y));
      setChanged(true);
    },
    options: [{
      value: 'req',
      label: 'Required'
    }, {
      value: 'pref',
      label: 'Nice to have'
    }]
  })))), /*#__PURE__*/React.createElement(Alert, {
    tone: "neutral",
    icon: "info"
  }, "Must-haves like the right to work never raise or lower your score. We\u2019ll keep reminding you until it\u2019s answered.")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'sticky',
      top: 20,
      display: 'grid',
      gap: 16,
      flex: '1 1 260px'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "sm"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 650,
      color: 'var(--text-strong)'
    }
  }, "Northstar People"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.84rem',
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, "Business Systems Analyst \u2014 Automation \xB7 Bucharest \xB7 hybrid")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Pill, {
    size: "sm"
  }, nReq, " required"), /*#__PURE__*/React.createElement(Pill, {
    size: "sm"
  }, nPref, " nice to have"), /*#__PURE__*/React.createElement(Pill, {
    size: "sm",
    tone: "warn"
  }, "1 must-have")), /*#__PURE__*/React.createElement(Select, {
    label: "Compare with",
    icon: "file-user",
    defaultValue: "v3",
    options: [{
      value: 'v3',
      label: 'Base CV v3',
      description: 'Current · 23 Oct'
    }, {
      value: 'v2',
      label: 'Base CV v2',
      description: '20 Oct'
    }]
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    iconRight: "arrow-right",
    onClick: () => go('match')
  }, "Check my match"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    icon: "pencil",
    onClick: () => go('addjob')
  }, "Edit the job ad"))))));
}
Object.assign(window, {
  JobCaptureScreen,
  RequirementsScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/ScrJobs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/ScrSystem.jsx
try { (() => {
function RzSysPage({
  icon,
  tone = 'good',
  code,
  title,
  children,
  actions,
  foot
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 520,
      margin: 'min(8vh,64px) auto 0',
      display: 'grid',
      gap: 20,
      justifyItems: 'center',
      textAlign: 'center'
    }
  }, code ? /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      font: '700 clamp(4.5rem,18cqi,7rem)/1 var(--font-display)',
      letterSpacing: '-0.06em',
      color: 'var(--pine-200)'
    }
  }, code) : /*#__PURE__*/React.createElement(OnbIconTile, {
    icon: icon,
    tone: tone,
    size: 64
  }), /*#__PURE__*/React.createElement(OnbTitle, {
    center: true,
    title: title
  }, children), actions && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      flexWrap: 'wrap',
      justifyContent: 'center'
    }
  }, actions), foot && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.82rem',
      color: 'var(--text-muted)',
      display: 'flex',
      gap: '6px 14px',
      flexWrap: 'wrap',
      justifyContent: 'center',
      alignItems: 'center'
    }
  }, foot));
}
function NotFoundScreen({
  go
}) {
  const {
    Button
  } = ONB_DS;
  return /*#__PURE__*/React.createElement(RzSysPage, {
    code: "404",
    title: "We can\u2019t find that page",
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: "house",
      onClick: () => go('home')
    }, "Go to Home"), /*#__PURE__*/React.createElement(Button, {
      icon: "briefcase",
      onClick: () => go('applications')
    }, "My applications")),
    foot: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", null, "Looking for something else?"), /*#__PURE__*/React.createElement("a", {
      href: "#/base"
    }, "Base CV"), /*#__PURE__*/React.createElement("a", {
      href: "#/account"
    }, "Account"), /*#__PURE__*/React.createElement("a", {
      href: "mailto:ajutor@resumora.ro"
    }, "Contact us"))
  }, "The link may be old or mistyped. Your CVs and applications are safe.");
}
function ServerErrorScreen({
  go,
  flash
}) {
  const {
    Button
  } = ONB_DS;
  const [busy, setBusy] = React.useState(false);
  return /*#__PURE__*/React.createElement(RzSysPage, {
    code: "500",
    title: "Something went wrong on our side",
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: "rotate-cw",
      loading: busy,
      onClick: () => {
        setBusy(true);
        setTimeout(() => {
          setBusy(false);
          flash('Still not working — try again in a minute');
        }, 1200);
      }
    }, "Try again"), /*#__PURE__*/React.createElement(Button, {
      icon: "house",
      onClick: () => go('home')
    }, "Go to Home")),
    foot: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
      style: {
        font: '600 .74rem var(--font-mono, monospace)'
      }
    }, "Reference RZ-7F3K-251026"), /*#__PURE__*/React.createElement("a", {
      href: "mailto:ajutor@resumora.ro"
    }, "Send it to us"))
  }, "Everything up to your last save is safe. It\u2019s not something you did \u2014 try again in a minute.");
}
function OfflineScreen({
  flash
}) {
  const {
    Button,
    Pill
  } = ONB_DS;
  return /*#__PURE__*/React.createElement(RzSysPage, {
    icon: "wifi-off",
    tone: "warn",
    title: "You\u2019re offline",
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: "rotate-cw",
      onClick: () => flash('Still offline — we’ll keep trying')
    }, "Try again"),
    foot: /*#__PURE__*/React.createElement(Pill, {
      size: "sm",
      tone: "warn",
      icon: "cloud-off"
    }, "2 changes waiting to save")
  }, "You can keep editing. Changes stay on this device and save as soon as you\u2019re back online.");
}
function MaintenanceScreen() {
  return /*#__PURE__*/React.createElement(RzSysPage, {
    icon: "wrench",
    tone: "info",
    title: "We\u2019re updating Resumora",
    foot: /*#__PURE__*/React.createElement("span", null, "Updates at ", /*#__PURE__*/React.createElement("a", {
      href: "#/maintenance"
    }, "status.resumora.ro"))
  }, "We\u2019ll be back by 14:00, Bucharest time. Everything you\u2019ve saved is safe and unchanged.");
}
function SessionScreen({
  go
}) {
  const {
    Button
  } = ONB_DS;
  return /*#__PURE__*/React.createElement(RzSysPage, {
    icon: "log-out",
    tone: "info",
    title: "You\u2019ve been signed out",
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: "log-in",
      onClick: () => go('login')
    }, "Log in again")
  }, "For your safety we sign you out after a while. Your unsaved draft is kept on this device \u2014 you\u2019ll find it after you log in.");
}
function RzAuthCard({
  title,
  sub,
  children,
  foot
}) {
  const {
    Card
  } = ONB_DS;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 440,
      margin: 'min(6vh,48px) auto 0',
      display: 'grid',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(OnbTitle, {
    title: title
  }, sub), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 18
    }
  }, children)), foot && /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      fontSize: '.86rem',
      color: 'var(--text-muted)'
    }
  }, foot));
}
function LoginScreen({
  state,
  go
}) {
  const {
    Field,
    Button,
    Alert,
    Checkbox
  } = ONB_DS;
  const [email, setEmail] = React.useState(state === 'Default' ? '' : 'mara.ionescu@example.ro');
  const [pw, setPw] = React.useState(state === 'Default' ? '' : 'wrongpass');
  const [tried, setTried] = React.useState(false);
  const locked = state === 'Too many attempts',
    wrong = state === 'Wrong password';
  const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);
  const submit = () => {
    setTried(true);
    if (emailOk && pw && !wrong && !locked) go('home');
  };
  return /*#__PURE__*/React.createElement(RzAuthCard, {
    title: "Welcome back",
    sub: "Log in to see your Base CV and applications.",
    foot: /*#__PURE__*/React.createElement("span", null, "New to Resumora? ", /*#__PURE__*/React.createElement("a", {
      href: "onboarding.html#/account"
    }, "Create an account"))
  }, locked && /*#__PURE__*/React.createElement(Alert, {
    tone: "warn",
    title: "Too many tries"
  }, "For your safety, wait 5 minutes \u2014 or reset your password now."), /*#__PURE__*/React.createElement(Field, {
    label: "Email",
    icon: "mail",
    type: "email",
    value: email,
    onChange: setEmail,
    placeholder: "name@example.ro",
    error: tried && !emailOk ? 'Check the email — it should look like name@example.ro.' : undefined
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Password",
    icon: "lock",
    type: "password",
    value: pw,
    onChange: setPw,
    error: wrong ? 'Email or password doesn’t match. Check both, or reset your password.' : tried && !pw ? 'Enter your password.' : undefined
  }), /*#__PURE__*/React.createElement("a", {
    href: "#/forgot",
    style: {
      justifySelf: 'end',
      fontSize: '.82rem'
    }
  }, "Forgot password?")), /*#__PURE__*/React.createElement(Checkbox, {
    defaultChecked: true,
    label: "Keep me logged in on this device"
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    disabled: locked,
    onClick: submit
  }, "Log in"));
}
function ForgotScreen({
  state,
  go
}) {
  const {
    Field,
    Button
  } = ONB_DS;
  const [email, setEmail] = React.useState('mara.ionescu@example.ro');
  const [sent, setSent] = React.useState(state === 'Sent');
  const [wait, setWait] = React.useState(0);
  React.useEffect(() => {
    if (!wait) return;
    const t = setTimeout(() => setWait(w => w - 1), 1000);
    return () => clearTimeout(t);
  }, [wait]);
  const ok = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);
  if (sent) return /*#__PURE__*/React.createElement(RzSysPage, {
    icon: "mail-check",
    title: "Check your inbox",
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      icon: "rotate-cw",
      disabled: wait > 0,
      onClick: () => setWait(30)
    }, wait ? `Resend in ${wait}s` : 'Resend link'), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: () => go('login')
    }, "Back to log in")),
    foot: /*#__PURE__*/React.createElement("span", null, "Can\u2019t find it? Look in Spam or Promotions.")
  }, "If an account exists for ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-strong)',
      fontWeight: 650
    }
  }, email), ", we sent a link to reset your password. It works for 1 hour.");
  return /*#__PURE__*/React.createElement(RzAuthCard, {
    title: "Reset your password",
    sub: "We\u2019ll email you a link to choose a new one.",
    foot: /*#__PURE__*/React.createElement("a", {
      href: "#/login"
    }, "Back to log in")
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Email",
    icon: "mail",
    type: "email",
    value: email,
    onChange: setEmail,
    error: email && !ok ? 'Check the email — it should look like name@example.ro.' : undefined
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    disabled: !ok,
    onClick: () => setSent(true)
  }, "Send reset link"));
}
function ResetScreen({
  state,
  go
}) {
  const {
    Field,
    Button
  } = ONB_DS;
  const [a, setA] = React.useState('');
  const [b, setB] = React.useState('');
  const [done, setDone] = React.useState(state === 'Done');
  if (done) return /*#__PURE__*/React.createElement(RzSysPage, {
    icon: "circle-check",
    tone: "inverse",
    title: "Password changed",
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      iconRight: "arrow-right",
      onClick: () => go('home')
    }, "Go to Home")
  }, "You\u2019re logged in on this device. For safety, we logged you out everywhere else.");
  const ok = a.length >= 8 && a === b;
  return /*#__PURE__*/React.createElement(RzAuthCard, {
    title: "Choose a new password",
    sub: "For mara.ionescu@example.ro"
  }, /*#__PURE__*/React.createElement(Field, {
    label: "New password",
    icon: "lock",
    type: "password",
    value: a,
    onChange: setA,
    hint: "At least 8 characters.",
    error: a && a.length < 8 ? 'Use at least 8 characters.' : undefined,
    success: a.length >= 8 ? 'Strong enough' : undefined
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Repeat it",
    icon: "lock",
    type: "password",
    value: b,
    onChange: setB,
    error: b && a !== b ? 'The two passwords don’t match.' : undefined
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    disabled: !ok,
    onClick: () => setDone(true)
  }, "Save new password"));
}
function ExpiredScreen({
  go
}) {
  const {
    Button
  } = ONB_DS;
  return /*#__PURE__*/React.createElement(RzSysPage, {
    icon: "link-2-off",
    tone: "warn",
    title: "This link has expired",
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: "mail",
      onClick: () => go('forgot')
    }, "Send a new link"), /*#__PURE__*/React.createElement(Button, {
      onClick: () => go('login')
    }, "Log in"))
  }, "Password links work for 1 hour and email links for 24 hours. Ask for a new one \u2014 it only takes a moment.");
}
Object.assign(window, {
  RzSysPage,
  NotFoundScreen,
  ServerErrorScreen,
  OfflineScreen,
  MaintenanceScreen,
  SessionScreen,
  LoginScreen,
  ForgotScreen,
  ResetScreen,
  ExpiredScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/ScrSystem.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/appdata.js
try { (() => {
window.RZ_APP = {
  base: {
    name: 'Mara Ionescu',
    t1: 'Business Systems Analyst',
    t2: '',
    email: 'mara.ionescu@example.ro',
    phone: '',
    city: 'Cluj-Napoca',
    summary: 'Analyst with 6 years in HR operations and process improvement.',
    pro: ['Process automation', 'Requirements analysis', 'Gestionarea părților interesate'],
    tech: ['SQL', 'Excel', 'REST APIs'],
    roles: [{
      id: 'r1',
      title: 'Systems Analyst',
      company: 'BridgeWorks',
      city: 'Cluj-Napoca',
      start: {
        y: '2021',
        m: ''
      },
      current: true,
      end: {
        y: '',
        m: ''
      },
      context: 'Internal systems team supporting finance and HR across 3 offices.',
      bullets: ['Mapped approval workflows with stakeholders across finance and HR.', 'Wrote SQL reports used in monthly payroll reconciliation.', 'Responsible for payroll exports via REST APIs for 3 HR teams.']
    }, {
      id: 'r2',
      title: 'HR Operations Specialist',
      company: 'Carpatia Retail',
      city: 'Cluj-Napoca',
      start: {
        y: '2019',
        m: '3'
      },
      current: false,
      end: {
        y: '2021',
        m: ''
      },
      context: 'HR team of 6 for a retail chain.',
      bullets: ['Coordinated onboarding for 40+ hires per quarter.', 'Responsible for HR reporting.']
    }],
    edu: 'BSc Economic Informatics — Babeș-Bolyai University, 2013 — 2016',
    langs: 'Romanian — native · English — C1 (Cambridge CAE)',
    sections: [{
      k: 'summary',
      label: 'Summary',
      on: true
    }, {
      k: 'experience',
      label: 'Experience',
      on: true
    }, {
      k: 'skills',
      label: 'Skills',
      on: true
    }, {
      k: 'education',
      label: 'Education',
      on: true
    }, {
      k: 'languages',
      label: 'Languages',
      on: true
    }]
  },
  versions: [{
    v: 3,
    date: '23 Oct 2026, 14:10',
    why: 'Confirmed an answer',
    detail: 'Added the outcome of the approval workflow at BridgeWorks.',
    summary: 'Analyst with 6 years in HR operations and process improvement.'
  }, {
    v: 2,
    date: '20 Oct 2026, 09:42',
    why: 'Edited',
    detail: 'Split skills into professional and technical. Added English level.',
    summary: 'Analyst with 6 years in HR operations and process improvement.'
  }, {
    v: 1,
    date: '18 Oct 2026, 18:05',
    why: 'Imported',
    detail: 'From Mara_Ionescu_CV_2026.pdf — every section confirmed.',
    summary: 'HR and systems analyst.'
  }],
  questions: [{
    id: 'e1',
    section: 'BridgeWorks · Systems Analyst',
    q: 'What changed after you automated the payroll exports?',
    help: 'Your own result. Qualitative is fine. If it wasn’t measured, say so — we won’t add a number.',
    chips: ['It wasn’t measured', 'No more manual file uploads', 'Fewer errors at month end'],
    before: 'Responsible for payroll exports via REST APIs for 3 HR teams.',
    after: 'Automated payroll exports via REST APIs for 3 HR teams, replacing manual file uploads.'
  }, {
    id: 'e2',
    section: 'BridgeWorks · Systems Analyst',
    q: 'What happened to approval requests after the new workflow?',
    help: 'Think of what people noticed — speed, fewer lost requests, less chasing.',
    chips: ['Requests stopped getting lost', 'Less chasing by email', 'It wasn’t measured'],
    before: null,
    after: 'Replaced manual approval emails with a tracked workflow, so requests no longer got lost.'
  }, {
    id: 'e3',
    section: 'Carpatia Retail · HR Operations',
    q: 'Which HR reports did you own, and who used them?',
    help: 'Name the reports and the people who relied on them.',
    chips: ['Monthly headcount', 'Turnover', 'Store managers used them'],
    before: 'Responsible for HR reporting.',
    after: 'Built monthly headcount and turnover reports for store managers.'
  }, {
    id: 'e4',
    section: 'Titles',
    q: 'Is there a second kind of role you apply for?',
    help: 'Shown under your name as a positioning title. It never changes your past job titles.',
    chips: ['Process Automation Specialist', 'HRIS Analyst'],
    before: null,
    after: null
  }],
  reqs: [{
    id: 'q1',
    text: 'Process automation',
    src: '“…to automate HR and payroll workflows.”',
    cat: 'Responsibilities',
    pri: 'req'
  }, {
    id: 'q2',
    text: 'SQL',
    src: '“Required: process automation, SQL, REST APIs…”',
    cat: 'Tools',
    pri: 'req'
  }, {
    id: 'q3',
    text: 'REST APIs',
    src: '“Required: process automation, SQL, REST APIs…”',
    cat: 'Tools',
    pri: 'req'
  }, {
    id: 'q4',
    text: 'Stakeholder management',
    src: '“…stakeholder management…”',
    cat: 'Professional skills',
    pri: 'req'
  }, {
    id: 'q5',
    text: '4+ years in business or systems analysis',
    src: '“4+ years in business/systems analysis”',
    cat: 'Experience',
    pri: 'req'
  }, {
    id: 'q6',
    text: 'Right to work in Romania',
    src: '“…right to work in Romania.”',
    cat: 'Eligibility',
    pri: 'req',
    gate: true
  }, {
    id: 'q7',
    text: 'HRIS: Workday or SAP SuccessFactors',
    src: '“Nice to have: HRIS experience (Workday or SAP SuccessFactors)”',
    cat: 'Domain',
    pri: 'pref',
    or: true
  }, {
    id: 'q8',
    text: 'Power BI',
    src: '“…Power BI.”',
    cat: 'Tools',
    pri: 'pref'
  }],
  apps: [{
    id: 'a1',
    role: 'Business Systems Analyst — Automation',
    company: 'Northstar People',
    stage: 'To send',
    cv: 'Not tailored yet',
    tailored: false,
    next: 'See your match and tailor your CV',
    date: ''
  }, {
    id: 'a2',
    role: 'Process Analyst',
    company: 'Lumen Bank',
    stage: 'Interview',
    cv: 'Tailored CV v2',
    tailored: true,
    next: 'Interview with the team',
    date: '28 Oct'
  }, {
    id: 'a3',
    role: 'HRIS Analyst',
    company: 'Carpatia Logistics',
    stage: 'Sent',
    cv: 'Tailored CV v1',
    tailored: true,
    next: 'Follow up with the recruiter',
    date: '30 Oct'
  }, {
    id: 'a4',
    role: 'Business Analyst',
    company: 'Orbit Soft',
    stage: 'Closed',
    cv: 'Base CV v2',
    tailored: false,
    next: '—',
    date: ''
  }],
  linkedin: 'Business Systems Analyst | Process automation · SQL · Power BI\n\nI help HR and finance teams replace manual work with simple, reliable workflows. Skills: Requirements analysis, Stakeholder management, Agile, Workday.',
  li: {
    both: ['Process automation', 'SQL', 'Requirements analysis', 'Stakeholder management'],
    onlyLi: ['Power BI', 'Agile', 'Workday'],
    onlyCv: ['REST APIs', 'Payroll systems', 'Excel']
  }
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/appdata.js", error: String((e && e.message) || e) }); }

// ui_kits/web-app/data.js
try { (() => {
window.CVZ_DATA = {
  user: {
    name: 'Mara Ionescu',
    first: 'Mara'
  },
  job: {
    title: 'Business Systems Analyst — Automation',
    company: 'Northstar People',
    city: 'Bucharest · hybrid',
    ad: 'Northstar People is hiring a Business Systems Analyst to automate HR and payroll workflows.\n\nRequired: process automation, SQL, REST APIs, stakeholder management, 4+ years in business/systems analysis, right to work in Romania.\nNice to have: HRIS experience (Workday or SAP SuccessFactors), Power BI.'
  },
  findings: {
    add: [{
      term: 'REST APIs',
      required: true,
      state: 'omitted',
      detail: 'Payroll API project at BridgeWorks is in your Base CV, not this one.'
    }, {
      term: 'HR / payroll systems',
      required: false,
      state: 'omitted',
      detail: 'You automated payroll exports for 3 HR teams.'
    }, {
      term: 'Outcome of your automation work',
      required: true,
      state: 'omitted',
      detail: 'You confirmed it cut manual approvals — say so in the summary.'
    }],
    check: [{
      term: 'Right to work in Romania',
      required: true,
      state: 'confirm',
      detail: 'The job requires it. We don’t know yet — your score doesn’t change either way.'
    }],
    strong: [{
      term: 'Process automation',
      required: true,
      state: 'included',
      detail: 'Two roles describe it.'
    }, {
      term: 'SQL',
      required: true,
      state: 'included',
      detail: 'Listed in technical skills and used at BridgeWorks.'
    }, {
      term: 'Stakeholder management',
      required: true,
      state: 'equivalent',
      detail: 'Your CV says “gestionarea părților interesate” — counted as the same.'
    }, {
      term: '4+ years in analysis',
      required: true,
      state: 'included',
      detail: 'About 6 years, as of Oct 2026 (overlaps counted once).'
    }],
    gap: [{
      term: 'Power BI',
      required: false,
      state: 'gap',
      detail: 'Not in your experience. Fine to leave out — it’s a nice-to-have.'
    }]
  },
  changes: [{
    id: 'sum',
    section: 'Summary',
    source: 'Uses confirmed facts',
    before: 'Analyst with 6 years in HR operations and process improvement.',
    after: 'Business systems analyst with 6 years automating HR and payroll workflows — from requirements to REST API integrations.',
    why: 'Names automation and APIs, both required.'
  }, {
    id: 'api',
    section: 'BridgeWorks · add bullet',
    source: 'From your Base CV',
    after: 'Automated payroll exports via REST APIs for 3 HR teams.',
    why: 'Shows REST APIs and payroll — currently missing.'
  }, {
    id: 'out',
    section: 'BridgeWorks · add bullet',
    source: 'You confirmed this',
    after: 'Replaced manual approval emails with a tracked workflow, so requests no longer got lost.',
    why: 'Adds an outcome. No number — you said it wasn’t measured.'
  }]
};
window.CVZ_cv = function (accepted) {
  const D = window.CVZ_DATA.changes;
  const has = id => accepted.includes(id);
  const bw = ['Mapped approval workflows with stakeholders across finance and HR.', 'Wrote SQL reports used in monthly payroll reconciliation.'];
  if (has('api')) bw.unshift(D[1].after);
  if (has('out')) bw.push(D[2].after);
  return [{
    title: 'Summary',
    text: has('sum') ? D[0].after : D[0].before
  }, {
    title: 'Experience',
    items: [{
      heading: 'Systems Analyst — BridgeWorks',
      dates: '2021 — Present',
      sub: 'Cluj-Napoca',
      bullets: bw
    }, {
      heading: 'HR Operations Specialist — Carpatia Retail',
      dates: 'Mar 2019 — 2021',
      sub: 'Cluj-Napoca',
      bullets: ['Coordinated onboarding for 40+ hires per quarter.']
    }]
  }, {
    title: 'Skills',
    text: 'Process automation · SQL · Requirements analysis · Gestionarea părților interesate · Excel'
  }];
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/data.js", error: String((e && e.message) || e) }); }

// ui_kits/web-app/ios-frame.jsx
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)
// Copied omelette starter. Re-running copy_starter_component with this kind overwrites this file with the latest version (page content is unaffected).

/* BEGIN USAGE */
// iOS.jsx — Simplified iOS 26 (Liquid Glass) device frame
// Based on the iOS 26 UI Kit + Figma status bar spec. No assets, no deps.
// Exports (to window): IOSDevice, IOSStatusBar, IOSNavBar, IOSGlassPill, IOSList, IOSListRow, IOSKeyboard
//
// Usage — wrap your screen content in <IOSDevice> to get the bezel, status bar
// and home indicator (props: title, dark, keyboard):
//
//   <IOSDevice title="Settings">
//     ...your screen content...
//   </IOSDevice>
//   <IOSDevice dark title="Search" keyboard>…</IOSDevice>
/* END USAGE */

// ─────────────────────────────────────────────────────────────
// Status bar
// ─────────────────────────────────────────────────────────────
function IOSStatusBar({
  dark = false,
  time = '9:41'
}) {
  const c = dark ? '#fff' : '#000';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 154,
      alignItems: 'center',
      justifyContent: 'center',
      padding: '21px 24px 19px',
      boxSizing: 'border-box',
      position: 'relative',
      zIndex: 20,
      width: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 22,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      paddingTop: 1.5
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: '-apple-system, "SF Pro", system-ui',
      fontWeight: 590,
      fontSize: 17,
      lineHeight: '22px',
      color: c
    }
  }, time)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 22,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 7,
      paddingTop: 1,
      paddingRight: 1
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "19",
    height: "12",
    viewBox: "0 0 19 12"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0",
    y: "7.5",
    width: "3.2",
    height: "4.5",
    rx: "0.7",
    fill: c
  }), /*#__PURE__*/React.createElement("rect", {
    x: "4.8",
    y: "5",
    width: "3.2",
    height: "7",
    rx: "0.7",
    fill: c
  }), /*#__PURE__*/React.createElement("rect", {
    x: "9.6",
    y: "2.5",
    width: "3.2",
    height: "9.5",
    rx: "0.7",
    fill: c
  }), /*#__PURE__*/React.createElement("rect", {
    x: "14.4",
    y: "0",
    width: "3.2",
    height: "12",
    rx: "0.7",
    fill: c
  })), /*#__PURE__*/React.createElement("svg", {
    width: "17",
    height: "12",
    viewBox: "0 0 17 12"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M8.5 3.2C10.8 3.2 12.9 4.1 14.4 5.6L15.5 4.5C13.7 2.7 11.2 1.5 8.5 1.5C5.8 1.5 3.3 2.7 1.5 4.5L2.6 5.6C4.1 4.1 6.2 3.2 8.5 3.2Z",
    fill: c
  }), /*#__PURE__*/React.createElement("path", {
    d: "M8.5 6.8C9.9 6.8 11.1 7.3 12 8.2L13.1 7.1C11.8 5.9 10.2 5.1 8.5 5.1C6.8 5.1 5.2 5.9 3.9 7.1L5 8.2C5.9 7.3 7.1 6.8 8.5 6.8Z",
    fill: c
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "8.5",
    cy: "10.5",
    r: "1.5",
    fill: c
  })), /*#__PURE__*/React.createElement("svg", {
    width: "27",
    height: "13",
    viewBox: "0 0 27 13"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0.5",
    y: "0.5",
    width: "23",
    height: "12",
    rx: "3.5",
    stroke: c,
    strokeOpacity: "0.35",
    fill: "none"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "2",
    y: "2",
    width: "20",
    height: "9",
    rx: "2",
    fill: c
  }), /*#__PURE__*/React.createElement("path", {
    d: "M25 4.5V8.5C25.8 8.2 26.5 7.2 26.5 6.5C26.5 5.8 25.8 4.8 25 4.5Z",
    fill: c,
    fillOpacity: "0.4"
  }))));
}

// ─────────────────────────────────────────────────────────────
// Liquid glass pill — blur + tint + shine
// ─────────────────────────────────────────────────────────────
function IOSGlassPill({
  children,
  dark = false,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: 44,
      minWidth: 44,
      borderRadius: 9999,
      position: 'relative',
      overflow: 'hidden',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: dark ? '0 2px 6px rgba(0,0,0,0.35), 0 6px 16px rgba(0,0,0,0.2)' : '0 1px 3px rgba(0,0,0,0.07), 0 3px 10px rgba(0,0,0,0.06)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 9999,
      backdropFilter: 'blur(12px) saturate(180%)',
      WebkitBackdropFilter: 'blur(12px) saturate(180%)',
      background: dark ? 'rgba(120,120,128,0.28)' : 'rgba(255,255,255,0.5)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 9999,
      boxShadow: dark ? 'inset 1.5px 1.5px 1px rgba(255,255,255,0.15), inset -1px -1px 1px rgba(255,255,255,0.08)' : 'inset 1.5px 1.5px 1px rgba(255,255,255,0.7), inset -1px -1px 1px rgba(255,255,255,0.4)',
      border: dark ? '0.5px solid rgba(255,255,255,0.15)' : '0.5px solid rgba(0,0,0,0.06)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 1,
      display: 'flex',
      alignItems: 'center',
      padding: '0 4px'
    }
  }, children));
}

// ─────────────────────────────────────────────────────────────
// Navigation bar — glass pills + large title
// ─────────────────────────────────────────────────────────────
function IOSNavBar({
  title = 'Title',
  dark = false,
  trailingIcon = true
}) {
  const muted = dark ? 'rgba(255,255,255,0.6)' : '#404040';
  const text = dark ? '#fff' : '#000';
  const pillIcon = content => /*#__PURE__*/React.createElement(IOSGlassPill, {
    dark: dark
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 36,
      height: 36,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, content));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      paddingTop: 62,
      paddingBottom: 10,
      position: 'relative',
      zIndex: 5
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 16px'
    }
  }, pillIcon(/*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "20",
    viewBox: "0 0 12 20",
    fill: "none",
    style: {
      marginLeft: -1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M10 2L2 10l8 8",
    stroke: muted,
    strokeWidth: "2.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))), trailingIcon && pillIcon(/*#__PURE__*/React.createElement("svg", {
    width: "22",
    height: "6",
    viewBox: "0 0 22 6"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "3",
    cy: "3",
    r: "2.5",
    fill: muted
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "11",
    cy: "3",
    r: "2.5",
    fill: muted
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "19",
    cy: "3",
    r: "2.5",
    fill: muted
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px',
      fontFamily: '-apple-system, system-ui',
      fontSize: 34,
      fontWeight: 700,
      lineHeight: '41px',
      color: text,
      letterSpacing: 0.4
    }
  }, title));
}

// ─────────────────────────────────────────────────────────────
// Grouped list (inset card, r:26) + row (52px)
// ─────────────────────────────────────────────────────────────
function IOSListRow({
  title,
  detail,
  icon,
  chevron = true,
  isLast = false,
  dark = false
}) {
  const text = dark ? '#fff' : '#000';
  const sec = dark ? 'rgba(235,235,245,0.6)' : 'rgba(60,60,67,0.6)';
  const ter = dark ? 'rgba(235,235,245,0.3)' : 'rgba(60,60,67,0.3)';
  const sep = dark ? 'rgba(84,84,88,0.65)' : 'rgba(60,60,67,0.12)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      minHeight: 52,
      padding: '0 16px',
      position: 'relative',
      fontFamily: '-apple-system, system-ui',
      fontSize: 17,
      letterSpacing: -0.43
    }
  }, icon && /*#__PURE__*/React.createElement("div", {
    style: {
      width: 30,
      height: 30,
      borderRadius: 7,
      background: icon,
      marginRight: 12,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      color: text
    }
  }, title), detail && /*#__PURE__*/React.createElement("span", {
    style: {
      color: sec,
      marginRight: 6
    }
  }, detail), chevron && /*#__PURE__*/React.createElement("svg", {
    width: "8",
    height: "14",
    viewBox: "0 0 8 14",
    style: {
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M1 1l6 6-6 6",
    stroke: ter,
    strokeWidth: "2",
    fill: "none",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })), !isLast && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: 0,
      right: 0,
      left: icon ? 58 : 16,
      height: 0.5,
      background: sep
    }
  }));
}
function IOSList({
  header,
  children,
  dark = false
}) {
  const hc = dark ? 'rgba(235,235,245,0.6)' : 'rgba(60,60,67,0.6)';
  const bg = dark ? '#1C1C1E' : '#fff';
  return /*#__PURE__*/React.createElement("div", null, header && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: '-apple-system, system-ui',
      fontSize: 13,
      color: hc,
      textTransform: 'uppercase',
      padding: '8px 36px 6px',
      letterSpacing: -0.08
    }
  }, header), /*#__PURE__*/React.createElement("div", {
    style: {
      background: bg,
      borderRadius: 26,
      margin: '0 16px',
      overflow: 'hidden'
    }
  }, children));
}

// ─────────────────────────────────────────────────────────────
// Device frame
// ─────────────────────────────────────────────────────────────
function IOSDevice({
  children,
  width = 402,
  height = 874,
  dark = false,
  title,
  keyboard = false
}) {
  return (
    /*#__PURE__*/
    // data-om-starter: inert presence marker — Claude Design's starter-usage
    // probe reads it; it renders nothing. Keep it on this root element.
    React.createElement("div", {
      "data-om-starter": "ios-frame",
      style: {
        width,
        height,
        borderRadius: 48,
        overflow: 'hidden',
        position: 'relative',
        background: dark ? '#000' : '#F2F2F7',
        boxShadow: '0 40px 80px rgba(0,0,0,0.18), 0 0 0 1px rgba(0,0,0,0.12)',
        fontFamily: '-apple-system, system-ui, sans-serif',
        WebkitFontSmoothing: 'antialiased'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        top: 11,
        left: '50%',
        transform: 'translateX(-50%)',
        width: 126,
        height: 37,
        borderRadius: 24,
        background: '#000',
        zIndex: 50
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 10
      }
    }, /*#__PURE__*/React.createElement(IOSStatusBar, {
      dark: dark
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        height: '100%',
        display: 'flex',
        flexDirection: 'column'
      }
    }, title !== undefined && /*#__PURE__*/React.createElement(IOSNavBar, {
      title: title,
      dark: dark
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        overflow: 'auto'
      }
    }, children), keyboard && /*#__PURE__*/React.createElement(IOSKeyboard, {
      dark: dark
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        zIndex: 60,
        height: 34,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'flex-end',
        paddingBottom: 8,
        pointerEvents: 'none'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 139,
        height: 5,
        borderRadius: 100,
        background: dark ? 'rgba(255,255,255,0.7)' : 'rgba(0,0,0,0.25)'
      }
    })))
  );
}

// ─────────────────────────────────────────────────────────────
// Keyboard — iOS 26 liquid glass
// ─────────────────────────────────────────────────────────────
function IOSKeyboard({
  dark = false
}) {
  const glyph = dark ? 'rgba(255,255,255,0.7)' : '#595959';
  const sugg = dark ? 'rgba(255,255,255,0.6)' : '#333';
  const keyBg = dark ? 'rgba(255,255,255,0.22)' : 'rgba(255,255,255,0.85)';

  // special-key icons
  const icons = {
    shift: /*#__PURE__*/React.createElement("svg", {
      width: "19",
      height: "17",
      viewBox: "0 0 19 17"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M9.5 1L1 9.5h4.5V16h8V9.5H18L9.5 1z",
      fill: glyph
    })),
    del: /*#__PURE__*/React.createElement("svg", {
      width: "23",
      height: "17",
      viewBox: "0 0 23 17"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M7 1h13a2 2 0 012 2v11a2 2 0 01-2 2H7l-6-7.5L7 1z",
      fill: "none",
      stroke: glyph,
      strokeWidth: "1.6",
      strokeLinejoin: "round"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M10 5l7 7M17 5l-7 7",
      stroke: glyph,
      strokeWidth: "1.6",
      strokeLinecap: "round"
    })),
    ret: /*#__PURE__*/React.createElement("svg", {
      width: "20",
      height: "14",
      viewBox: "0 0 20 14"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M18 1v6H4m0 0l4-4M4 7l4 4",
      fill: "none",
      stroke: "#fff",
      strokeWidth: "1.8",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }))
  };
  const key = (content, {
    w,
    flex,
    ret,
    fs = 25,
    k
  } = {}) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      height: 42,
      borderRadius: 8.5,
      flex: flex ? 1 : undefined,
      width: w,
      minWidth: 0,
      background: ret ? '#08f' : keyBg,
      boxShadow: '0 1px 0 rgba(0,0,0,0.075)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: '-apple-system, "SF Compact", system-ui',
      fontSize: fs,
      fontWeight: 458,
      color: ret ? '#fff' : glyph
    }
  }, content);
  const row = (keys, pad = 0) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6.5,
      justifyContent: 'center',
      padding: `0 ${pad}px`
    }
  }, keys.map(l => key(l, {
    flex: true,
    k: l
  })));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 15,
      borderRadius: 27,
      overflow: 'hidden',
      padding: '11px 0 2px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      boxShadow: dark ? '0 -2px 20px rgba(0,0,0,0.09)' : '0 -1px 6px rgba(0,0,0,0.018), 0 -3px 20px rgba(0,0,0,0.012)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 27,
      backdropFilter: 'blur(12px) saturate(180%)',
      WebkitBackdropFilter: 'blur(12px) saturate(180%)',
      background: dark ? 'rgba(120,120,128,0.14)' : 'rgba(255,255,255,0.25)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 27,
      boxShadow: dark ? 'inset 1.5px 1.5px 1px rgba(255,255,255,0.15)' : 'inset 1.5px 1.5px 1px rgba(255,255,255,0.7), inset -1px -1px 1px rgba(255,255,255,0.4)',
      border: dark ? '0.5px solid rgba(255,255,255,0.15)' : '0.5px solid rgba(0,0,0,0.06)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 20,
      alignItems: 'center',
      padding: '8px 22px 13px',
      width: '100%',
      boxSizing: 'border-box',
      position: 'relative'
    }
  }, ['"The"', 'the', 'to'].map((w, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      width: 1,
      height: 25,
      background: '#ccc',
      opacity: 0.3
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      textAlign: 'center',
      fontFamily: '-apple-system, system-ui',
      fontSize: 17,
      color: sugg,
      letterSpacing: -0.43,
      lineHeight: '22px'
    }
  }, w)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 13,
      padding: '0 6.5px',
      width: '100%',
      boxSizing: 'border-box',
      position: 'relative'
    }
  }, row(['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p']), row(['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'], 20), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14.25,
      alignItems: 'center'
    }
  }, key(icons.shift, {
    w: 45,
    k: 'shift'
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6.5,
      flex: 1
    }
  }, ['z', 'x', 'c', 'v', 'b', 'n', 'm'].map(l => key(l, {
    flex: true,
    k: l
  }))), key(icons.del, {
    w: 45,
    k: 'del'
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      alignItems: 'center'
    }
  }, key('ABC', {
    w: 92.25,
    fs: 18,
    k: 'abc'
  }), key('', {
    flex: true,
    k: 'space'
  }), key(icons.ret, {
    w: 92.25,
    ret: true,
    k: 'ret'
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 56,
      width: '100%',
      position: 'relative'
    }
  }));
}
Object.assign(window, {
  IOSDevice,
  IOSStatusBar,
  IOSNavBar,
  IOSGlassPill,
  IOSList,
  IOSListRow,
  IOSKeyboard
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/ios-frame.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/routes.js
try { (() => {
window.RZ_ROUTES = {
  home: {
    id: 'UX01',
    name: 'Home',
    journeys: ['A', 'C', 'G'],
    nav: 'home',
    states: ['Returning', 'First visit'],
    notes: ['Leads with the next application; creating a Base CV is the visible alternative.', 'Returning users see each application’s stage, attached CV and next step.', 'No outcome promises, hiring odds or invented stats.']
  },
  base: {
    id: 'UX06',
    name: 'Base CV',
    journeys: ['A', 'B'],
    nav: 'base',
    states: ['Edit', 'Review', 'Unsaved draft', 'Save conflict'],
    notes: ['Save creates a new version. Undo only changes the unsaved draft.', 'Dates keep their precision — a year alone never becomes January. Durations show a range and an “as of” date; overlapping roles count once.', 'Review shows five checks with next steps — never combined into a score.', 'Two positioning titles are separate from past job titles. A save conflict keeps the user’s edits.']
  },
  history: {
    id: 'UX07',
    name: 'Version history',
    journeys: ['A', 'B'],
    nav: 'base',
    states: ['Versions', 'No versions'],
    notes: ['Every version says why it exists (import, edit, confirmed answer, restore).', 'Restoring creates a new version — history is never rewritten.']
  },
  enrich: {
    id: 'UX08',
    name: 'Improve profile',
    journeys: ['B'],
    nav: 'enrich',
    states: ['Questions', 'Nothing to ask'],
    notes: ['Questions come after the Base review, one section at a time.', '“I don’t know” or Skip adds no fact and no points.', 'Answer → review → confirm → choose where it goes are separate steps.', 'Wording proposals never add numbers, tools or titles the user didn’t give.']
  },
  addjob: {
    id: 'UX09',
    name: 'Add a job',
    journeys: ['C'],
    flow: 0,
    states: ['Paste', 'Link blocked', 'Manual', 'Extension', 'Parse failed'],
    notes: ['Four ways in — paste, link, manual, browser capture — all end in the same requirements check.', 'A link that needs a login falls back to paste. We never sign in for the user.', 'Browser capture is a concept: one page, previewed, sent only after consent.']
  },
  requirements: {
    id: 'UX10',
    name: 'Check requirements',
    journeys: ['C'],
    flow: 1,
    states: ['Default', 'No Base CV'],
    notes: ['The user can correct required vs nice-to-have; changing it makes the old match out of date.', 'Must-haves (like right to work) are checked separately and never change the score.', '“Required” wording alone doesn’t make something a must-have.']
  },
  match: {
    id: 'UX11 · UX12',
    name: 'Match report',
    journeys: ['D'],
    flow: 2,
    states: ['Needs verification', 'Outdated', 'Failed'],
    notes: ['“You vs the job” uses every confirmed fact; “This CV” counts only what’s on the page.', 'An unanswered must-have stays visible next to every score, through to download.', 'PDF readability stays “Not tested” until a real PDF is checked.', 'Estimates only — not an employer’s ATS and not a hiring prediction.']
  },
  compare: {
    id: 'UX13',
    name: 'Review changes',
    journeys: ['E'],
    flow: 3,
    states: ['Default'],
    notes: ['One decision per change; unticking keeps the original wording.', 'Saving changes only this job’s CV. Updating the Base CV is a separate, explicit choice.']
  },
  jobeditor: {
    id: 'UX14',
    name: 'Job CV editor',
    journeys: ['E'],
    flow: 3,
    states: ['Default'],
    notes: ['Same controls as the Base editor, but every save is a job CV version.', 'Shows which Base version it came from. New facts go back to Base only via “Also add to Base CV”.']
  },
  preview: {
    id: 'UX15 · UX16',
    name: 'Template & download',
    journeys: ['E', 'F'],
    flow: 4,
    states: ['Ready', 'Export failed', 'No plan'],
    notes: ['Templates change presentation only — same facts in Clar and Contur.', 'CV language is separate from the app language. Contact details shown are chosen explicitly.', 'The user confirms the content before download. A failed export keeps everything saved.']
  },
  applications: {
    id: 'UX20',
    name: 'Applications',
    journeys: ['G'],
    nav: 'applications',
    states: ['List', 'Empty', 'No results'],
    notes: ['Each record shows its stage, attached CV (tailored or not) and next step.', '“Sent” counts only applications the user marked as sent.']
  },
  application: {
    id: 'UX20',
    name: 'Application',
    journeys: ['G'],
    nav: 'applications',
    states: ['To send', 'Sent'],
    notes: ['Marking as sent needs an attached CV and keeps an exact copy of what was sent.', 'Changing the stage later never creates or removes a “sent” record.', 'Tracking is manual — no reminders or outbound messages.']
  },
  linkedin: {
    id: 'UX21',
    name: 'LinkedIn check',
    journeys: ['G'],
    nav: 'linkedin',
    states: ['Paste', 'Compared'],
    notes: ['Works only on text the user pastes (20+ characters). No profile access or sync.', 'Differences are suggestions; nothing is added to the Base CV automatically.']
  },
  plans: {
    id: 'UX17',
    name: 'Plans',
    journeys: ['F'],
    nav: 'account',
    states: ['Default'],
    notes: ['1, 3 or 6 months. Prices stay “— RON” until decided.', 'Editing, match reports and preview stay free; the gate shown is one proposal.']
  },
  checkout: {
    id: 'UX17',
    name: 'Checkout',
    journeys: ['F'],
    nav: 'account',
    states: ['Form', 'Pending', 'Declined', 'Active'],
    notes: ['Card details live on the payment provider’s page — no card fields here.', 'Pending never grants access. Only the provider’s confirmation activates the plan.', 'The user acknowledges auto-renewal before paying.']
  },
  account: {
    id: 'UX18',
    name: 'Account',
    journeys: ['F'],
    nav: 'account',
    states: ['Active', 'Cancel scheduled', 'Payment failed', 'Free'],
    notes: ['Cancelling takes effect at the end of the period and can be undone until then.', 'Export everything as JSON; deleting the account needs explicit confirmation.', 'App language is separate from CV language.']
  },
  login: {
    id: 'AUTH01',
    name: 'Log in',
    journeys: ['H'],
    bare: true,
    states: ['Default', 'Wrong password', 'Too many attempts'],
    notes: ['One error message for wrong email or password — never say which one was wrong.', 'After too many tries, pause logins for a few minutes and offer a reset.', 'Unsaved drafts on the device survive a logout.']
  },
  forgot: {
    id: 'AUTH02',
    name: 'Forgot password',
    journeys: ['H'],
    bare: true,
    states: ['Form', 'Sent'],
    notes: ['The confirmation is the same whether or not the email has an account.', 'Resend waits 30 seconds; the link works for 1 hour.']
  },
  reset: {
    id: 'AUTH03',
    name: 'New password',
    journeys: ['H'],
    bare: true,
    states: ['Form', 'Done'],
    notes: ['Same password rules as sign-up. Changing it logs out every other device.']
  },
  expired: {
    id: 'AUTH04',
    name: 'Link expired',
    journeys: ['H'],
    bare: true,
    states: ['Default'],
    notes: ['Say how long links last and offer a new one in one click.']
  },
  session: {
    id: 'AUTH05',
    name: 'Signed out',
    journeys: ['H'],
    bare: true,
    states: ['Default'],
    notes: ['Explain why, reassure that the draft is kept, return to the same page after logging in.']
  },
  notfound: {
    id: 'SYS01',
    name: 'Page not found',
    journeys: ['I'],
    bare: true,
    states: ['Default'],
    notes: ['Any unknown address shows this page — with the app’s logo and a way back.', 'Reassure that data is safe; offer the two most likely destinations.']
  },
  error: {
    id: 'SYS02',
    name: 'Something went wrong',
    journeys: ['I'],
    bare: true,
    states: ['Default'],
    notes: ['Never blame the user. Say what’s safe and give a reference they can send us.', 'Try again first, Home second.']
  },
  offline: {
    id: 'SYS03',
    name: 'Offline',
    journeys: ['I'],
    bare: true,
    states: ['Default'],
    notes: ['Editing keeps working offline; show how many changes are waiting to save.']
  },
  maintenance: {
    id: 'SYS04',
    name: 'Maintenance',
    journeys: ['I'],
    bare: true,
    states: ['Default'],
    notes: ['Give a concrete return time in Bucharest time and a status page link.']
  }
};
window.RZ_ONB = [{
  r: 'welcome',
  id: 'UX01',
  name: 'Welcome (first visit)'
}, {
  r: 'account',
  id: 'UX02',
  name: 'Create account'
}, {
  r: 'verify',
  id: 'UX02',
  name: 'Verify email'
}, {
  r: 'goals',
  id: 'UX02',
  name: 'Your search'
}, {
  r: 'import',
  id: 'UX03',
  name: 'Import CV'
}, {
  r: 'reading',
  id: 'UX04',
  name: 'Reading your CV'
}, {
  r: 'review',
  id: 'UX05',
  name: 'Check details'
}, {
  r: 'ready',
  id: 'UX06',
  name: 'Base CV ready'
}];
window.RZ_HREF = (r, s) => r.indexOf('onb:') === 0 ? 'onboarding.html#/' + r.slice(4) : 'app.html#/' + r + (s ? '/' + encodeURIComponent(s) : '');
window.RZ_JOURNEYS = [{
  k: 'A',
  name: 'Get a Base CV you trust',
  when: 'First visit',
  goal: '“Turn the CV I already have into one I trust — without retyping everything.”',
  done: 'Base CV v1 is saved and every section has been confirmed by the user.',
  stages: [{
    t: 'Discover',
    r: 'onb:welcome',
    ux: 'UX01',
    does: 'Reads what Resumora does and what it won’t do.',
    we: 'Three steps, three promises. No outcome claims.'
  }, {
    t: 'Create account',
    r: 'onb:account',
    ux: 'UX02',
    does: 'Name, email, password, terms.',
    we: 'Inline errors that say how to fix them. Email verification next.'
  }, {
    t: 'Your search',
    r: 'onb:goals',
    ux: 'UX02',
    does: 'Where they apply and the role they aim for.',
    we: 'Sets the starting CV language. Skippable.'
  }, {
    t: 'Import',
    r: 'onb:import',
    ux: 'UX03',
    does: 'Uploads a PDF/DOCX or starts from scratch.',
    we: 'What happens to the file, before they upload.'
  }, {
    t: 'Reading',
    r: 'onb:reading',
    ux: 'UX04',
    does: 'Waits, or stops.',
    we: 'Named stages, cancel, and a retry that keeps nothing half-saved.'
  }, {
    t: 'Check details',
    r: 'onb:review',
    ux: 'UX05',
    does: 'Confirms each section; answers two small questions.',
    we: 'Live preview. Unknown month stays unknown.'
  }, {
    t: 'Base CV ready',
    r: 'onb:ready',
    ux: 'UX06',
    does: 'Adds a first job or opens the Base CV.',
    we: 'Version 1 saved; optional next tasks.'
  }],
  recover: ['Scanned or protected file → “Type it in”, guided', 'Reading fails → Try again; nothing was saved', 'Wrong email, short password, missing name → fix inline'],
  rules: ['Extracted facts stay “not confirmed” until the user confirms them', 'Saving needs an explicit “this is true” acknowledgement']
}, {
  k: 'B',
  name: 'Make the profile stronger',
  when: 'Right after the first save, or from Base CV → Review',
  goal: '“Add the results I never wrote down — honestly.”',
  done: 'A confirmed answer becomes a new Base CV version (or goes to one job CV). Skipped questions change nothing.',
  stages: [{
    t: 'See the review',
    r: 'base',
    s: 'Review',
    ux: 'UX06',
    does: 'Reads five checks for the Base CV.',
    we: 'Content, structure, job fit, writing, readiness — each with a next step.'
  }, {
    t: 'Answer a question',
    r: 'enrich',
    ux: 'UX08',
    does: 'Answers in their own words, or skips.',
    we: 'One section at a time; quick-answer chips; “wasn’t measured” is valid.'
  }, {
    t: 'Review & confirm',
    r: 'enrich',
    ux: 'UX08',
    does: 'Checks the proposed wording and confirms it’s true.',
    we: 'Before/after, the fact we’d record, no added numbers.'
  }, {
    t: 'Choose where it goes',
    r: 'enrich',
    ux: 'UX08',
    does: 'Base CV or only one job’s CV.',
    we: 'Destination is its own decision.'
  }, {
    t: 'New version',
    r: 'history',
    ux: 'UX07',
    does: 'Can look back or restore.',
    we: 'v4 saved with its reason; restore makes v5.'
  }],
  recover: ['“I don’t know” / Skip → no fact, no score change', 'Edit the answer after review, before saving'],
  rules: ['Never create an achievement, number, tool, title or date the user didn’t give', 'Each saved answer keeps its question, source and date']
}, {
  k: 'C',
  name: 'Add a job',
  when: 'Home → Start with a job, or Applications → Add a job',
  goal: '“Tell Resumora which job I’m applying for, in whatever form I have it.”',
  done: 'Requirements are reviewed as required or nice-to-have, must-haves are flagged, and a Base version is picked for the match.',
  stages: [{
    t: 'Capture the ad',
    r: 'addjob',
    ux: 'UX09',
    does: 'Pastes text, a link, types it in or captures the open tab.',
    we: 'All four end in the same review.'
  }, {
    t: 'Recover',
    r: 'addjob',
    s: 'Link blocked',
    ux: 'UX09',
    does: 'Pastes the text when a link can’t be read.',
    we: 'Plain reason + one-click switch to paste.'
  }, {
    t: 'Check requirements',
    r: 'requirements',
    ux: 'UX10',
    does: 'Corrects required vs nice-to-have.',
    we: 'Source sentence for each item; must-haves set apart.'
  }],
  recover: ['Link behind a login → paste instead', 'Reading the ad fails → text kept, try again or enter manually', 'No Base CV yet → bring your CV first'],
  rules: ['Editing requirements makes the existing match out of date', 'We never fetch pages behind logins or read browsing history']
}, {
  k: 'D',
  name: 'Understand my match',
  when: 'After requirements are checked',
  goal: '“Show me honestly how well I fit and what my CV is missing.”',
  done: 'The user knows their fit, what this CV leaves out, and what still needs an answer.',
  stages: [{
    t: 'Read the verdict',
    r: 'match',
    ux: 'UX11',
    does: 'Sees fit vs this CV, in plain words.',
    we: 'Two scores with different meanings; readability not tested.'
  }, {
    t: 'Answer must-haves',
    r: 'match',
    ux: 'UX11',
    does: 'Says whether they can work in Romania.',
    we: 'Answer is per job; it never changes the score.'
  }, {
    t: 'Inspect evidence',
    r: 'match',
    ux: 'UX12',
    does: 'Opens “Ready to add” and “Already strong”.',
    we: 'Where each fact comes from; RO↔EN equivalents explained.'
  }, {
    t: 'Recalculate',
    r: 'match',
    s: 'Outdated',
    ux: 'UX11',
    does: 'Refreshes a match after editing.',
    we: 'Out-of-date notice names the old version.'
  }],
  recover: ['Match out of date → Recalculate', 'Calculation fails → Try again; CV and job are kept'],
  rules: ['Rewording alone never raises the score', 'A high score never implies the user meets a must-have']
}, {
  k: 'E',
  name: 'Tailor and download',
  when: 'From the match report',
  goal: '“Give me a CV for this job I’m happy to send.”',
  done: 'A PDF of a saved job CV version is downloaded. The Base CV is unchanged unless the user chose to update it.',
  stages: [{
    t: 'Review changes',
    r: 'compare',
    ux: 'UX13',
    does: 'Keeps or drops each proposed change.',
    we: 'Before/after with the evidence behind it.'
  }, {
    t: 'Edit by hand',
    r: 'jobeditor',
    ux: 'UX14',
    does: 'Reorders bullets, hides items, edits the summary.',
    we: 'Job-only saves; source Base version shown.'
  }, {
    t: 'Update Base?',
    r: 'jobeditor',
    ux: 'UX13',
    does: 'Optionally sends new facts back to the Base CV.',
    we: 'Separate dialog with exactly what moves.'
  }, {
    t: 'Template & download',
    r: 'preview',
    ux: 'UX15 · UX16',
    does: 'Picks Clar or Contur, language, contact details.',
    we: 'Must-have warning repeated; content check before download.'
  }],
  recover: ['Export fails → nothing lost, Try again', 'No plan → see plans, then come back'],
  rules: ['A job CV save never changes the Base CV', 'Templates change layout, never facts']
}, {
  k: 'F',
  name: 'Plan and account',
  when: 'At the first download, or from Account',
  goal: '“Pay only when I need it, and stay in control of my plan and data.”',
  done: 'The plan is active (confirmed by the payment provider), or a cancellation is scheduled.',
  stages: [{
    t: 'Choose a term',
    r: 'plans',
    ux: 'UX17',
    does: 'Picks 1, 3 or 6 months.',
    we: 'Prices “— RON” until decided; what stays free.'
  }, {
    t: 'Checkout',
    r: 'checkout',
    ux: 'UX17',
    does: 'Acknowledges renewal, pays on the provider’s page.',
    we: 'Order summary with VAT and renewal terms.'
  }, {
    t: 'Pending or declined',
    r: 'checkout',
    s: 'Pending',
    ux: 'UX17',
    does: 'Waits for the bank, or tries again.',
    we: 'No access until confirmed; nothing charged on decline.'
  }, {
    t: 'Manage',
    r: 'account',
    ux: 'UX18',
    does: 'Sees allowance, cancels or resumes, exports data.',
    we: 'Cancel at period end; full JSON export.'
  }],
  recover: ['Payment declined → try again or another card', 'Renewal fails → downloads paused, CVs safe, update payment'],
  rules: ['A redirect after checkout never activates a plan', 'Deleting the account needs explicit confirmation']
}, {
  k: 'G',
  name: 'Track applications',
  when: 'Any time after adding a job',
  goal: '“Keep each job, its CV and my next step in one place.”',
  done: 'Each application has its CV attached, a stage, a contact and a next step; sent ones keep an exact copy.',
  stages: [{
    t: 'See all applications',
    r: 'applications',
    ux: 'UX20',
    does: 'Searches and filters by stage.',
    we: 'Tailored or not, next step and date.'
  }, {
    t: 'Open one',
    r: 'application',
    ux: 'UX20',
    does: 'Attaches a CV, adds contact and next step.',
    we: 'Latest CV for this job; must-have reminder.'
  }, {
    t: 'Mark as sent',
    r: 'application',
    s: 'Sent',
    ux: 'UX20',
    does: 'Confirms they sent it.',
    we: 'Keeps the exact CV, template and date sent.'
  }, {
    t: 'LinkedIn check',
    r: 'linkedin',
    ux: 'UX21',
    does: 'Pastes profile text to compare with the Base CV.',
    we: 'In both / only LinkedIn / only CV — suggestions only.'
  }],
  recover: ['No applications → add a job', 'Search with no results → clear search'],
  rules: ['Only an explicit “I’ve sent this” counts as sent', 'No reminders, outbound contact or LinkedIn connection']
}, {
  k: 'H',
  name: 'Sign in and get back in',
  when: 'Returning to the app, or a forgotten password',
  goal: '“Get back to my CVs quickly — even if I forgot my password.”',
  done: 'The user is logged in and lands where they were, with any unsaved draft intact.',
  stages: [{
    t: 'Log in',
    r: 'login',
    ux: 'AUTH01',
    does: 'Enters email and password.',
    we: 'One neutral error; “Forgot password?” always visible.'
  }, {
    t: 'Ask for a link',
    r: 'forgot',
    ux: 'AUTH02',
    does: 'Enters their email.',
    we: 'Same message whether or not an account exists.'
  }, {
    t: 'Check inbox',
    r: 'forgot',
    s: 'Sent',
    ux: 'AUTH02',
    does: 'Opens the email, or resends.',
    we: 'Link lifetime and where to look.'
  }, {
    t: 'New password',
    r: 'reset',
    ux: 'AUTH03',
    does: 'Chooses and repeats a password.',
    we: 'Inline rules; other devices logged out.'
  }, {
    t: 'Signed out',
    r: 'session',
    ux: 'AUTH05',
    does: 'Logs back in after a timeout.',
    we: 'Why it happened; the draft is kept.'
  }],
  recover: ['Wrong password → neutral message + reset', 'Too many tries → short pause, reset offered', 'Expired link → one click for a new one'],
  rules: ['Never reveal whether an email has an account', 'Passwords are never shown in plain text or stored by the prototype']
}, {
  k: 'I',
  name: 'When something breaks',
  when: 'Any time a page can’t load',
  goal: '“Tell me my work is safe and how to carry on.”',
  done: 'The user knows their data is safe and has one obvious next step.',
  stages: [{
    t: 'Page not found',
    r: 'notfound',
    ux: 'SYS01',
    does: 'Follows an old or mistyped link.',
    we: '404, reassurance, Home and Applications.'
  }, {
    t: 'Server error',
    r: 'error',
    ux: 'SYS02',
    does: 'Hits a failure on our side.',
    we: 'Not your fault; Try again; reference code.'
  }, {
    t: 'Offline',
    r: 'offline',
    ux: 'SYS03',
    does: 'Loses connection mid-edit.',
    we: 'Keep editing; changes waiting to save.'
  }, {
    t: 'Maintenance',
    r: 'maintenance',
    ux: 'SYS04',
    does: 'Arrives during an update.',
    we: 'Return time and status link.'
  }],
  recover: ['Retry from the page itself', 'Always a link back to Home'],
  rules: ['Every system page keeps the logo and a way back', 'Say what’s safe before saying what went wrong']
}];
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/routes.js", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.Pill = __ds_scope.Pill;

__ds_ns.BTN_CSS = __ds_scope.BTN_CSS;

__ds_ns.LOGO_WORD_D = __ds_scope.LOGO_WORD_D;

__ds_ns.LOGO_W = __ds_scope.LOGO_W;

__ds_ns.DOOR_RAYS = __ds_scope.DOOR_RAYS;

__ds_ns.DOOR_LEAF = __ds_scope.DOOR_LEAF;

__ds_ns.CVDocument = __ds_scope.CVDocument;

__ds_ns.PlanCard = __ds_scope.PlanCard;

__ds_ns.TaskCard = __ds_scope.TaskCard;

__ds_ns.Alert = __ds_scope.Alert;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.EmptyState = __ds_scope.EmptyState;

__ds_ns.Spinner = __ds_scope.Spinner;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Dropzone = __ds_scope.Dropzone;

__ds_ns.Field = __ds_scope.Field;

__ds_ns.FieldShell = __ds_scope.FieldShell;

__ds_ns.RadioGroup = __ds_scope.RadioGroup;

__ds_ns.Segmented = __ds_scope.Segmented;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.FIELD_CSS = __ds_scope.FIELD_CSS;

__ds_ns.ChangeCard = __ds_scope.ChangeCard;

__ds_ns.FindingGroup = __ds_scope.FindingGroup;

__ds_ns.KeywordRow = __ds_scope.KeywordRow;

__ds_ns.MatchVerdict = __ds_scope.MatchVerdict;

__ds_ns.SideNav = __ds_scope.SideNav;

__ds_ns.TopBar = __ds_scope.TopBar;

__ds_ns.ProgressBar = __ds_scope.ProgressBar;

__ds_ns.ScoreRing = __ds_scope.ScoreRing;

__ds_ns.Stepper = __ds_scope.Stepper;

})();
